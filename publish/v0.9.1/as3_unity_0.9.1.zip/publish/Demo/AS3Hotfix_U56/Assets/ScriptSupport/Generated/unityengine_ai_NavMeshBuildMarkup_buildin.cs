using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class unityengine_ai_NavMeshBuildMarkup_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("unityengine_ai_NavMeshBuildMarkup_creator", default(UnityEngine.AI.NavMeshBuildMarkup)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuildMarkup_buildin.unityengine_ai_NavMeshBuildMarkup_ctor","unityengine_ai_NavMeshBuildMarkup_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuildMarkup_buildin.unityengine_ai_NavMeshBuildMarkup_get_overrideArea","unityengine_ai_NavMeshBuildMarkup_get_overrideArea");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuildMarkup_buildin.unityengine_ai_NavMeshBuildMarkup_set_overrideArea","unityengine_ai_NavMeshBuildMarkup_set_overrideArea");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuildMarkup_buildin.unityengine_ai_NavMeshBuildMarkup_get_area","unityengine_ai_NavMeshBuildMarkup_get_area");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuildMarkup_buildin.unityengine_ai_NavMeshBuildMarkup_set_area","unityengine_ai_NavMeshBuildMarkup_set_area");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuildMarkup_buildin.unityengine_ai_NavMeshBuildMarkup_get_ignoreFromBuild","unityengine_ai_NavMeshBuildMarkup_get_ignoreFromBuild");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuildMarkup_buildin.unityengine_ai_NavMeshBuildMarkup_set_ignoreFromBuild","unityengine_ai_NavMeshBuildMarkup_set_ignoreFromBuild");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuildMarkup_buildin.unityengine_ai_NavMeshBuildMarkup_get_root","unityengine_ai_NavMeshBuildMarkup_get_root");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuildMarkup_buildin.unityengine_ai_NavMeshBuildMarkup_set_root","unityengine_ai_NavMeshBuildMarkup_set_root");
		}


		public class unityengine_ai_NavMeshBuildMarkup_ctor : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshBuildMarkup_ctor() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshBuildMarkup_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{

					((LinkObj<UnityEngine.AI.NavMeshBuildMarkup>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new UnityEngine.AI.NavMeshBuildMarkup();
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshBuildMarkup_get_overrideArea : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshBuildMarkup_get_overrideArea() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshBuildMarkup_get_overrideArea";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshBuildMarkup _this =
					(UnityEngine.AI.NavMeshBuildMarkup)((LinkObj<UnityEngine.AI.NavMeshBuildMarkup>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					bool _result_ = _this.overrideArea
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					((LinkObj<UnityEngine.AI.NavMeshBuildMarkup>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshBuildMarkup_set_overrideArea : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshBuildMarkup_set_overrideArea() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_boolean);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshBuildMarkup_set_overrideArea";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshBuildMarkup _this =
					(UnityEngine.AI.NavMeshBuildMarkup)((LinkObj<UnityEngine.AI.NavMeshBuildMarkup>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					bool arg0 = TypeConverter.ConvertToBoolean(argements[0], stackframe, token).value;

					_this.overrideArea = (System.Boolean)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<UnityEngine.AI.NavMeshBuildMarkup>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshBuildMarkup_get_area : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshBuildMarkup_get_area() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshBuildMarkup_get_area";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshBuildMarkup _this =
					(UnityEngine.AI.NavMeshBuildMarkup)((LinkObj<UnityEngine.AI.NavMeshBuildMarkup>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					int _result_ = (int)(_this.area
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<UnityEngine.AI.NavMeshBuildMarkup>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshBuildMarkup_set_area : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshBuildMarkup_set_area() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshBuildMarkup_set_area";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshBuildMarkup _this =
					(UnityEngine.AI.NavMeshBuildMarkup)((LinkObj<UnityEngine.AI.NavMeshBuildMarkup>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					_this.area = (System.Int32)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<UnityEngine.AI.NavMeshBuildMarkup>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshBuildMarkup_get_ignoreFromBuild : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshBuildMarkup_get_ignoreFromBuild() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshBuildMarkup_get_ignoreFromBuild";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshBuildMarkup _this =
					(UnityEngine.AI.NavMeshBuildMarkup)((LinkObj<UnityEngine.AI.NavMeshBuildMarkup>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					bool _result_ = _this.ignoreFromBuild
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					((LinkObj<UnityEngine.AI.NavMeshBuildMarkup>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshBuildMarkup_set_ignoreFromBuild : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshBuildMarkup_set_ignoreFromBuild() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_boolean);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshBuildMarkup_set_ignoreFromBuild";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshBuildMarkup _this =
					(UnityEngine.AI.NavMeshBuildMarkup)((LinkObj<UnityEngine.AI.NavMeshBuildMarkup>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					bool arg0 = TypeConverter.ConvertToBoolean(argements[0], stackframe, token).value;

					_this.ignoreFromBuild = (System.Boolean)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<UnityEngine.AI.NavMeshBuildMarkup>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshBuildMarkup_get_root : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshBuildMarkup_get_root() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshBuildMarkup_get_root";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshBuildMarkup _this =
					(UnityEngine.AI.NavMeshBuildMarkup)((LinkObj<UnityEngine.AI.NavMeshBuildMarkup>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					object _result_ = _this.root
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					((LinkObj<UnityEngine.AI.NavMeshBuildMarkup>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshBuildMarkup_set_root : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshBuildMarkup_set_root() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshBuildMarkup_set_root";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshBuildMarkup _this =
					(UnityEngine.AI.NavMeshBuildMarkup)((LinkObj<UnityEngine.AI.NavMeshBuildMarkup>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					UnityEngine.Transform arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.Transform)_temp;
					}

					_this.root = (UnityEngine.Transform)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<UnityEngine.AI.NavMeshBuildMarkup>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

	}
}
