using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_DateTime_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_DateTime_creator", default(System.DateTime)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_constructor_","system_DateTime_constructor_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_constructor__","system_DateTime_constructor__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_constructor___","system_DateTime_constructor___");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_constructor____","system_DateTime_constructor____");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_constructor_____","system_DateTime_constructor_____");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_constructor______","system_DateTime_constructor______");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_constructor_______","system_DateTime_constructor_______");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_constructor________","system_DateTime_constructor________");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_constructor_________","system_DateTime_constructor_________");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_constructor__________","system_DateTime_constructor__________");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_ctor","system_DateTime_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_MinValue_getter","system_DateTime_MinValue_getter");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_MaxValue_getter","system_DateTime_MaxValue_getter");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_add","system_DateTime_add");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_addDays","system_DateTime_addDays");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_addHours","system_DateTime_addHours");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_addMilliseconds","system_DateTime_addMilliseconds");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_addMinutes","system_DateTime_addMinutes");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_addMonths","system_DateTime_addMonths");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_addSeconds","system_DateTime_addSeconds");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_addTicks","system_DateTime_addTicks");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_addYears","system_DateTime_addYears");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_compare","static_system_DateTime_compare");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_compareTo_","system_DateTime_compareTo_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_daysInMonth","static_system_DateTime_daysInMonth");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_equals___","system_DateTime_equals___");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_equals","static_system_DateTime_equals");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_fromBinary","static_system_DateTime_fromBinary");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_fromFileTime","static_system_DateTime_fromFileTime");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_fromFileTimeUtc","static_system_DateTime_fromFileTimeUtc");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_fromOADate","static_system_DateTime_fromOADate");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_isDaylightSavingTime","system_DateTime_isDaylightSavingTime");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_specifyKind","static_system_DateTime_specifyKind");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_toBinary","system_DateTime_toBinary");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_get_Date","system_DateTime_get_Date");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_get_Day","system_DateTime_get_Day");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_get_DayOfWeek","system_DateTime_get_DayOfWeek");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_get_DayOfYear","system_DateTime_get_DayOfYear");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_get_Hour","system_DateTime_get_Hour");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_get_Kind","system_DateTime_get_Kind");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_get_Millisecond","system_DateTime_get_Millisecond");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_get_Minute","system_DateTime_get_Minute");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_get_Month","system_DateTime_get_Month");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_get_Now","static_system_DateTime_get_Now");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_get_UtcNow","static_system_DateTime_get_UtcNow");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_get_Second","system_DateTime_get_Second");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_get_Ticks","system_DateTime_get_Ticks");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_get_TimeOfDay","system_DateTime_get_TimeOfDay");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_get_Today","static_system_DateTime_get_Today");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_get_Year","system_DateTime_get_Year");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_isLeapYear","static_system_DateTime_isLeapYear");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_parse","static_system_DateTime_parse");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_parse_","static_system_DateTime_parse_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_parse__","static_system_DateTime_parse__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_parseExact","static_system_DateTime_parseExact");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_parseExact_","static_system_DateTime_parseExact_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_parseExact__","static_system_DateTime_parseExact__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_subtract","system_DateTime_subtract");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_subtract_","system_DateTime_subtract_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_toOADate","system_DateTime_toOADate");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_toFileTime","system_DateTime_toFileTime");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_toFileTimeUtc","system_DateTime_toFileTimeUtc");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_toLocalTime","system_DateTime_toLocalTime");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_toLongDateString","system_DateTime_toLongDateString");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_toLongTimeString","system_DateTime_toLongTimeString");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_toShortDateString","system_DateTime_toShortDateString");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_toShortTimeString","system_DateTime_toShortTimeString");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_toString___","system_DateTime_toString___");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_toUniversalTime","system_DateTime_toUniversalTime");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_tryParse","static_system_DateTime_tryParse");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_tryParse_","static_system_DateTime_tryParse_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_tryParseExact","static_system_DateTime_tryParseExact");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_tryParseExact_","static_system_DateTime_tryParseExact_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_getDateTimeFormats","system_DateTime_getDateTimeFormats");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_getDateTimeFormats_","system_DateTime_getDateTimeFormats_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_getDateTimeFormats__","system_DateTime_getDateTimeFormats__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.system_DateTime_getDateTimeFormats___","system_DateTime_getDateTimeFormats___");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_op_Addition","static_system_DateTime_op_Addition");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_op_Subtraction","static_system_DateTime_op_Subtraction");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_op_Subtraction_","static_system_DateTime_op_Subtraction_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_op_Equality","static_system_DateTime_op_Equality");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_op_Inequality","static_system_DateTime_op_Inequality");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_op_LessThan","static_system_DateTime_op_LessThan");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_op_LessThanOrEqual","static_system_DateTime_op_LessThanOrEqual");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_op_GreaterThan","static_system_DateTime_op_GreaterThan");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_DateTime_buildin.static_system_DateTime_op_GreaterThanOrEqual","static_system_DateTime_op_GreaterThanOrEqual");
		}


		public class system_DateTime_constructor_ : NativeConstParameterFunction
		{
			public system_DateTime_constructor_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_constructor_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.Int64 arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Int64);
					}
					else
					{
						LinkObj<System.Int64> argObj = (LinkObj<System.Int64>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.DateTimeKind arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.DateTimeKind)_temp;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.DateTime((System.Int64)arg0,(System.DateTimeKind)arg1));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_constructor__ : NativeConstParameterFunction
		{
			public system_DateTime_constructor__() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_constructor__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					int arg2 = TypeConverter.ConvertToInt(argements[2]);

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.DateTime((System.Int32)arg0,(System.Int32)arg1,(System.Int32)arg2));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_constructor___ : NativeConstParameterFunction
		{
			public system_DateTime_constructor___() : base(4)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_constructor___";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					int arg2 = TypeConverter.ConvertToInt(argements[2]);
					System.Globalization.Calendar arg3;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[3],

							stackframe.player.linktypemapper.getLinkType(argements[3].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[3].rtType,

								functionDefine.signature.parameters[3].type
								);
							success = false;
							return;
						}
						arg3 = (System.Globalization.Calendar)_temp;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.DateTime((System.Int32)arg0,(System.Int32)arg1,(System.Int32)arg2,(System.Globalization.Calendar)arg3));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_constructor____ : NativeConstParameterFunction
		{
			public system_DateTime_constructor____() : base(6)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_constructor____";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					int arg2 = TypeConverter.ConvertToInt(argements[2]);
					int arg3 = TypeConverter.ConvertToInt(argements[3]);
					int arg4 = TypeConverter.ConvertToInt(argements[4]);
					int arg5 = TypeConverter.ConvertToInt(argements[5]);

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.DateTime((System.Int32)arg0,(System.Int32)arg1,(System.Int32)arg2,(System.Int32)arg3,(System.Int32)arg4,(System.Int32)arg5));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_constructor_____ : NativeConstParameterFunction
		{
			public system_DateTime_constructor_____() : base(7)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_constructor_____";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					int arg2 = TypeConverter.ConvertToInt(argements[2]);
					int arg3 = TypeConverter.ConvertToInt(argements[3]);
					int arg4 = TypeConverter.ConvertToInt(argements[4]);
					int arg5 = TypeConverter.ConvertToInt(argements[5]);
					System.DateTimeKind arg6;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[6],

							stackframe.player.linktypemapper.getLinkType(argements[6].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[6].rtType,

								functionDefine.signature.parameters[6].type
								);
							success = false;
							return;
						}
						arg6 = (System.DateTimeKind)_temp;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.DateTime((System.Int32)arg0,(System.Int32)arg1,(System.Int32)arg2,(System.Int32)arg3,(System.Int32)arg4,(System.Int32)arg5,(System.DateTimeKind)arg6));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_constructor______ : NativeConstParameterFunction
		{
			public system_DateTime_constructor______() : base(7)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_constructor______";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					int arg2 = TypeConverter.ConvertToInt(argements[2]);
					int arg3 = TypeConverter.ConvertToInt(argements[3]);
					int arg4 = TypeConverter.ConvertToInt(argements[4]);
					int arg5 = TypeConverter.ConvertToInt(argements[5]);
					System.Globalization.Calendar arg6;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[6],

							stackframe.player.linktypemapper.getLinkType(argements[6].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[6].rtType,

								functionDefine.signature.parameters[6].type
								);
							success = false;
							return;
						}
						arg6 = (System.Globalization.Calendar)_temp;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.DateTime((System.Int32)arg0,(System.Int32)arg1,(System.Int32)arg2,(System.Int32)arg3,(System.Int32)arg4,(System.Int32)arg5,(System.Globalization.Calendar)arg6));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_constructor_______ : NativeConstParameterFunction
		{
			public system_DateTime_constructor_______() : base(7)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_constructor_______";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					int arg2 = TypeConverter.ConvertToInt(argements[2]);
					int arg3 = TypeConverter.ConvertToInt(argements[3]);
					int arg4 = TypeConverter.ConvertToInt(argements[4]);
					int arg5 = TypeConverter.ConvertToInt(argements[5]);
					int arg6 = TypeConverter.ConvertToInt(argements[6]);

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.DateTime((System.Int32)arg0,(System.Int32)arg1,(System.Int32)arg2,(System.Int32)arg3,(System.Int32)arg4,(System.Int32)arg5,(System.Int32)arg6));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_constructor________ : NativeConstParameterFunction
		{
			public system_DateTime_constructor________() : base(8)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_constructor________";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					int arg2 = TypeConverter.ConvertToInt(argements[2]);
					int arg3 = TypeConverter.ConvertToInt(argements[3]);
					int arg4 = TypeConverter.ConvertToInt(argements[4]);
					int arg5 = TypeConverter.ConvertToInt(argements[5]);
					int arg6 = TypeConverter.ConvertToInt(argements[6]);
					System.DateTimeKind arg7;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[7],

							stackframe.player.linktypemapper.getLinkType(argements[7].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[7].rtType,

								functionDefine.signature.parameters[7].type
								);
							success = false;
							return;
						}
						arg7 = (System.DateTimeKind)_temp;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.DateTime((System.Int32)arg0,(System.Int32)arg1,(System.Int32)arg2,(System.Int32)arg3,(System.Int32)arg4,(System.Int32)arg5,(System.Int32)arg6,(System.DateTimeKind)arg7));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_constructor_________ : NativeConstParameterFunction
		{
			public system_DateTime_constructor_________() : base(8)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_constructor_________";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					int arg2 = TypeConverter.ConvertToInt(argements[2]);
					int arg3 = TypeConverter.ConvertToInt(argements[3]);
					int arg4 = TypeConverter.ConvertToInt(argements[4]);
					int arg5 = TypeConverter.ConvertToInt(argements[5]);
					int arg6 = TypeConverter.ConvertToInt(argements[6]);
					System.Globalization.Calendar arg7;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[7],

							stackframe.player.linktypemapper.getLinkType(argements[7].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[7].rtType,

								functionDefine.signature.parameters[7].type
								);
							success = false;
							return;
						}
						arg7 = (System.Globalization.Calendar)_temp;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.DateTime((System.Int32)arg0,(System.Int32)arg1,(System.Int32)arg2,(System.Int32)arg3,(System.Int32)arg4,(System.Int32)arg5,(System.Int32)arg6,(System.Globalization.Calendar)arg7));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_constructor__________ : NativeConstParameterFunction
		{
			public system_DateTime_constructor__________() : base(9)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_constructor__________";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					int arg2 = TypeConverter.ConvertToInt(argements[2]);
					int arg3 = TypeConverter.ConvertToInt(argements[3]);
					int arg4 = TypeConverter.ConvertToInt(argements[4]);
					int arg5 = TypeConverter.ConvertToInt(argements[5]);
					int arg6 = TypeConverter.ConvertToInt(argements[6]);
					System.Globalization.Calendar arg7;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[7],

							stackframe.player.linktypemapper.getLinkType(argements[7].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[7].rtType,

								functionDefine.signature.parameters[7].type
								);
							success = false;
							return;
						}
						arg7 = (System.Globalization.Calendar)_temp;
					}
					System.DateTimeKind arg8;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[8],

							stackframe.player.linktypemapper.getLinkType(argements[8].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[8].rtType,

								functionDefine.signature.parameters[8].type
								);
							success = false;
							return;
						}
						arg8 = (System.DateTimeKind)_temp;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.DateTime((System.Int32)arg0,(System.Int32)arg1,(System.Int32)arg2,(System.Int32)arg3,(System.Int32)arg4,(System.Int32)arg5,(System.Int32)arg6,(System.Globalization.Calendar)arg7,(System.DateTimeKind)arg8));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_ctor : NativeConstParameterFunction
		{
			public system_DateTime_ctor() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.Int64 arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Int64);
					}
					else
					{
						LinkObj<System.Int64> argObj = (LinkObj<System.Int64>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new System.DateTime((System.Int64)arg0);
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_MinValue_getter : NativeConstParameterFunction
		{
			public system_DateTime_MinValue_getter() : base(0)
			{
				para = new List<RunTimeDataType>();
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_MinValue_getter";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.DateTime _result_ = System.DateTime.MinValue					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);

					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_MaxValue_getter : NativeConstParameterFunction
		{
			public system_DateTime_MaxValue_getter() : base(0)
			{
				para = new List<RunTimeDataType>();
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_MaxValue_getter";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.DateTime _result_ = System.DateTime.MaxValue					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);

					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_add : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_add() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_add";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					System.TimeSpan arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.TimeSpan);
					}
					else
					{
						LinkObj<System.TimeSpan> argObj = (LinkObj<System.TimeSpan>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.DateTime _result_ = _this.Add((System.TimeSpan)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("Add",new Type[] {typeof(System.TimeSpan)});;
				}
				return method;
			}

		}

		public class system_DateTime_addDays : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_addDays() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_number);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_addDays";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					double arg0 = TypeConverter.ConvertToNumber(argements[0]);

					System.DateTime _result_ = _this.AddDays((System.Double)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("AddDays",new Type[] {typeof(System.Double)});;
				}
				return method;
			}

		}

		public class system_DateTime_addHours : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_addHours() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_number);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_addHours";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					double arg0 = TypeConverter.ConvertToNumber(argements[0]);

					System.DateTime _result_ = _this.AddHours((System.Double)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("AddHours",new Type[] {typeof(System.Double)});;
				}
				return method;
			}

		}

		public class system_DateTime_addMilliseconds : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_addMilliseconds() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_number);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_addMilliseconds";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					double arg0 = TypeConverter.ConvertToNumber(argements[0]);

					System.DateTime _result_ = _this.AddMilliseconds((System.Double)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("AddMilliseconds",new Type[] {typeof(System.Double)});;
				}
				return method;
			}

		}

		public class system_DateTime_addMinutes : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_addMinutes() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_number);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_addMinutes";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					double arg0 = TypeConverter.ConvertToNumber(argements[0]);

					System.DateTime _result_ = _this.AddMinutes((System.Double)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("AddMinutes",new Type[] {typeof(System.Double)});;
				}
				return method;
			}

		}

		public class system_DateTime_addMonths : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_addMonths() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_addMonths";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					System.DateTime _result_ = _this.AddMonths((System.Int32)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("AddMonths",new Type[] {typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_DateTime_addSeconds : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_addSeconds() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_number);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_addSeconds";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					double arg0 = TypeConverter.ConvertToNumber(argements[0]);

					System.DateTime _result_ = _this.AddSeconds((System.Double)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("AddSeconds",new Type[] {typeof(System.Double)});;
				}
				return method;
			}

		}

		public class system_DateTime_addTicks : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_addTicks() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_addTicks";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					System.Int64 arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Int64);
					}
					else
					{
						LinkObj<System.Int64> argObj = (LinkObj<System.Int64>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.DateTime _result_ = _this.AddTicks((System.Int64)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("AddTicks",new Type[] {typeof(System.Int64)});;
				}
				return method;
			}

		}

		public class system_DateTime_addYears : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_addYears() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_addYears";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					System.DateTime _result_ = _this.AddYears((System.Int32)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("AddYears",new Type[] {typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class static_system_DateTime_compare : NativeConstParameterFunction
		{
			public static_system_DateTime_compare() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_compare";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.DateTime arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.DateTime arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					int _result_ = (int)(System.DateTime.Compare((System.DateTime)arg0,(System.DateTime)arg1)
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_compareTo_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_compareTo_() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_compareTo_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					System.DateTime arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					int _result_ = (int)(_this.CompareTo((System.DateTime)arg0)
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("CompareTo",new Type[] {typeof(System.DateTime)});;
				}
				return method;
			}

		}

		public class static_system_DateTime_daysInMonth : NativeConstParameterFunction
		{
			public static_system_DateTime_daysInMonth() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_daysInMonth";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					int _result_ = (int)(System.DateTime.DaysInMonth((System.Int32)arg0,(System.Int32)arg1)
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_equals___ : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_equals___() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_equals___";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					System.DateTime arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					bool _result_ = _this.Equals((System.DateTime)arg0)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("Equals",new Type[] {typeof(System.DateTime)});;
				}
				return method;
			}

		}

		public class static_system_DateTime_equals : NativeConstParameterFunction
		{
			public static_system_DateTime_equals() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_equals";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.DateTime arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.DateTime arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					bool _result_ = System.DateTime.Equals((System.DateTime)arg0,(System.DateTime)arg1)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_fromBinary : NativeConstParameterFunction
		{
			public static_system_DateTime_fromBinary() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_fromBinary";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Int64 arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Int64);
					}
					else
					{
						LinkObj<System.Int64> argObj = (LinkObj<System.Int64>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.DateTime _result_ = System.DateTime.FromBinary((System.Int64)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_fromFileTime : NativeConstParameterFunction
		{
			public static_system_DateTime_fromFileTime() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_fromFileTime";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Int64 arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Int64);
					}
					else
					{
						LinkObj<System.Int64> argObj = (LinkObj<System.Int64>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.DateTime _result_ = System.DateTime.FromFileTime((System.Int64)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_fromFileTimeUtc : NativeConstParameterFunction
		{
			public static_system_DateTime_fromFileTimeUtc() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_fromFileTimeUtc";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Int64 arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Int64);
					}
					else
					{
						LinkObj<System.Int64> argObj = (LinkObj<System.Int64>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.DateTime _result_ = System.DateTime.FromFileTimeUtc((System.Int64)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_fromOADate : NativeConstParameterFunction
		{
			public static_system_DateTime_fromOADate() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_number);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_fromOADate";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					double arg0 = TypeConverter.ConvertToNumber(argements[0]);

					System.DateTime _result_ = System.DateTime.FromOADate((System.Double)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_isDaylightSavingTime : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_isDaylightSavingTime() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_isDaylightSavingTime";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					bool _result_ = _this.IsDaylightSavingTime()
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("IsDaylightSavingTime",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class static_system_DateTime_specifyKind : NativeConstParameterFunction
		{
			public static_system_DateTime_specifyKind() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_specifyKind";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.DateTime arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.DateTimeKind arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.DateTimeKind)_temp;
					}

					System.DateTime _result_ = System.DateTime.SpecifyKind((System.DateTime)arg0,(System.DateTimeKind)arg1)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_toBinary : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_toBinary() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_toBinary";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					System.Int64 _result_ = _this.ToBinary()
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("ToBinary",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_DateTime_get_Date : NativeConstParameterFunction
		{
			public system_DateTime_get_Date() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_get_Date";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					System.DateTime _result_ = _this.Date
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_get_Day : NativeConstParameterFunction
		{
			public system_DateTime_get_Day() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_get_Day";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					int _result_ = (int)(_this.Day
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_get_DayOfWeek : NativeConstParameterFunction
		{
			public system_DateTime_get_DayOfWeek() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_get_DayOfWeek";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					System.DayOfWeek _result_ = _this.DayOfWeek
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_get_DayOfYear : NativeConstParameterFunction
		{
			public system_DateTime_get_DayOfYear() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_get_DayOfYear";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					int _result_ = (int)(_this.DayOfYear
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_get_Hour : NativeConstParameterFunction
		{
			public system_DateTime_get_Hour() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_get_Hour";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					int _result_ = (int)(_this.Hour
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_get_Kind : NativeConstParameterFunction
		{
			public system_DateTime_get_Kind() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_get_Kind";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					System.DateTimeKind _result_ = _this.Kind
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_get_Millisecond : NativeConstParameterFunction
		{
			public system_DateTime_get_Millisecond() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_get_Millisecond";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					int _result_ = (int)(_this.Millisecond
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_get_Minute : NativeConstParameterFunction
		{
			public system_DateTime_get_Minute() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_get_Minute";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					int _result_ = (int)(_this.Minute
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_get_Month : NativeConstParameterFunction
		{
			public system_DateTime_get_Month() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_get_Month";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					int _result_ = (int)(_this.Month
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_get_Now : NativeConstParameterFunction
		{
			public static_system_DateTime_get_Now() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_get_Now";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{

					System.DateTime _result_ = System.DateTime.Now
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_get_UtcNow : NativeConstParameterFunction
		{
			public static_system_DateTime_get_UtcNow() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_get_UtcNow";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{

					System.DateTime _result_ = System.DateTime.UtcNow
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_get_Second : NativeConstParameterFunction
		{
			public system_DateTime_get_Second() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_get_Second";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					int _result_ = (int)(_this.Second
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_get_Ticks : NativeConstParameterFunction
		{
			public system_DateTime_get_Ticks() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_get_Ticks";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					System.Int64 _result_ = _this.Ticks
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_get_TimeOfDay : NativeConstParameterFunction
		{
			public system_DateTime_get_TimeOfDay() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_get_TimeOfDay";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					System.TimeSpan _result_ = _this.TimeOfDay
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_get_Today : NativeConstParameterFunction
		{
			public static_system_DateTime_get_Today() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_get_Today";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{

					System.DateTime _result_ = System.DateTime.Today
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_get_Year : NativeConstParameterFunction
		{
			public system_DateTime_get_Year() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_get_Year";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					int _result_ = (int)(_this.Year
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_isLeapYear : NativeConstParameterFunction
		{
			public static_system_DateTime_isLeapYear() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_isLeapYear";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					bool _result_ = System.DateTime.IsLeapYear((System.Int32)arg0)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_parse : NativeConstParameterFunction
		{
			public static_system_DateTime_parse() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_parse";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					System.DateTime _result_ = System.DateTime.Parse((System.String)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_parse_ : NativeConstParameterFunction
		{
			public static_system_DateTime_parse_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_parse_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					System.IFormatProvider arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.IFormatProvider)_temp;
					}

					System.DateTime _result_ = System.DateTime.Parse((System.String)arg0,(System.IFormatProvider)arg1)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_parse__ : NativeConstParameterFunction
		{
			public static_system_DateTime_parse__() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_parse__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					System.IFormatProvider arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.IFormatProvider)_temp;
					}
					System.Globalization.DateTimeStyles arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Globalization.DateTimeStyles)_temp;
					}

					System.DateTime _result_ = System.DateTime.Parse((System.String)arg0,(System.IFormatProvider)arg1,(System.Globalization.DateTimeStyles)arg2)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_parseExact : NativeConstParameterFunction
		{
			public static_system_DateTime_parseExact() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_parseExact";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);
					System.IFormatProvider arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.IFormatProvider)_temp;
					}

					System.DateTime _result_ = System.DateTime.ParseExact((System.String)arg0,(System.String)arg1,(System.IFormatProvider)arg2)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_parseExact_ : NativeConstParameterFunction
		{
			public static_system_DateTime_parseExact_() : base(4)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_parseExact_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);
					System.IFormatProvider arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.IFormatProvider)_temp;
					}
					System.Globalization.DateTimeStyles arg3;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[3],

							stackframe.player.linktypemapper.getLinkType(argements[3].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[3].rtType,

								functionDefine.signature.parameters[3].type
								);
							success = false;
							return;
						}
						arg3 = (System.Globalization.DateTimeStyles)_temp;
					}

					System.DateTime _result_ = System.DateTime.ParseExact((System.String)arg0,(System.String)arg1,(System.IFormatProvider)arg2,(System.Globalization.DateTimeStyles)arg3)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_parseExact__ : NativeConstParameterFunction
		{
			public static_system_DateTime_parseExact__() : base(4)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_parseExact__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					System.String[] arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.String[])_temp;
					}
					System.IFormatProvider arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.IFormatProvider)_temp;
					}
					System.Globalization.DateTimeStyles arg3;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[3],

							stackframe.player.linktypemapper.getLinkType(argements[3].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[3].rtType,

								functionDefine.signature.parameters[3].type
								);
							success = false;
							return;
						}
						arg3 = (System.Globalization.DateTimeStyles)_temp;
					}

					System.DateTime _result_ = System.DateTime.ParseExact((System.String)arg0,(System.String[])arg1,(System.IFormatProvider)arg2,(System.Globalization.DateTimeStyles)arg3)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_subtract : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_subtract() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_subtract";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					System.DateTime arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.TimeSpan _result_ = _this.Subtract((System.DateTime)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("Subtract",new Type[] {typeof(System.DateTime)});;
				}
				return method;
			}

		}

		public class system_DateTime_subtract_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_subtract_() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_subtract_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					System.TimeSpan arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.TimeSpan);
					}
					else
					{
						LinkObj<System.TimeSpan> argObj = (LinkObj<System.TimeSpan>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.DateTime _result_ = _this.Subtract((System.TimeSpan)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("Subtract",new Type[] {typeof(System.TimeSpan)});;
				}
				return method;
			}

		}

		public class system_DateTime_toOADate : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_toOADate() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_toOADate";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_number;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					double _result_ = (double)(_this.ToOADate()
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("ToOADate",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_DateTime_toFileTime : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_toFileTime() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_toFileTime";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					System.Int64 _result_ = _this.ToFileTime()
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("ToFileTime",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_DateTime_toFileTimeUtc : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_toFileTimeUtc() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_toFileTimeUtc";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					System.Int64 _result_ = _this.ToFileTimeUtc()
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("ToFileTimeUtc",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_DateTime_toLocalTime : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_toLocalTime() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_toLocalTime";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					System.DateTime _result_ = _this.ToLocalTime()
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("ToLocalTime",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_DateTime_toLongDateString : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_toLongDateString() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_toLongDateString";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					string _result_ = (string)(_this.ToLongDateString()
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("ToLongDateString",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_DateTime_toLongTimeString : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_toLongTimeString() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_toLongTimeString";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					string _result_ = (string)(_this.ToLongTimeString()
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("ToLongTimeString",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_DateTime_toShortDateString : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_toShortDateString() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_toShortDateString";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					string _result_ = (string)(_this.ToShortDateString()
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("ToShortDateString",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_DateTime_toShortTimeString : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_toShortTimeString() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_toShortTimeString";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					string _result_ = (string)(_this.ToShortTimeString()
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("ToShortTimeString",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_DateTime_toString___ : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_toString___() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_toString___";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					string _result_ = (string)(_this.ToString((System.String)arg0)
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("ToString",new Type[] {typeof(System.String)});;
				}
				return method;
			}

		}

		public class system_DateTime_toUniversalTime : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_toUniversalTime() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_toUniversalTime";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					System.DateTime _result_ = _this.ToUniversalTime()
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("ToUniversalTime",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class static_system_DateTime_tryParse : NativeConstParameterFunction
		{
			public static_system_DateTime_tryParse() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_tryParse";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					System.DateTime arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}
					ASRuntime.nativefuncs.linksystem.RefOutStore arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (ASRuntime.nativefuncs.linksystem.RefOutStore)_temp;
					}

					bool _result_ = System.DateTime.TryParse((System.String)arg0,out arg1)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					if (arg2 != null)
					{
						arg2.Clear();
					}

					if (arg2 != null)
					{
						arg2.SetValue(functionDefine.signature.parameters[1].name, arg1);
					}

					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_tryParse_ : NativeConstParameterFunction
		{
			public static_system_DateTime_tryParse_() : base(5)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_tryParse_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					System.IFormatProvider arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.IFormatProvider)_temp;
					}
					System.Globalization.DateTimeStyles arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Globalization.DateTimeStyles)_temp;
					}
					System.DateTime arg3;

					if (argements[3].rtType == RunTimeDataType.rt_null)
					{
						arg3 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[3]).value;
						arg3 = argObj.value;
					}
					ASRuntime.nativefuncs.linksystem.RefOutStore arg4;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[4],

							stackframe.player.linktypemapper.getLinkType(argements[4].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[4].rtType,

								functionDefine.signature.parameters[4].type
								);
							success = false;
							return;
						}
						arg4 = (ASRuntime.nativefuncs.linksystem.RefOutStore)_temp;
					}

					bool _result_ = System.DateTime.TryParse((System.String)arg0,(System.IFormatProvider)arg1,(System.Globalization.DateTimeStyles)arg2,out arg3)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					if (arg4 != null)
					{
						arg4.Clear();
					}

					if (arg4 != null)
					{
						arg4.SetValue(functionDefine.signature.parameters[3].name, arg3);
					}

					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_tryParseExact : NativeConstParameterFunction
		{
			public static_system_DateTime_tryParseExact() : base(6)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_tryParseExact";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);
					System.IFormatProvider arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.IFormatProvider)_temp;
					}
					System.Globalization.DateTimeStyles arg3;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[3],

							stackframe.player.linktypemapper.getLinkType(argements[3].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[3].rtType,

								functionDefine.signature.parameters[3].type
								);
							success = false;
							return;
						}
						arg3 = (System.Globalization.DateTimeStyles)_temp;
					}
					System.DateTime arg4;

					if (argements[4].rtType == RunTimeDataType.rt_null)
					{
						arg4 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[4]).value;
						arg4 = argObj.value;
					}
					ASRuntime.nativefuncs.linksystem.RefOutStore arg5;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[5],

							stackframe.player.linktypemapper.getLinkType(argements[5].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[5].rtType,

								functionDefine.signature.parameters[5].type
								);
							success = false;
							return;
						}
						arg5 = (ASRuntime.nativefuncs.linksystem.RefOutStore)_temp;
					}

					bool _result_ = System.DateTime.TryParseExact((System.String)arg0,(System.String)arg1,(System.IFormatProvider)arg2,(System.Globalization.DateTimeStyles)arg3,out arg4)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					if (arg5 != null)
					{
						arg5.Clear();
					}

					if (arg5 != null)
					{
						arg5.SetValue(functionDefine.signature.parameters[4].name, arg4);
					}

					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_tryParseExact_ : NativeConstParameterFunction
		{
			public static_system_DateTime_tryParseExact_() : base(6)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_tryParseExact_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					System.String[] arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.String[])_temp;
					}
					System.IFormatProvider arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.IFormatProvider)_temp;
					}
					System.Globalization.DateTimeStyles arg3;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[3],

							stackframe.player.linktypemapper.getLinkType(argements[3].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[3].rtType,

								functionDefine.signature.parameters[3].type
								);
							success = false;
							return;
						}
						arg3 = (System.Globalization.DateTimeStyles)_temp;
					}
					System.DateTime arg4;

					if (argements[4].rtType == RunTimeDataType.rt_null)
					{
						arg4 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[4]).value;
						arg4 = argObj.value;
					}
					ASRuntime.nativefuncs.linksystem.RefOutStore arg5;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[5],

							stackframe.player.linktypemapper.getLinkType(argements[5].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[5].rtType,

								functionDefine.signature.parameters[5].type
								);
							success = false;
							return;
						}
						arg5 = (ASRuntime.nativefuncs.linksystem.RefOutStore)_temp;
					}

					bool _result_ = System.DateTime.TryParseExact((System.String)arg0,(System.String[])arg1,(System.IFormatProvider)arg2,(System.Globalization.DateTimeStyles)arg3,out arg4)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					if (arg5 != null)
					{
						arg5.Clear();
					}

					if (arg5 != null)
					{
						arg5.SetValue(functionDefine.signature.parameters[4].name, arg4);
					}

					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_DateTime_getDateTimeFormats : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_getDateTimeFormats() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_getDateTimeFormats";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					object _result_ = _this.GetDateTimeFormats()
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("GetDateTimeFormats",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_DateTime_getDateTimeFormats_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_getDateTimeFormats_() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_getDateTimeFormats_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					System.IFormatProvider arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.IFormatProvider)_temp;
					}

					object _result_ = _this.GetDateTimeFormats((System.IFormatProvider)arg0)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("GetDateTimeFormats",new Type[] {typeof(System.IFormatProvider)});;
				}
				return method;
			}

		}

		public class system_DateTime_getDateTimeFormats__ : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_getDateTimeFormats__() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_getDateTimeFormats__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					System.Char arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Char);
					}
					else
					{
						LinkObj<System.Char> argObj = (LinkObj<System.Char>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					object _result_ = _this.GetDateTimeFormats((System.Char)arg0)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("GetDateTimeFormats",new Type[] {typeof(System.Char)});;
				}
				return method;
			}

		}

		public class system_DateTime_getDateTimeFormats___ : NativeConstParameterFunction,IMethodGetter
		{
			public system_DateTime_getDateTimeFormats___() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_DateTime_getDateTimeFormats___";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.DateTime _this =
					(System.DateTime)((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					System.Char arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Char);
					}
					else
					{
						LinkObj<System.Char> argObj = (LinkObj<System.Char>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.IFormatProvider arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.IFormatProvider)_temp;
					}

					object _result_ = _this.GetDateTimeFormats((System.Char)arg0,(System.IFormatProvider)arg1)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					((LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.DateTime).GetMethod("GetDateTimeFormats",new Type[] {typeof(System.Char),typeof(System.IFormatProvider)});;
				}
				return method;
			}

		}

		public class static_system_DateTime_op_Addition : NativeConstParameterFunction
		{
			public static_system_DateTime_op_Addition() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_op_Addition";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.DateTime arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.TimeSpan arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.TimeSpan);
					}
					else
					{
						LinkObj<System.TimeSpan> argObj = (LinkObj<System.TimeSpan>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					System.DateTime _result_ = arg0 + arg1					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_op_Subtraction : NativeConstParameterFunction
		{
			public static_system_DateTime_op_Subtraction() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_op_Subtraction";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.DateTime arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.TimeSpan arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.TimeSpan);
					}
					else
					{
						LinkObj<System.TimeSpan> argObj = (LinkObj<System.TimeSpan>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					System.DateTime _result_ = arg0 - arg1					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_op_Subtraction_ : NativeConstParameterFunction
		{
			public static_system_DateTime_op_Subtraction_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_op_Subtraction_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.DateTime arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.DateTime arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					System.TimeSpan _result_ = arg0 - arg1					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_op_Equality : NativeConstParameterFunction
		{
			public static_system_DateTime_op_Equality() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_op_Equality";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.DateTime arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.DateTime arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					bool _result_ = arg0 == arg1					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_op_Inequality : NativeConstParameterFunction
		{
			public static_system_DateTime_op_Inequality() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_op_Inequality";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.DateTime arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.DateTime arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					bool _result_ = arg0 != arg1					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_op_LessThan : NativeConstParameterFunction
		{
			public static_system_DateTime_op_LessThan() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_op_LessThan";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.DateTime arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.DateTime arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					bool _result_ = arg0 < arg1					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_op_LessThanOrEqual : NativeConstParameterFunction
		{
			public static_system_DateTime_op_LessThanOrEqual() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_op_LessThanOrEqual";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.DateTime arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.DateTime arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					bool _result_ = arg0 <= arg1					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_op_GreaterThan : NativeConstParameterFunction
		{
			public static_system_DateTime_op_GreaterThan() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_op_GreaterThan";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.DateTime arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.DateTime arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					bool _result_ = arg0 > arg1					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_DateTime_op_GreaterThanOrEqual : NativeConstParameterFunction
		{
			public static_system_DateTime_op_GreaterThanOrEqual() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_DateTime_op_GreaterThanOrEqual";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.DateTime arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.DateTime arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.DateTime);
					}
					else
					{
						LinkObj<System.DateTime> argObj = (LinkObj<System.DateTime>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					bool _result_ = arg0 >= arg1					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

	}
}
