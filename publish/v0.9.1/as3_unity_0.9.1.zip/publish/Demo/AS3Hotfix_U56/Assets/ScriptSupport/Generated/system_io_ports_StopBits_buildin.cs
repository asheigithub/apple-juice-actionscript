using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_io_ports_StopBits_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_io_ports_StopBits_creator", default(System.IO.Ports.StopBits)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_io_ports_StopBits_buildin.system_io_ports_StopBits_ctor","system_io_ports_StopBits_ctor");
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_io_ports_StopBits_None_getter",()=>{ return System.IO.Ports.StopBits.None;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_io_ports_StopBits_One_getter",()=>{ return System.IO.Ports.StopBits.One;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_io_ports_StopBits_Two_getter",()=>{ return System.IO.Ports.StopBits.Two;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_io_ports_StopBits_OnePointFive_getter",()=>{ return System.IO.Ports.StopBits.OnePointFive;}));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_io_ports_StopBits_buildin.system_io_ports_StopBits_operator_bitOr","system_io_ports_StopBits_operator_bitOr");
		}

		public class system_io_ports_StopBits_ctor : NativeFunctionBase
		{
			public system_io_ports_StopBits_ctor()
			{
				para = new List<RunTimeDataType>();
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_io_ports_StopBits_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override RunTimeValueBase execute(RunTimeValueBase thisObj, SLOT[] argements, object stackframe, out string errormessage, out int errorno)
			{
				errormessage = null; errorno = 0;
				return ASBinCode.rtData.rtUndefined.undefined;

			}
		}

		public class system_io_ports_StopBits_operator_bitOr : ASRuntime.nativefuncs.NativeConstParameterFunction
		{
			public system_io_ports_StopBits_operator_bitOr() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_io_ports_StopBits_operator_bitOr";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				System.IO.Ports.StopBits ts1;

				if (argements[0].rtType == RunTimeDataType.rt_null)
				{
					ts1 = default(System.IO.Ports.StopBits);
				}
				else
				{
					LinkObj<object> argObj = (LinkObj<object>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
					ts1 = (System.IO.Ports.StopBits)argObj.value;
				}

				System.IO.Ports.StopBits ts2;

				if (argements[1].rtType == RunTimeDataType.rt_null)
				{
					ts2 = default(System.IO.Ports.StopBits);
				}
				else
				{
					LinkObj<object> argObj = (LinkObj<object>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
					ts2 = (System.IO.Ports.StopBits)argObj.value;
				}

				((StackSlot)returnSlot).setLinkObjectValue(
					bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, ts1 | ts2);

				success = true;
			}
		}

	}
}
