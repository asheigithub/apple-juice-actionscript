using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_security_cryptography_x509certificates_X509FindType_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_security_cryptography_x509certificates_X509FindType_creator", default(System.Security.Cryptography.X509Certificates.X509FindType)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509FindType_buildin.system_security_cryptography_x509certificates_X509FindType_ctor","system_security_cryptography_x509certificates_X509FindType_ctor");
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509FindType_FindByThumbprint_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509FindType.FindByThumbprint;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509FindType_FindBySubjectName_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509FindType.FindBySubjectName;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509FindType_FindBySubjectDistinguishedName_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509FindType.FindBySubjectDistinguishedName;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509FindType_FindByIssuerName_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509FindType.FindByIssuerName;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509FindType_FindByIssuerDistinguishedName_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509FindType.FindByIssuerDistinguishedName;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509FindType_FindBySerialNumber_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509FindType.FindBySerialNumber;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509FindType_FindByTimeValid_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509FindType.FindByTimeValid;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509FindType_FindByTimeNotYetValid_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509FindType.FindByTimeNotYetValid;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509FindType_FindByTimeExpired_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509FindType.FindByTimeExpired;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509FindType_FindByTemplateName_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509FindType.FindByTemplateName;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509FindType_FindByApplicationPolicy_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509FindType.FindByApplicationPolicy;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509FindType_FindByCertificatePolicy_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509FindType.FindByCertificatePolicy;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509FindType_FindByExtension_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509FindType.FindByExtension;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509FindType_FindByKeyUsage_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509FindType.FindByKeyUsage;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509FindType_FindBySubjectKeyIdentifier_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509FindType.FindBySubjectKeyIdentifier;}));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509FindType_buildin.system_security_cryptography_x509certificates_X509FindType_operator_bitOr","system_security_cryptography_x509certificates_X509FindType_operator_bitOr");
		}

		public class system_security_cryptography_x509certificates_X509FindType_ctor : NativeFunctionBase
		{
			public system_security_cryptography_x509certificates_X509FindType_ctor()
			{
				para = new List<RunTimeDataType>();
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509FindType_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override RunTimeValueBase execute(RunTimeValueBase thisObj, SLOT[] argements, object stackframe, out string errormessage, out int errorno)
			{
				errormessage = null; errorno = 0;
				return ASBinCode.rtData.rtUndefined.undefined;

			}
		}

		public class system_security_cryptography_x509certificates_X509FindType_operator_bitOr : ASRuntime.nativefuncs.NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509FindType_operator_bitOr() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509FindType_operator_bitOr";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				System.Security.Cryptography.X509Certificates.X509FindType ts1;

				if (argements[0].rtType == RunTimeDataType.rt_null)
				{
					ts1 = default(System.Security.Cryptography.X509Certificates.X509FindType);
				}
				else
				{
					LinkObj<object> argObj = (LinkObj<object>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
					ts1 = (System.Security.Cryptography.X509Certificates.X509FindType)argObj.value;
				}

				System.Security.Cryptography.X509Certificates.X509FindType ts2;

				if (argements[1].rtType == RunTimeDataType.rt_null)
				{
					ts2 = default(System.Security.Cryptography.X509Certificates.X509FindType);
				}
				else
				{
					LinkObj<object> argObj = (LinkObj<object>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
					ts2 = (System.Security.Cryptography.X509Certificates.X509FindType)argObj.value;
				}

				((StackSlot)returnSlot).setLinkObjectValue(
					bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, ts1 | ts2);

				success = true;
			}
		}

	}
}
