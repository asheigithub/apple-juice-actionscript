using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_io_ports_SerialPinChange_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_io_ports_SerialPinChange_creator", default(System.IO.Ports.SerialPinChange)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_io_ports_SerialPinChange_buildin.system_io_ports_SerialPinChange_ctor","system_io_ports_SerialPinChange_ctor");
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_io_ports_SerialPinChange_CtsChanged_getter",()=>{ return System.IO.Ports.SerialPinChange.CtsChanged;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_io_ports_SerialPinChange_DsrChanged_getter",()=>{ return System.IO.Ports.SerialPinChange.DsrChanged;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_io_ports_SerialPinChange_CDChanged_getter",()=>{ return System.IO.Ports.SerialPinChange.CDChanged;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_io_ports_SerialPinChange_Break_getter",()=>{ return System.IO.Ports.SerialPinChange.Break;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_io_ports_SerialPinChange_Ring_getter",()=>{ return System.IO.Ports.SerialPinChange.Ring;}));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_io_ports_SerialPinChange_buildin.system_io_ports_SerialPinChange_operator_bitOr","system_io_ports_SerialPinChange_operator_bitOr");
		}

		public class system_io_ports_SerialPinChange_ctor : NativeFunctionBase
		{
			public system_io_ports_SerialPinChange_ctor()
			{
				para = new List<RunTimeDataType>();
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_io_ports_SerialPinChange_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override RunTimeValueBase execute(RunTimeValueBase thisObj, SLOT[] argements, object stackframe, out string errormessage, out int errorno)
			{
				errormessage = null; errorno = 0;
				return ASBinCode.rtData.rtUndefined.undefined;

			}
		}

		public class system_io_ports_SerialPinChange_operator_bitOr : ASRuntime.nativefuncs.NativeConstParameterFunction
		{
			public system_io_ports_SerialPinChange_operator_bitOr() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_io_ports_SerialPinChange_operator_bitOr";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				System.IO.Ports.SerialPinChange ts1;

				if (argements[0].rtType == RunTimeDataType.rt_null)
				{
					ts1 = default(System.IO.Ports.SerialPinChange);
				}
				else
				{
					LinkObj<object> argObj = (LinkObj<object>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
					ts1 = (System.IO.Ports.SerialPinChange)argObj.value;
				}

				System.IO.Ports.SerialPinChange ts2;

				if (argements[1].rtType == RunTimeDataType.rt_null)
				{
					ts2 = default(System.IO.Ports.SerialPinChange);
				}
				else
				{
					LinkObj<object> argObj = (LinkObj<object>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
					ts2 = (System.IO.Ports.SerialPinChange)argObj.value;
				}

				((StackSlot)returnSlot).setLinkObjectValue(
					bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, ts1 | ts2);

				success = true;
			}
		}

	}
}
