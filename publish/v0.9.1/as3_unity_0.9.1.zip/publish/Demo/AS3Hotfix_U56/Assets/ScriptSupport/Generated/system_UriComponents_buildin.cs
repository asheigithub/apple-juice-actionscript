using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_UriComponents_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_UriComponents_creator", default(System.UriComponents)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_UriComponents_buildin.system_UriComponents_ctor","system_UriComponents_ctor");
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_UriComponents_Scheme_getter",()=>{ return System.UriComponents.Scheme;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_UriComponents_UserInfo_getter",()=>{ return System.UriComponents.UserInfo;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_UriComponents_Host_getter",()=>{ return System.UriComponents.Host;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_UriComponents_Port_getter",()=>{ return System.UriComponents.Port;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_UriComponents_Path_getter",()=>{ return System.UriComponents.Path;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_UriComponents_Query_getter",()=>{ return System.UriComponents.Query;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_UriComponents_Fragment_getter",()=>{ return System.UriComponents.Fragment;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_UriComponents_StrongPort_getter",()=>{ return System.UriComponents.StrongPort;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_UriComponents_KeepDelimiter_getter",()=>{ return System.UriComponents.KeepDelimiter;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_UriComponents_HostAndPort_getter",()=>{ return System.UriComponents.HostAndPort;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_UriComponents_StrongAuthority_getter",()=>{ return System.UriComponents.StrongAuthority;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_UriComponents_AbsoluteUri_getter",()=>{ return System.UriComponents.AbsoluteUri;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_UriComponents_PathAndQuery_getter",()=>{ return System.UriComponents.PathAndQuery;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_UriComponents_HttpRequestUrl_getter",()=>{ return System.UriComponents.HttpRequestUrl;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_UriComponents_SchemeAndServer_getter",()=>{ return System.UriComponents.SchemeAndServer;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_UriComponents_SerializationInfoString_getter",()=>{ return System.UriComponents.SerializationInfoString;}));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_UriComponents_buildin.system_UriComponents_operator_bitOr","system_UriComponents_operator_bitOr");
		}

		public class system_UriComponents_ctor : NativeFunctionBase
		{
			public system_UriComponents_ctor()
			{
				para = new List<RunTimeDataType>();
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_UriComponents_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override RunTimeValueBase execute(RunTimeValueBase thisObj, SLOT[] argements, object stackframe, out string errormessage, out int errorno)
			{
				errormessage = null; errorno = 0;
				return ASBinCode.rtData.rtUndefined.undefined;

			}
		}

		public class system_UriComponents_operator_bitOr : ASRuntime.nativefuncs.NativeConstParameterFunction
		{
			public system_UriComponents_operator_bitOr() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_UriComponents_operator_bitOr";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				System.UriComponents ts1;

				if (argements[0].rtType == RunTimeDataType.rt_null)
				{
					ts1 = default(System.UriComponents);
				}
				else
				{
					LinkObj<object> argObj = (LinkObj<object>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
					ts1 = (System.UriComponents)argObj.value;
				}

				System.UriComponents ts2;

				if (argements[1].rtType == RunTimeDataType.rt_null)
				{
					ts2 = default(System.UriComponents);
				}
				else
				{
					LinkObj<object> argObj = (LinkObj<object>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
					ts2 = (System.UriComponents)argObj.value;
				}

				((StackSlot)returnSlot).setLinkObjectValue(
					bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, ts1 | ts2);

				success = true;
			}
		}

	}
}
