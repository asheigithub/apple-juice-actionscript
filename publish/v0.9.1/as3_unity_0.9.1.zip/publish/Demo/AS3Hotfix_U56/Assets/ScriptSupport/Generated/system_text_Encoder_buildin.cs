using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_text_Encoder_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_text_Encoder_creator", default(System.Text.Encoder)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_Encoder_buildin.system_text_Encoder_get_Fallback","system_text_Encoder_get_Fallback");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_Encoder_buildin.system_text_Encoder_set_Fallback","system_text_Encoder_set_Fallback");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_Encoder_buildin.system_text_Encoder_get_FallbackBuffer","system_text_Encoder_get_FallbackBuffer");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_Encoder_buildin.system_text_Encoder_reset","system_text_Encoder_reset");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_Encoder_buildin.system_text_Encoder_getByteCount","system_text_Encoder_getByteCount");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_Encoder_buildin.system_text_Encoder_getBytes","system_text_Encoder_getBytes");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_Encoder_buildin.system_text_Encoder_convert","system_text_Encoder_convert");
		}


		public class system_text_Encoder_get_Fallback : NativeConstParameterFunction
		{
			public system_text_Encoder_get_Fallback() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_Encoder_get_Fallback";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.Encoder _this =
					(System.Text.Encoder)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.Fallback
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_text_Encoder_set_Fallback : NativeConstParameterFunction
		{
			public system_text_Encoder_set_Fallback() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_Encoder_set_Fallback";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.Encoder _this =
					(System.Text.Encoder)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Text.EncoderFallback arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Text.EncoderFallback)_temp;
					}

					_this.Fallback = (System.Text.EncoderFallback)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_text_Encoder_get_FallbackBuffer : NativeConstParameterFunction
		{
			public system_text_Encoder_get_FallbackBuffer() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_Encoder_get_FallbackBuffer";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.Encoder _this =
					(System.Text.Encoder)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.FallbackBuffer
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_text_Encoder_reset : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_Encoder_reset() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_Encoder_reset";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.Encoder _this =
					(System.Text.Encoder)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					_this.Reset()
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.Encoder).GetMethod("Reset",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_text_Encoder_getByteCount : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_Encoder_getByteCount() : base(4)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_boolean);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_Encoder_getByteCount";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.Encoder _this =
					(System.Text.Encoder)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Char[] arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Char[])_temp;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					int arg2 = TypeConverter.ConvertToInt(argements[2]);
					bool arg3 = TypeConverter.ConvertToBoolean(argements[3], stackframe, token).value;

					int _result_ = (int)(_this.GetByteCount((System.Char[])arg0,(System.Int32)arg1,(System.Int32)arg2,(System.Boolean)arg3)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.Encoder).GetMethod("GetByteCount",new Type[] {typeof(System.Char[]),typeof(System.Int32),typeof(System.Int32),typeof(System.Boolean)});;
				}
				return method;
			}

		}

		public class system_text_Encoder_getBytes : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_Encoder_getBytes() : base(6)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_boolean);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_Encoder_getBytes";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.Encoder _this =
					(System.Text.Encoder)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Char[] arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Char[])_temp;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					int arg2 = TypeConverter.ConvertToInt(argements[2]);
					System.Byte[] arg3;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[3],

							stackframe.player.linktypemapper.getLinkType(argements[3].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[3].rtType,

								functionDefine.signature.parameters[3].type
								);
							success = false;
							return;
						}
						arg3 = (System.Byte[])_temp;
					}
					int arg4 = TypeConverter.ConvertToInt(argements[4]);
					bool arg5 = TypeConverter.ConvertToBoolean(argements[5], stackframe, token).value;

					int _result_ = (int)(_this.GetBytes((System.Char[])arg0,(System.Int32)arg1,(System.Int32)arg2,(System.Byte[])arg3,(System.Int32)arg4,(System.Boolean)arg5)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.Encoder).GetMethod("GetBytes",new Type[] {typeof(System.Char[]),typeof(System.Int32),typeof(System.Int32),typeof(System.Byte[]),typeof(System.Int32),typeof(System.Boolean)});;
				}
				return method;
			}

		}

		public class system_text_Encoder_convert : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_Encoder_convert() : base(11)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_boolean);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_boolean);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_Encoder_convert";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.Encoder _this =
					(System.Text.Encoder)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Char[] arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Char[])_temp;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					int arg2 = TypeConverter.ConvertToInt(argements[2]);
					System.Byte[] arg3;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[3],

							stackframe.player.linktypemapper.getLinkType(argements[3].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[3].rtType,

								functionDefine.signature.parameters[3].type
								);
							success = false;
							return;
						}
						arg3 = (System.Byte[])_temp;
					}
					int arg4 = TypeConverter.ConvertToInt(argements[4]);
					int arg5 = TypeConverter.ConvertToInt(argements[5]);
					bool arg6 = TypeConverter.ConvertToBoolean(argements[6], stackframe, token).value;
					int arg7 = TypeConverter.ConvertToInt(argements[7]);
					int arg8 = TypeConverter.ConvertToInt(argements[8]);
					bool arg9 = TypeConverter.ConvertToBoolean(argements[9], stackframe, token).value;
					ASRuntime.nativefuncs.linksystem.RefOutStore arg10;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[10],

							stackframe.player.linktypemapper.getLinkType(argements[10].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[10].rtType,

								functionDefine.signature.parameters[10].type
								);
							success = false;
							return;
						}
						arg10 = (ASRuntime.nativefuncs.linksystem.RefOutStore)_temp;
					}

					_this.Convert((System.Char[])arg0,(System.Int32)arg1,(System.Int32)arg2,(System.Byte[])arg3,(System.Int32)arg4,(System.Int32)arg5,(System.Boolean)arg6,out arg7,out arg8,out arg9)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					if (arg10 != null)
					{
						arg10.Clear();
					}

					if (arg10 != null)
					{
						arg10.SetValue(functionDefine.signature.parameters[7].name, arg7);
					}

					if (arg10 != null)
					{
						arg10.SetValue(functionDefine.signature.parameters[8].name, arg8);
					}

					if (arg10 != null)
					{
						arg10.SetValue(functionDefine.signature.parameters[9].name, arg9);
					}

					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.Encoder).GetMethod("Convert",new Type[] {typeof(System.Char[]),typeof(System.Int32),typeof(System.Int32),typeof(System.Byte[]),typeof(System.Int32),typeof(System.Int32),typeof(System.Boolean),typeof(System.Int32),typeof(System.Int32),typeof(System.Boolean)});;
				}
				return method;
			}

		}

	}
}
