using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class unityengine_ai_NavMeshCollectGeometry_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("unityengine_ai_NavMeshCollectGeometry_creator", default(UnityEngine.AI.NavMeshCollectGeometry)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshCollectGeometry_buildin.unityengine_ai_NavMeshCollectGeometry_ctor","unityengine_ai_NavMeshCollectGeometry_ctor");
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("unityengine_ai_NavMeshCollectGeometry_RenderMeshes_getter",()=>{ return UnityEngine.AI.NavMeshCollectGeometry.RenderMeshes;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("unityengine_ai_NavMeshCollectGeometry_PhysicsColliders_getter",()=>{ return UnityEngine.AI.NavMeshCollectGeometry.PhysicsColliders;}));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshCollectGeometry_buildin.unityengine_ai_NavMeshCollectGeometry_operator_bitOr","unityengine_ai_NavMeshCollectGeometry_operator_bitOr");
		}

		public class unityengine_ai_NavMeshCollectGeometry_ctor : NativeFunctionBase
		{
			public unityengine_ai_NavMeshCollectGeometry_ctor()
			{
				para = new List<RunTimeDataType>();
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshCollectGeometry_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override RunTimeValueBase execute(RunTimeValueBase thisObj, SLOT[] argements, object stackframe, out string errormessage, out int errorno)
			{
				errormessage = null; errorno = 0;
				return ASBinCode.rtData.rtUndefined.undefined;

			}
		}

		public class unityengine_ai_NavMeshCollectGeometry_operator_bitOr : ASRuntime.nativefuncs.NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshCollectGeometry_operator_bitOr() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshCollectGeometry_operator_bitOr";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				UnityEngine.AI.NavMeshCollectGeometry ts1;

				if (argements[0].rtType == RunTimeDataType.rt_null)
				{
					ts1 = default(UnityEngine.AI.NavMeshCollectGeometry);
				}
				else
				{
					LinkObj<object> argObj = (LinkObj<object>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
					ts1 = (UnityEngine.AI.NavMeshCollectGeometry)argObj.value;
				}

				UnityEngine.AI.NavMeshCollectGeometry ts2;

				if (argements[1].rtType == RunTimeDataType.rt_null)
				{
					ts2 = default(UnityEngine.AI.NavMeshCollectGeometry);
				}
				else
				{
					LinkObj<object> argObj = (LinkObj<object>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
					ts2 = (UnityEngine.AI.NavMeshCollectGeometry)argObj.value;
				}

				((StackSlot)returnSlot).setLinkObjectValue(
					bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, ts1 | ts2);

				success = true;
			}
		}

	}
}
