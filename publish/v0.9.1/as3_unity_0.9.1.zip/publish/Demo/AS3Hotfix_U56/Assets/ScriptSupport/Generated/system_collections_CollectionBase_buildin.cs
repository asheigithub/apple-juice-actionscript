using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_collections_CollectionBase_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_collections_CollectionBase_creator", default(System.Collections.CollectionBase)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_CollectionBase_buildin.system_collections_CollectionBase_get_Capacity","system_collections_CollectionBase_get_Capacity");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_CollectionBase_buildin.system_collections_CollectionBase_set_Capacity","system_collections_CollectionBase_set_Capacity");
		}


		public class system_collections_CollectionBase_get_Capacity : NativeConstParameterFunction
		{
			public system_collections_CollectionBase_get_Capacity() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_CollectionBase_get_Capacity";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.CollectionBase _this =
					(System.Collections.CollectionBase)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					int _result_ = (int)(_this.Capacity
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_CollectionBase_set_Capacity : NativeConstParameterFunction
		{
			public system_collections_CollectionBase_set_Capacity() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_CollectionBase_set_Capacity";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.CollectionBase _this =
					(System.Collections.CollectionBase)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					_this.Capacity = (System.Int32)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

	}
}
