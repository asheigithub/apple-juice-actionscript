using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_text_EncoderFallbackBuffer_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_text_EncoderFallbackBuffer_creator", default(System.Text.EncoderFallbackBuffer)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_EncoderFallbackBuffer_buildin.system_text_EncoderFallbackBuffer_fallback","system_text_EncoderFallbackBuffer_fallback");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_EncoderFallbackBuffer_buildin.system_text_EncoderFallbackBuffer_fallback_","system_text_EncoderFallbackBuffer_fallback_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_EncoderFallbackBuffer_buildin.system_text_EncoderFallbackBuffer_getNextChar","system_text_EncoderFallbackBuffer_getNextChar");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_EncoderFallbackBuffer_buildin.system_text_EncoderFallbackBuffer_movePrevious","system_text_EncoderFallbackBuffer_movePrevious");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_EncoderFallbackBuffer_buildin.system_text_EncoderFallbackBuffer_get_Remaining","system_text_EncoderFallbackBuffer_get_Remaining");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_EncoderFallbackBuffer_buildin.system_text_EncoderFallbackBuffer_reset","system_text_EncoderFallbackBuffer_reset");
		}


		public class system_text_EncoderFallbackBuffer_fallback : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_EncoderFallbackBuffer_fallback() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_EncoderFallbackBuffer_fallback";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.EncoderFallbackBuffer _this =
					(System.Text.EncoderFallbackBuffer)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Char arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Char);
					}
					else
					{
						LinkObj<System.Char> argObj = (LinkObj<System.Char>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					bool _result_ = _this.Fallback((System.Char)arg0,(System.Int32)arg1)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.EncoderFallbackBuffer).GetMethod("Fallback",new Type[] {typeof(System.Char),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_text_EncoderFallbackBuffer_fallback_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_EncoderFallbackBuffer_fallback_() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_EncoderFallbackBuffer_fallback_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.EncoderFallbackBuffer _this =
					(System.Text.EncoderFallbackBuffer)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Char arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Char);
					}
					else
					{
						LinkObj<System.Char> argObj = (LinkObj<System.Char>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.Char arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Char);
					}
					else
					{
						LinkObj<System.Char> argObj = (LinkObj<System.Char>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}
					int arg2 = TypeConverter.ConvertToInt(argements[2]);

					bool _result_ = _this.Fallback((System.Char)arg0,(System.Char)arg1,(System.Int32)arg2)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.EncoderFallbackBuffer).GetMethod("Fallback",new Type[] {typeof(System.Char),typeof(System.Char),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_text_EncoderFallbackBuffer_getNextChar : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_EncoderFallbackBuffer_getNextChar() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_EncoderFallbackBuffer_getNextChar";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.EncoderFallbackBuffer _this =
					(System.Text.EncoderFallbackBuffer)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					System.Char _result_ = _this.GetNextChar()
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.EncoderFallbackBuffer).GetMethod("GetNextChar",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_text_EncoderFallbackBuffer_movePrevious : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_EncoderFallbackBuffer_movePrevious() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_EncoderFallbackBuffer_movePrevious";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.EncoderFallbackBuffer _this =
					(System.Text.EncoderFallbackBuffer)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					bool _result_ = _this.MovePrevious()
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.EncoderFallbackBuffer).GetMethod("MovePrevious",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_text_EncoderFallbackBuffer_get_Remaining : NativeConstParameterFunction
		{
			public system_text_EncoderFallbackBuffer_get_Remaining() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_EncoderFallbackBuffer_get_Remaining";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.EncoderFallbackBuffer _this =
					(System.Text.EncoderFallbackBuffer)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					int _result_ = (int)(_this.Remaining
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_text_EncoderFallbackBuffer_reset : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_EncoderFallbackBuffer_reset() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_EncoderFallbackBuffer_reset";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.EncoderFallbackBuffer _this =
					(System.Text.EncoderFallbackBuffer)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					_this.Reset()
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.EncoderFallbackBuffer).GetMethod("Reset",Type.EmptyTypes);;
				}
				return method;
			}

		}

	}
}
