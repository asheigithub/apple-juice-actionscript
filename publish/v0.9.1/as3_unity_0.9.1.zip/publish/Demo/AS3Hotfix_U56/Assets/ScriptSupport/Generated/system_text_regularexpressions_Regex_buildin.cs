using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_text_regularexpressions_Regex_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_text_regularexpressions_Regex_creator", default(System.Text.RegularExpressions.Regex)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_constructor_","system_text_regularexpressions_Regex_constructor_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_ctor","system_text_regularexpressions_Regex_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin._system_text_regularexpressions_RegexAdapter_ctor","_system_text_regularexpressions_RegexAdapter_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.static_system_text_regularexpressions_Regex_escape","static_system_text_regularexpressions_Regex_escape");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.static_system_text_regularexpressions_Regex_unescape","static_system_text_regularexpressions_Regex_unescape");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.static_system_text_regularexpressions_Regex_isMatch","static_system_text_regularexpressions_Regex_isMatch");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.static_system_text_regularexpressions_Regex_isMatch_","static_system_text_regularexpressions_Regex_isMatch_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.static_system_text_regularexpressions_Regex_match","static_system_text_regularexpressions_Regex_match");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.static_system_text_regularexpressions_Regex_match_","static_system_text_regularexpressions_Regex_match_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.static_system_text_regularexpressions_Regex_matches","static_system_text_regularexpressions_Regex_matches");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.static_system_text_regularexpressions_Regex_matches_","static_system_text_regularexpressions_Regex_matches_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.static_system_text_regularexpressions_Regex_replace","static_system_text_regularexpressions_Regex_replace");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.static_system_text_regularexpressions_Regex_replace_","static_system_text_regularexpressions_Regex_replace_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.static_system_text_regularexpressions_Regex_replace__","static_system_text_regularexpressions_Regex_replace__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.static_system_text_regularexpressions_Regex_replace___","static_system_text_regularexpressions_Regex_replace___");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.static_system_text_regularexpressions_Regex_split","static_system_text_regularexpressions_Regex_split");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.static_system_text_regularexpressions_Regex_split_","static_system_text_regularexpressions_Regex_split_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.static_system_text_regularexpressions_Regex_get_CacheSize","static_system_text_regularexpressions_Regex_get_CacheSize");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.static_system_text_regularexpressions_Regex_set_CacheSize","static_system_text_regularexpressions_Regex_set_CacheSize");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_get_Options","system_text_regularexpressions_Regex_get_Options");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_get_RightToLeft","system_text_regularexpressions_Regex_get_RightToLeft");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_getGroupNames","system_text_regularexpressions_Regex_getGroupNames");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_getGroupNumbers","system_text_regularexpressions_Regex_getGroupNumbers");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_groupNameFromNumber","system_text_regularexpressions_Regex_groupNameFromNumber");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_groupNumberFromName","system_text_regularexpressions_Regex_groupNumberFromName");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_isMatch","system_text_regularexpressions_Regex_isMatch");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_isMatch_","system_text_regularexpressions_Regex_isMatch_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_match","system_text_regularexpressions_Regex_match");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_match_","system_text_regularexpressions_Regex_match_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_match__","system_text_regularexpressions_Regex_match__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_matches","system_text_regularexpressions_Regex_matches");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_matches_","system_text_regularexpressions_Regex_matches_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_replace","system_text_regularexpressions_Regex_replace");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_replace_","system_text_regularexpressions_Regex_replace_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_replace__","system_text_regularexpressions_Regex_replace__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_replace___","system_text_regularexpressions_Regex_replace___");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_replace____","system_text_regularexpressions_Regex_replace____");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_replace_____","system_text_regularexpressions_Regex_replace_____");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_split","system_text_regularexpressions_Regex_split");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_split_","system_text_regularexpressions_Regex_split_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_Regex_buildin.system_text_regularexpressions_Regex_split__","system_text_regularexpressions_Regex_split__");
		}

		public class system_text_regularexpressions_RegexAdapter :System.Text.RegularExpressions.Regex ,ASRuntime.ICrossExtendAdapter
		{

			public ASBinCode.rtti.Class AS3Class { get { return typeclass; } }

			public ASBinCode.rtData.rtObjectBase AS3Object { get { return bindAS3Object; } }

			protected Player player;
			private Class typeclass;
			private ASBinCode.rtData.rtObjectBase bindAS3Object;

			public void SetAS3RuntimeEnvironment(Player player, Class typeclass, ASBinCode.rtData.rtObjectBase bindAS3Object)
			{
				this.player = player;
				this.typeclass = typeclass;
				this.bindAS3Object = bindAS3Object;
			}

			public system_text_regularexpressions_RegexAdapter(System.String pattern):base(pattern){}

		}
		public class system_text_regularexpressions_Regex_constructor_ : NativeConstParameterFunction
		{
			public system_text_regularexpressions_Regex_constructor_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_constructor_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					System.Text.RegularExpressions.RegexOptions arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Text.RegularExpressions.RegexOptions)_temp;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Text.RegularExpressions.Regex((System.String)arg0,(System.Text.RegularExpressions.RegexOptions)arg1));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_text_regularexpressions_Regex_ctor : NativeConstParameterFunction
		{
			public system_text_regularexpressions_Regex_ctor() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new System.Text.RegularExpressions.Regex((System.String)arg0);
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class _system_text_regularexpressions_RegexAdapter_ctor : NativeConstParameterFunction,ICrossExtendAdapterCreator
		{
			public _system_text_regularexpressions_RegexAdapter_ctor() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public Type GetAdapterType()
			{
				return typeof(system_text_regularexpressions_RegexAdapter);
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "_system_text_regularexpressions_RegexAdapter_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new system_text_regularexpressions_RegexAdapter((System.String)arg0);

					((ICrossExtendAdapter)((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value)
						.SetAS3RuntimeEnvironment(stackframe.player, ((ASBinCode.rtData.rtObjectBase)thisObj).value._class, (ASBinCode.rtData.rtObjectBase)thisObj);


					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_text_regularexpressions_Regex_escape : NativeConstParameterFunction
		{
			public static_system_text_regularexpressions_Regex_escape() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_text_regularexpressions_Regex_escape";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					string _result_ = (string)(System.Text.RegularExpressions.Regex.Escape((System.String)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_text_regularexpressions_Regex_unescape : NativeConstParameterFunction
		{
			public static_system_text_regularexpressions_Regex_unescape() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_text_regularexpressions_Regex_unescape";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					string _result_ = (string)(System.Text.RegularExpressions.Regex.Unescape((System.String)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_text_regularexpressions_Regex_isMatch : NativeConstParameterFunction
		{
			public static_system_text_regularexpressions_Regex_isMatch() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_text_regularexpressions_Regex_isMatch";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);

					bool _result_ = System.Text.RegularExpressions.Regex.IsMatch((System.String)arg0,(System.String)arg1)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_text_regularexpressions_Regex_isMatch_ : NativeConstParameterFunction
		{
			public static_system_text_regularexpressions_Regex_isMatch_() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_text_regularexpressions_Regex_isMatch_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);
					System.Text.RegularExpressions.RegexOptions arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Text.RegularExpressions.RegexOptions)_temp;
					}

					bool _result_ = System.Text.RegularExpressions.Regex.IsMatch((System.String)arg0,(System.String)arg1,(System.Text.RegularExpressions.RegexOptions)arg2)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_text_regularexpressions_Regex_match : NativeConstParameterFunction
		{
			public static_system_text_regularexpressions_Regex_match() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_text_regularexpressions_Regex_match";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);

					object _result_ = System.Text.RegularExpressions.Regex.Match((System.String)arg0,(System.String)arg1)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_text_regularexpressions_Regex_match_ : NativeConstParameterFunction
		{
			public static_system_text_regularexpressions_Regex_match_() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_text_regularexpressions_Regex_match_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);
					System.Text.RegularExpressions.RegexOptions arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Text.RegularExpressions.RegexOptions)_temp;
					}

					object _result_ = System.Text.RegularExpressions.Regex.Match((System.String)arg0,(System.String)arg1,(System.Text.RegularExpressions.RegexOptions)arg2)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_text_regularexpressions_Regex_matches : NativeConstParameterFunction
		{
			public static_system_text_regularexpressions_Regex_matches() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_text_regularexpressions_Regex_matches";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);

					object _result_ = System.Text.RegularExpressions.Regex.Matches((System.String)arg0,(System.String)arg1)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_text_regularexpressions_Regex_matches_ : NativeConstParameterFunction
		{
			public static_system_text_regularexpressions_Regex_matches_() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_text_regularexpressions_Regex_matches_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);
					System.Text.RegularExpressions.RegexOptions arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Text.RegularExpressions.RegexOptions)_temp;
					}

					object _result_ = System.Text.RegularExpressions.Regex.Matches((System.String)arg0,(System.String)arg1,(System.Text.RegularExpressions.RegexOptions)arg2)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_text_regularexpressions_Regex_replace : NativeConstParameterFunction
		{
			public static_system_text_regularexpressions_Regex_replace() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_text_regularexpressions_Regex_replace";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);
					System.Text.RegularExpressions.MatchEvaluator arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Text.RegularExpressions.MatchEvaluator)_temp;
					}

					string _result_ = (string)(System.Text.RegularExpressions.Regex.Replace((System.String)arg0,(System.String)arg1,(System.Text.RegularExpressions.MatchEvaluator)arg2)
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_text_regularexpressions_Regex_replace_ : NativeConstParameterFunction
		{
			public static_system_text_regularexpressions_Regex_replace_() : base(4)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_text_regularexpressions_Regex_replace_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);
					System.Text.RegularExpressions.MatchEvaluator arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Text.RegularExpressions.MatchEvaluator)_temp;
					}
					System.Text.RegularExpressions.RegexOptions arg3;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[3],

							stackframe.player.linktypemapper.getLinkType(argements[3].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[3].rtType,

								functionDefine.signature.parameters[3].type
								);
							success = false;
							return;
						}
						arg3 = (System.Text.RegularExpressions.RegexOptions)_temp;
					}

					string _result_ = (string)(System.Text.RegularExpressions.Regex.Replace((System.String)arg0,(System.String)arg1,(System.Text.RegularExpressions.MatchEvaluator)arg2,(System.Text.RegularExpressions.RegexOptions)arg3)
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_text_regularexpressions_Regex_replace__ : NativeConstParameterFunction
		{
			public static_system_text_regularexpressions_Regex_replace__() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_text_regularexpressions_Regex_replace__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);
					string arg2 = TypeConverter.ConvertToString(argements[2], stackframe, token);

					string _result_ = (string)(System.Text.RegularExpressions.Regex.Replace((System.String)arg0,(System.String)arg1,(System.String)arg2)
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_text_regularexpressions_Regex_replace___ : NativeConstParameterFunction
		{
			public static_system_text_regularexpressions_Regex_replace___() : base(4)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_text_regularexpressions_Regex_replace___";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);
					string arg2 = TypeConverter.ConvertToString(argements[2], stackframe, token);
					System.Text.RegularExpressions.RegexOptions arg3;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[3],

							stackframe.player.linktypemapper.getLinkType(argements[3].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[3].rtType,

								functionDefine.signature.parameters[3].type
								);
							success = false;
							return;
						}
						arg3 = (System.Text.RegularExpressions.RegexOptions)_temp;
					}

					string _result_ = (string)(System.Text.RegularExpressions.Regex.Replace((System.String)arg0,(System.String)arg1,(System.String)arg2,(System.Text.RegularExpressions.RegexOptions)arg3)
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_text_regularexpressions_Regex_split : NativeConstParameterFunction
		{
			public static_system_text_regularexpressions_Regex_split() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_text_regularexpressions_Regex_split";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);

					object _result_ = System.Text.RegularExpressions.Regex.Split((System.String)arg0,(System.String)arg1)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_text_regularexpressions_Regex_split_ : NativeConstParameterFunction
		{
			public static_system_text_regularexpressions_Regex_split_() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_text_regularexpressions_Regex_split_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);
					System.Text.RegularExpressions.RegexOptions arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Text.RegularExpressions.RegexOptions)_temp;
					}

					object _result_ = System.Text.RegularExpressions.Regex.Split((System.String)arg0,(System.String)arg1,(System.Text.RegularExpressions.RegexOptions)arg2)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_text_regularexpressions_Regex_get_CacheSize : NativeConstParameterFunction
		{
			public static_system_text_regularexpressions_Regex_get_CacheSize() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_text_regularexpressions_Regex_get_CacheSize";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{

					int _result_ = (int)(System.Text.RegularExpressions.Regex.CacheSize
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_text_regularexpressions_Regex_set_CacheSize : NativeConstParameterFunction
		{
			public static_system_text_regularexpressions_Regex_set_CacheSize() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_text_regularexpressions_Regex_set_CacheSize";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					System.Text.RegularExpressions.Regex.CacheSize = (System.Int32)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_text_regularexpressions_Regex_get_Options : NativeConstParameterFunction
		{
			public system_text_regularexpressions_Regex_get_Options() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_get_Options";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.Regex _this =
					(System.Text.RegularExpressions.Regex)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					System.Text.RegularExpressions.RegexOptions _result_ = _this.Options
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_text_regularexpressions_Regex_get_RightToLeft : NativeConstParameterFunction
		{
			public system_text_regularexpressions_Regex_get_RightToLeft() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_get_RightToLeft";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.Regex _this =
					(System.Text.RegularExpressions.Regex)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					bool _result_ = _this.RightToLeft
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_text_regularexpressions_Regex_getGroupNames : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_regularexpressions_Regex_getGroupNames() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_getGroupNames";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.Regex _this =
					(System.Text.RegularExpressions.Regex)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.GetGroupNames()
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.RegularExpressions.Regex).GetMethod("GetGroupNames",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_text_regularexpressions_Regex_getGroupNumbers : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_regularexpressions_Regex_getGroupNumbers() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_getGroupNumbers";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.Regex _this =
					(System.Text.RegularExpressions.Regex)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.GetGroupNumbers()
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.RegularExpressions.Regex).GetMethod("GetGroupNumbers",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_text_regularexpressions_Regex_groupNameFromNumber : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_regularexpressions_Regex_groupNameFromNumber() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_groupNameFromNumber";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.Regex _this =
					(System.Text.RegularExpressions.Regex)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					string _result_ = (string)(_this.GroupNameFromNumber((System.Int32)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.RegularExpressions.Regex).GetMethod("GroupNameFromNumber",new Type[] {typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_text_regularexpressions_Regex_groupNumberFromName : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_regularexpressions_Regex_groupNumberFromName() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_groupNumberFromName";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.Regex _this =
					(System.Text.RegularExpressions.Regex)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					int _result_ = (int)(_this.GroupNumberFromName((System.String)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.RegularExpressions.Regex).GetMethod("GroupNumberFromName",new Type[] {typeof(System.String)});;
				}
				return method;
			}

		}

		public class system_text_regularexpressions_Regex_isMatch : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_regularexpressions_Regex_isMatch() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_isMatch";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.Regex _this =
					(System.Text.RegularExpressions.Regex)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					bool _result_ = _this.IsMatch((System.String)arg0)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.RegularExpressions.Regex).GetMethod("IsMatch",new Type[] {typeof(System.String)});;
				}
				return method;
			}

		}

		public class system_text_regularexpressions_Regex_isMatch_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_regularexpressions_Regex_isMatch_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_isMatch_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.Regex _this =
					(System.Text.RegularExpressions.Regex)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					bool _result_ = _this.IsMatch((System.String)arg0,(System.Int32)arg1)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.RegularExpressions.Regex).GetMethod("IsMatch",new Type[] {typeof(System.String),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_text_regularexpressions_Regex_match : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_regularexpressions_Regex_match() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_match";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.Regex _this =
					(System.Text.RegularExpressions.Regex)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					object _result_ = _this.Match((System.String)arg0)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.RegularExpressions.Regex).GetMethod("Match",new Type[] {typeof(System.String)});;
				}
				return method;
			}

		}

		public class system_text_regularexpressions_Regex_match_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_regularexpressions_Regex_match_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_match_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.Regex _this =
					(System.Text.RegularExpressions.Regex)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					object _result_ = _this.Match((System.String)arg0,(System.Int32)arg1)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.RegularExpressions.Regex).GetMethod("Match",new Type[] {typeof(System.String),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_text_regularexpressions_Regex_match__ : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_regularexpressions_Regex_match__() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_match__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.Regex _this =
					(System.Text.RegularExpressions.Regex)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					int arg2 = TypeConverter.ConvertToInt(argements[2]);

					object _result_ = _this.Match((System.String)arg0,(System.Int32)arg1,(System.Int32)arg2)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.RegularExpressions.Regex).GetMethod("Match",new Type[] {typeof(System.String),typeof(System.Int32),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_text_regularexpressions_Regex_matches : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_regularexpressions_Regex_matches() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_matches";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.Regex _this =
					(System.Text.RegularExpressions.Regex)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					object _result_ = _this.Matches((System.String)arg0)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.RegularExpressions.Regex).GetMethod("Matches",new Type[] {typeof(System.String)});;
				}
				return method;
			}

		}

		public class system_text_regularexpressions_Regex_matches_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_regularexpressions_Regex_matches_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_matches_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.Regex _this =
					(System.Text.RegularExpressions.Regex)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					object _result_ = _this.Matches((System.String)arg0,(System.Int32)arg1)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.RegularExpressions.Regex).GetMethod("Matches",new Type[] {typeof(System.String),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_text_regularexpressions_Regex_replace : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_regularexpressions_Regex_replace() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_replace";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.Regex _this =
					(System.Text.RegularExpressions.Regex)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					System.Text.RegularExpressions.MatchEvaluator arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Text.RegularExpressions.MatchEvaluator)_temp;
					}

					string _result_ = (string)(_this.Replace((System.String)arg0,(System.Text.RegularExpressions.MatchEvaluator)arg1)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.RegularExpressions.Regex).GetMethod("Replace",new Type[] {typeof(System.String),typeof(System.Text.RegularExpressions.MatchEvaluator)});;
				}
				return method;
			}

		}

		public class system_text_regularexpressions_Regex_replace_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_regularexpressions_Regex_replace_() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_replace_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.Regex _this =
					(System.Text.RegularExpressions.Regex)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					System.Text.RegularExpressions.MatchEvaluator arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Text.RegularExpressions.MatchEvaluator)_temp;
					}
					int arg2 = TypeConverter.ConvertToInt(argements[2]);

					string _result_ = (string)(_this.Replace((System.String)arg0,(System.Text.RegularExpressions.MatchEvaluator)arg1,(System.Int32)arg2)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.RegularExpressions.Regex).GetMethod("Replace",new Type[] {typeof(System.String),typeof(System.Text.RegularExpressions.MatchEvaluator),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_text_regularexpressions_Regex_replace__ : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_regularexpressions_Regex_replace__() : base(4)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_replace__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.Regex _this =
					(System.Text.RegularExpressions.Regex)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					System.Text.RegularExpressions.MatchEvaluator arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Text.RegularExpressions.MatchEvaluator)_temp;
					}
					int arg2 = TypeConverter.ConvertToInt(argements[2]);
					int arg3 = TypeConverter.ConvertToInt(argements[3]);

					string _result_ = (string)(_this.Replace((System.String)arg0,(System.Text.RegularExpressions.MatchEvaluator)arg1,(System.Int32)arg2,(System.Int32)arg3)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.RegularExpressions.Regex).GetMethod("Replace",new Type[] {typeof(System.String),typeof(System.Text.RegularExpressions.MatchEvaluator),typeof(System.Int32),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_text_regularexpressions_Regex_replace___ : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_regularexpressions_Regex_replace___() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_replace___";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.Regex _this =
					(System.Text.RegularExpressions.Regex)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);

					string _result_ = (string)(_this.Replace((System.String)arg0,(System.String)arg1)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.RegularExpressions.Regex).GetMethod("Replace",new Type[] {typeof(System.String),typeof(System.String)});;
				}
				return method;
			}

		}

		public class system_text_regularexpressions_Regex_replace____ : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_regularexpressions_Regex_replace____() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_replace____";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.Regex _this =
					(System.Text.RegularExpressions.Regex)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);
					int arg2 = TypeConverter.ConvertToInt(argements[2]);

					string _result_ = (string)(_this.Replace((System.String)arg0,(System.String)arg1,(System.Int32)arg2)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.RegularExpressions.Regex).GetMethod("Replace",new Type[] {typeof(System.String),typeof(System.String),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_text_regularexpressions_Regex_replace_____ : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_regularexpressions_Regex_replace_____() : base(4)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_replace_____";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.Regex _this =
					(System.Text.RegularExpressions.Regex)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);
					int arg2 = TypeConverter.ConvertToInt(argements[2]);
					int arg3 = TypeConverter.ConvertToInt(argements[3]);

					string _result_ = (string)(_this.Replace((System.String)arg0,(System.String)arg1,(System.Int32)arg2,(System.Int32)arg3)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.RegularExpressions.Regex).GetMethod("Replace",new Type[] {typeof(System.String),typeof(System.String),typeof(System.Int32),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_text_regularexpressions_Regex_split : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_regularexpressions_Regex_split() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_split";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.Regex _this =
					(System.Text.RegularExpressions.Regex)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					object _result_ = _this.Split((System.String)arg0)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.RegularExpressions.Regex).GetMethod("Split",new Type[] {typeof(System.String)});;
				}
				return method;
			}

		}

		public class system_text_regularexpressions_Regex_split_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_regularexpressions_Regex_split_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_split_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.Regex _this =
					(System.Text.RegularExpressions.Regex)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					object _result_ = _this.Split((System.String)arg0,(System.Int32)arg1)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.RegularExpressions.Regex).GetMethod("Split",new Type[] {typeof(System.String),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_text_regularexpressions_Regex_split__ : NativeConstParameterFunction,IMethodGetter
		{
			public system_text_regularexpressions_Regex_split__() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_Regex_split__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.Regex _this =
					(System.Text.RegularExpressions.Regex)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					int arg2 = TypeConverter.ConvertToInt(argements[2]);

					object _result_ = _this.Split((System.String)arg0,(System.Int32)arg1,(System.Int32)arg2)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Text.RegularExpressions.Regex).GetMethod("Split",new Type[] {typeof(System.String),typeof(System.Int32),typeof(System.Int32)});;
				}
				return method;
			}

		}

	}
}
