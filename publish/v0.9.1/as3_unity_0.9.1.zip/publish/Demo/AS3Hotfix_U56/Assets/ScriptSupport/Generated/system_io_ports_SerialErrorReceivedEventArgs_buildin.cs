using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_io_ports_SerialErrorReceivedEventArgs_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_io_ports_SerialErrorReceivedEventArgs_creator", default(System.IO.Ports.SerialErrorReceivedEventArgs)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_io_ports_SerialErrorReceivedEventArgs_buildin.system_io_ports_SerialErrorReceivedEventArgs_get_EventType","system_io_ports_SerialErrorReceivedEventArgs_get_EventType");
		}


		public class system_io_ports_SerialErrorReceivedEventArgs_get_EventType : NativeConstParameterFunction
		{
			public system_io_ports_SerialErrorReceivedEventArgs_get_EventType() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_io_ports_SerialErrorReceivedEventArgs_get_EventType";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.IO.Ports.SerialErrorReceivedEventArgs _this =
					(System.IO.Ports.SerialErrorReceivedEventArgs)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					System.IO.Ports.SerialError _result_ = _this.EventType
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

	}
}
