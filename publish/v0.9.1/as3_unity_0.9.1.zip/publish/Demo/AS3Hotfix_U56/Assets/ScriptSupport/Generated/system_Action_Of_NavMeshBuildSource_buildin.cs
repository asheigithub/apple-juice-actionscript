using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_Action_Of_NavMeshBuildSource_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_Action_Of_NavMeshBuildSource_creator", default(System.Action<UnityEngine.AI.NavMeshBuildSource>)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Action_Of_NavMeshBuildSource_buildin.system_Action_Of_NavMeshBuildSource_ctor","system_Action_Of_NavMeshBuildSource_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Action_Of_NavMeshBuildSource_buildin.system_Action_Of_NavMeshBuildSource_implicit_from_","system_Action_Of_NavMeshBuildSource_implicit_from_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Action_Of_NavMeshBuildSource_buildin.system_Action_Of_NavMeshBuildSource_invoke","system_Action_Of_NavMeshBuildSource_invoke");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Action_Of_NavMeshBuildSource_buildin.system_Action_Of_NavMeshBuildSource_beginInvoke","system_Action_Of_NavMeshBuildSource_beginInvoke");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Action_Of_NavMeshBuildSource_buildin.system_Action_Of_NavMeshBuildSource_endInvoke","system_Action_Of_NavMeshBuildSource_endInvoke");
		}


		public class system_Action_Of_NavMeshBuildSource_ctor : NativeConstParameterFunction
		{
			public system_Action_Of_NavMeshBuildSource_ctor() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_function);
				
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Action_Of_NavMeshBuildSource_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					var cls = bin.getClassByRunTimeDataType(thisObj.rtType);

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						stackframe.throwArgementException(token, "参数" + functionDefine.signature.parameters[0].name + "不能为null" );
						success = false;
					}
					else
					{
						var action = stackframe.player.WapperFunctionDelegate(argements[0], cls, typeof(System.Action<UnityEngine.AI.NavMeshBuildSource>) ,

							(wapper) => {
								

								System.Action<UnityEngine.AI.NavMeshBuildSource> actionwapper = (__wapperargs__0) =>
								{
									wapper.Invoke(__wapperargs__0);
								};

								wapper.action = actionwapper;								

							}
							
							);

						


						((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = action;
						success = true;
					}
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
				}
				catch (ASRunTimeException ex)
				{
					success = false;
					stackframe.throwError(token, 9998, ex.ToString());					
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}


		public class system_Action_Of_NavMeshBuildSource_implicit_from_ : NativeConstParameterFunction,IWapperDelegateMaker
		{
			public system_Action_Of_NavMeshBuildSource_implicit_from_() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_function);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Action_Of_NavMeshBuildSource_implicit_from_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					var cls = ((ASBinCode.rtData.rtObjectBase)thisObj).value._class.instanceClass;
					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						stackframe.throwArgementException(token, "参数" + functionDefine.signature.parameters[0].name + "不能为null");
						success = false;
					}
					else
					{
						var action = MakeWapper(argements[0], stackframe.player, cls);

						((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, (System.Action<UnityEngine.AI.NavMeshBuildSource>)action);

						success = true;
					}

				}
				catch (ASRunTimeException ex)
				{
					success = false;
					stackframe.throwError(token, 9998, ex.ToString());
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			public Delegate MakeWapper(ASBinCode.RunTimeValueBase function, Player player, ASBinCode.rtti.Class cls)
			{
				var action = player.WapperFunctionDelegate(function, cls, typeof(System.Action<UnityEngine.AI.NavMeshBuildSource>),
					(wapper)=> {
						

						System.Action<UnityEngine.AI.NavMeshBuildSource> actionwapper = (__wapperargs__0) =>
						{
							wapper.Invoke(__wapperargs__0);
						};

						wapper.action = actionwapper;
						
					});

				

				return action;

			}
		}

		public class system_Action_Of_NavMeshBuildSource_invoke : NativeConstParameterFunction
		{
			public system_Action_Of_NavMeshBuildSource_invoke() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Action_Of_NavMeshBuildSource_invoke";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Action<UnityEngine.AI.NavMeshBuildSource> _this =
					(System.Action<UnityEngine.AI.NavMeshBuildSource>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.AI.NavMeshBuildSource arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(UnityEngine.AI.NavMeshBuildSource);
					}
					else
					{
						LinkObj<UnityEngine.AI.NavMeshBuildSource> argObj = (LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					_this.Invoke((UnityEngine.AI.NavMeshBuildSource)arg0)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_Action_Of_NavMeshBuildSource_beginInvoke : NativeConstParameterFunction
		{
			public system_Action_Of_NavMeshBuildSource_beginInvoke() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Action_Of_NavMeshBuildSource_beginInvoke";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Action<UnityEngine.AI.NavMeshBuildSource> _this =
					(System.Action<UnityEngine.AI.NavMeshBuildSource>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.AI.NavMeshBuildSource arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(UnityEngine.AI.NavMeshBuildSource);
					}
					else
					{
						LinkObj<UnityEngine.AI.NavMeshBuildSource> argObj = (LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.AsyncCallback arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.AsyncCallback)_temp;
					}
					System.Object arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Object)_temp;
					}

					object _result_ = _this.BeginInvoke((UnityEngine.AI.NavMeshBuildSource)arg0,(System.AsyncCallback)arg1,(System.Object)arg2)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_Action_Of_NavMeshBuildSource_endInvoke : NativeConstParameterFunction
		{
			public system_Action_Of_NavMeshBuildSource_endInvoke() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Action_Of_NavMeshBuildSource_endInvoke";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Action<UnityEngine.AI.NavMeshBuildSource> _this =
					(System.Action<UnityEngine.AI.NavMeshBuildSource>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.IAsyncResult arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.IAsyncResult)_temp;
					}

					_this.EndInvoke((System.IAsyncResult)arg0)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

	}
}
