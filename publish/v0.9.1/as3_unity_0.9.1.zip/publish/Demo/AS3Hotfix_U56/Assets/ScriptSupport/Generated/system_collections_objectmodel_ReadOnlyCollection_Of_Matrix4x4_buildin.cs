using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_creator", default(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Matrix4x4>)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_buildin.system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_getThisItem","system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_getThisItem");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_buildin.system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_contains","system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_contains");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_buildin.system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_copyTo","system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_copyTo");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_buildin.system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_indexOf","system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_indexOf");
		}


		public class system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_getThisItem : NativeConstParameterFunction
		{
			public system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_getThisItem() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_getThisItem";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Matrix4x4> _this =
					(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Matrix4x4>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					UnityEngine.Matrix4x4 _result_ = _this[(System.Int32)arg0]
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_contains : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_contains() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_contains";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Matrix4x4> _this =
					(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Matrix4x4>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.Matrix4x4 arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(UnityEngine.Matrix4x4);
					}
					else
					{
						LinkObj<UnityEngine.Matrix4x4> argObj = (LinkObj<UnityEngine.Matrix4x4>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					bool _result_ = _this.Contains((UnityEngine.Matrix4x4)arg0)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Matrix4x4>).GetMethod("Contains",new Type[] {typeof(UnityEngine.Matrix4x4)});;
				}
				return method;
			}

		}

		public class system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_copyTo : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_copyTo() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_copyTo";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Matrix4x4> _this =
					(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Matrix4x4>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.Matrix4x4[] arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.Matrix4x4[])_temp;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					_this.CopyTo((UnityEngine.Matrix4x4[])arg0,(System.Int32)arg1)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Matrix4x4>).GetMethod("CopyTo",new Type[] {typeof(UnityEngine.Matrix4x4[]),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_indexOf : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_indexOf() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_objectmodel_ReadOnlyCollection_Of_Matrix4x4_indexOf";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Matrix4x4> _this =
					(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Matrix4x4>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.Matrix4x4 arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(UnityEngine.Matrix4x4);
					}
					else
					{
						LinkObj<UnityEngine.Matrix4x4> argObj = (LinkObj<UnityEngine.Matrix4x4>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					int _result_ = (int)(_this.IndexOf((UnityEngine.Matrix4x4)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Matrix4x4>).GetMethod("IndexOf",new Type[] {typeof(UnityEngine.Matrix4x4)});;
				}
				return method;
			}

		}

	}
}
