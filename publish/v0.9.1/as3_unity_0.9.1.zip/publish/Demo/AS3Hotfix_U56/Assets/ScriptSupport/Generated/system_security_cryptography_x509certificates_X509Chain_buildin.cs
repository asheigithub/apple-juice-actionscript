using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_security_cryptography_x509certificates_X509Chain_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_security_cryptography_x509certificates_X509Chain_creator", default(System.Security.Cryptography.X509Certificates.X509Chain)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Chain_buildin.system_security_cryptography_x509certificates_X509Chain_constructor_","system_security_cryptography_x509certificates_X509Chain_constructor_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Chain_buildin.system_security_cryptography_x509certificates_X509Chain_constructor__","system_security_cryptography_x509certificates_X509Chain_constructor__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Chain_buildin.system_security_cryptography_x509certificates_X509Chain_ctor","system_security_cryptography_x509certificates_X509Chain_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Chain_buildin._system_security_cryptography_x509certificates_X509ChainAdapter_ctor","_system_security_cryptography_x509certificates_X509ChainAdapter_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Chain_buildin.system_security_cryptography_x509certificates_X509Chain_get_ChainContext","system_security_cryptography_x509certificates_X509Chain_get_ChainContext");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Chain_buildin.system_security_cryptography_x509certificates_X509Chain_get_ChainElements","system_security_cryptography_x509certificates_X509Chain_get_ChainElements");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Chain_buildin.system_security_cryptography_x509certificates_X509Chain_get_ChainPolicy","system_security_cryptography_x509certificates_X509Chain_get_ChainPolicy");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Chain_buildin.system_security_cryptography_x509certificates_X509Chain_set_ChainPolicy","system_security_cryptography_x509certificates_X509Chain_set_ChainPolicy");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Chain_buildin.system_security_cryptography_x509certificates_X509Chain_get_ChainStatus","system_security_cryptography_x509certificates_X509Chain_get_ChainStatus");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Chain_buildin.system_security_cryptography_x509certificates_X509Chain_build","system_security_cryptography_x509certificates_X509Chain_build");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Chain_buildin.system_security_cryptography_x509certificates_X509Chain_reset","system_security_cryptography_x509certificates_X509Chain_reset");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Chain_buildin.static_system_security_cryptography_x509certificates_X509Chain_create","static_system_security_cryptography_x509certificates_X509Chain_create");
		}

		public class system_security_cryptography_x509certificates_X509ChainAdapter :System.Security.Cryptography.X509Certificates.X509Chain ,ASRuntime.ICrossExtendAdapter
		{

			public ASBinCode.rtti.Class AS3Class { get { return typeclass; } }

			public ASBinCode.rtData.rtObjectBase AS3Object { get { return bindAS3Object; } }

			protected Player player;
			private Class typeclass;
			private ASBinCode.rtData.rtObjectBase bindAS3Object;

			public void SetAS3RuntimeEnvironment(Player player, Class typeclass, ASBinCode.rtData.rtObjectBase bindAS3Object)
			{
				this.player = player;
				this.typeclass = typeclass;
				this.bindAS3Object = bindAS3Object;
			}

			public system_security_cryptography_x509certificates_X509ChainAdapter():base(){}

		}
		public class system_security_cryptography_x509certificates_X509Chain_constructor_ : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Chain_constructor_() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_boolean);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Chain_constructor_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					bool arg0 = TypeConverter.ConvertToBoolean(argements[0], stackframe, token).value;

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Security.Cryptography.X509Certificates.X509Chain((System.Boolean)arg0));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Chain_constructor__ : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Chain_constructor__() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Chain_constructor__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.IntPtr arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.IntPtr);
					}
					else
					{
						LinkObj<System.IntPtr> argObj = (LinkObj<System.IntPtr>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Security.Cryptography.X509Certificates.X509Chain((System.IntPtr)arg0));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Chain_ctor : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Chain_ctor() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Chain_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{

					((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new System.Security.Cryptography.X509Certificates.X509Chain();
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class _system_security_cryptography_x509certificates_X509ChainAdapter_ctor : NativeConstParameterFunction,ICrossExtendAdapterCreator
		{
			public _system_security_cryptography_x509certificates_X509ChainAdapter_ctor() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public Type GetAdapterType()
			{
				return typeof(system_security_cryptography_x509certificates_X509ChainAdapter);
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "_system_security_cryptography_x509certificates_X509ChainAdapter_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{

					((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new system_security_cryptography_x509certificates_X509ChainAdapter();

					((ICrossExtendAdapter)((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value)
						.SetAS3RuntimeEnvironment(stackframe.player, ((ASBinCode.rtData.rtObjectBase)thisObj).value._class, (ASBinCode.rtData.rtObjectBase)thisObj);


					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Chain_get_ChainContext : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Chain_get_ChainContext() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Chain_get_ChainContext";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Chain _this =
					(System.Security.Cryptography.X509Certificates.X509Chain)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					System.IntPtr _result_ = _this.ChainContext
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Chain_get_ChainElements : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Chain_get_ChainElements() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Chain_get_ChainElements";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Chain _this =
					(System.Security.Cryptography.X509Certificates.X509Chain)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.ChainElements
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Chain_get_ChainPolicy : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Chain_get_ChainPolicy() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Chain_get_ChainPolicy";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Chain _this =
					(System.Security.Cryptography.X509Certificates.X509Chain)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.ChainPolicy
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Chain_set_ChainPolicy : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Chain_set_ChainPolicy() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Chain_set_ChainPolicy";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Chain _this =
					(System.Security.Cryptography.X509Certificates.X509Chain)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Security.Cryptography.X509Certificates.X509ChainPolicy arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Security.Cryptography.X509Certificates.X509ChainPolicy)_temp;
					}

					_this.ChainPolicy = (System.Security.Cryptography.X509Certificates.X509ChainPolicy)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Chain_get_ChainStatus : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Chain_get_ChainStatus() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Chain_get_ChainStatus";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Chain _this =
					(System.Security.Cryptography.X509Certificates.X509Chain)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.ChainStatus
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Chain_build : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Chain_build() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Chain_build";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Chain _this =
					(System.Security.Cryptography.X509Certificates.X509Chain)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Security.Cryptography.X509Certificates.X509Certificate2 arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Security.Cryptography.X509Certificates.X509Certificate2)_temp;
					}

					bool _result_ = _this.Build((System.Security.Cryptography.X509Certificates.X509Certificate2)arg0)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Chain).GetMethod("Build",new Type[] {typeof(System.Security.Cryptography.X509Certificates.X509Certificate2)});;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Chain_reset : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Chain_reset() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Chain_reset";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Chain _this =
					(System.Security.Cryptography.X509Certificates.X509Chain)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					_this.Reset()
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Chain).GetMethod("Reset",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class static_system_security_cryptography_x509certificates_X509Chain_create : NativeConstParameterFunction
		{
			public static_system_security_cryptography_x509certificates_X509Chain_create() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_security_cryptography_x509certificates_X509Chain_create";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{

					object _result_ = System.Security.Cryptography.X509Certificates.X509Chain.Create()
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

	}
}
