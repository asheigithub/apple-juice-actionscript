using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_text_regularexpressions_RegexCompilationInfo_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_text_regularexpressions_RegexCompilationInfo_creator", default(System.Text.RegularExpressions.RegexCompilationInfo)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_RegexCompilationInfo_buildin.system_text_regularexpressions_RegexCompilationInfo_ctor","system_text_regularexpressions_RegexCompilationInfo_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_RegexCompilationInfo_buildin._system_text_regularexpressions_RegexCompilationInfoAdapter_ctor","_system_text_regularexpressions_RegexCompilationInfoAdapter_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_RegexCompilationInfo_buildin.system_text_regularexpressions_RegexCompilationInfo_get_IsPublic","system_text_regularexpressions_RegexCompilationInfo_get_IsPublic");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_RegexCompilationInfo_buildin.system_text_regularexpressions_RegexCompilationInfo_set_IsPublic","system_text_regularexpressions_RegexCompilationInfo_set_IsPublic");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_RegexCompilationInfo_buildin.system_text_regularexpressions_RegexCompilationInfo_get_Name","system_text_regularexpressions_RegexCompilationInfo_get_Name");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_RegexCompilationInfo_buildin.system_text_regularexpressions_RegexCompilationInfo_set_Name","system_text_regularexpressions_RegexCompilationInfo_set_Name");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_RegexCompilationInfo_buildin.system_text_regularexpressions_RegexCompilationInfo_get_Namespace","system_text_regularexpressions_RegexCompilationInfo_get_Namespace");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_RegexCompilationInfo_buildin.system_text_regularexpressions_RegexCompilationInfo_set_Namespace","system_text_regularexpressions_RegexCompilationInfo_set_Namespace");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_RegexCompilationInfo_buildin.system_text_regularexpressions_RegexCompilationInfo_get_Options","system_text_regularexpressions_RegexCompilationInfo_get_Options");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_RegexCompilationInfo_buildin.system_text_regularexpressions_RegexCompilationInfo_set_Options","system_text_regularexpressions_RegexCompilationInfo_set_Options");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_RegexCompilationInfo_buildin.system_text_regularexpressions_RegexCompilationInfo_get_Pattern","system_text_regularexpressions_RegexCompilationInfo_get_Pattern");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_text_regularexpressions_RegexCompilationInfo_buildin.system_text_regularexpressions_RegexCompilationInfo_set_Pattern","system_text_regularexpressions_RegexCompilationInfo_set_Pattern");
		}

		public class system_text_regularexpressions_RegexCompilationInfoAdapter :System.Text.RegularExpressions.RegexCompilationInfo ,ASRuntime.ICrossExtendAdapter
		{

			public ASBinCode.rtti.Class AS3Class { get { return typeclass; } }

			public ASBinCode.rtData.rtObjectBase AS3Object { get { return bindAS3Object; } }

			protected Player player;
			private Class typeclass;
			private ASBinCode.rtData.rtObjectBase bindAS3Object;

			public void SetAS3RuntimeEnvironment(Player player, Class typeclass, ASBinCode.rtData.rtObjectBase bindAS3Object)
			{
				this.player = player;
				this.typeclass = typeclass;
				this.bindAS3Object = bindAS3Object;
			}

			public system_text_regularexpressions_RegexCompilationInfoAdapter(System.String pattern,System.Text.RegularExpressions.RegexOptions options,System.String name,System.String fullnamespace,System.Boolean ispublic):base(pattern,options,name,fullnamespace,ispublic){}

		}
		public class system_text_regularexpressions_RegexCompilationInfo_ctor : NativeConstParameterFunction
		{
			public system_text_regularexpressions_RegexCompilationInfo_ctor() : base(5)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_boolean);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_RegexCompilationInfo_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					System.Text.RegularExpressions.RegexOptions arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Text.RegularExpressions.RegexOptions)_temp;
					}
					string arg2 = TypeConverter.ConvertToString(argements[2], stackframe, token);
					string arg3 = TypeConverter.ConvertToString(argements[3], stackframe, token);
					bool arg4 = TypeConverter.ConvertToBoolean(argements[4], stackframe, token).value;

					((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new System.Text.RegularExpressions.RegexCompilationInfo((System.String)arg0,(System.Text.RegularExpressions.RegexOptions)arg1,(System.String)arg2,(System.String)arg3,(System.Boolean)arg4);
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class _system_text_regularexpressions_RegexCompilationInfoAdapter_ctor : NativeConstParameterFunction,ICrossExtendAdapterCreator
		{
			public _system_text_regularexpressions_RegexCompilationInfoAdapter_ctor() : base(5)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_boolean);

			}

			public Type GetAdapterType()
			{
				return typeof(system_text_regularexpressions_RegexCompilationInfoAdapter);
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "_system_text_regularexpressions_RegexCompilationInfoAdapter_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					System.Text.RegularExpressions.RegexOptions arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Text.RegularExpressions.RegexOptions)_temp;
					}
					string arg2 = TypeConverter.ConvertToString(argements[2], stackframe, token);
					string arg3 = TypeConverter.ConvertToString(argements[3], stackframe, token);
					bool arg4 = TypeConverter.ConvertToBoolean(argements[4], stackframe, token).value;

					((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new system_text_regularexpressions_RegexCompilationInfoAdapter((System.String)arg0,(System.Text.RegularExpressions.RegexOptions)arg1,(System.String)arg2,(System.String)arg3,(System.Boolean)arg4);

					((ICrossExtendAdapter)((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value)
						.SetAS3RuntimeEnvironment(stackframe.player, ((ASBinCode.rtData.rtObjectBase)thisObj).value._class, (ASBinCode.rtData.rtObjectBase)thisObj);


					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_text_regularexpressions_RegexCompilationInfo_get_IsPublic : NativeConstParameterFunction
		{
			public system_text_regularexpressions_RegexCompilationInfo_get_IsPublic() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_RegexCompilationInfo_get_IsPublic";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.RegexCompilationInfo _this =
					(System.Text.RegularExpressions.RegexCompilationInfo)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					bool _result_ = _this.IsPublic
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_text_regularexpressions_RegexCompilationInfo_set_IsPublic : NativeConstParameterFunction
		{
			public system_text_regularexpressions_RegexCompilationInfo_set_IsPublic() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_boolean);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_RegexCompilationInfo_set_IsPublic";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.RegexCompilationInfo _this =
					(System.Text.RegularExpressions.RegexCompilationInfo)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					bool arg0 = TypeConverter.ConvertToBoolean(argements[0], stackframe, token).value;

					_this.IsPublic = (System.Boolean)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_text_regularexpressions_RegexCompilationInfo_get_Name : NativeConstParameterFunction
		{
			public system_text_regularexpressions_RegexCompilationInfo_get_Name() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_RegexCompilationInfo_get_Name";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.RegexCompilationInfo _this =
					(System.Text.RegularExpressions.RegexCompilationInfo)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					string _result_ = (string)(_this.Name
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_text_regularexpressions_RegexCompilationInfo_set_Name : NativeConstParameterFunction
		{
			public system_text_regularexpressions_RegexCompilationInfo_set_Name() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_RegexCompilationInfo_set_Name";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.RegexCompilationInfo _this =
					(System.Text.RegularExpressions.RegexCompilationInfo)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					_this.Name = (System.String)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_text_regularexpressions_RegexCompilationInfo_get_Namespace : NativeConstParameterFunction
		{
			public system_text_regularexpressions_RegexCompilationInfo_get_Namespace() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_RegexCompilationInfo_get_Namespace";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.RegexCompilationInfo _this =
					(System.Text.RegularExpressions.RegexCompilationInfo)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					string _result_ = (string)(_this.Namespace
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_text_regularexpressions_RegexCompilationInfo_set_Namespace : NativeConstParameterFunction
		{
			public system_text_regularexpressions_RegexCompilationInfo_set_Namespace() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_RegexCompilationInfo_set_Namespace";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.RegexCompilationInfo _this =
					(System.Text.RegularExpressions.RegexCompilationInfo)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					_this.Namespace = (System.String)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_text_regularexpressions_RegexCompilationInfo_get_Options : NativeConstParameterFunction
		{
			public system_text_regularexpressions_RegexCompilationInfo_get_Options() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_RegexCompilationInfo_get_Options";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.RegexCompilationInfo _this =
					(System.Text.RegularExpressions.RegexCompilationInfo)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					System.Text.RegularExpressions.RegexOptions _result_ = _this.Options
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_text_regularexpressions_RegexCompilationInfo_set_Options : NativeConstParameterFunction
		{
			public system_text_regularexpressions_RegexCompilationInfo_set_Options() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_RegexCompilationInfo_set_Options";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.RegexCompilationInfo _this =
					(System.Text.RegularExpressions.RegexCompilationInfo)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Text.RegularExpressions.RegexOptions arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Text.RegularExpressions.RegexOptions)_temp;
					}

					_this.Options = (System.Text.RegularExpressions.RegexOptions)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_text_regularexpressions_RegexCompilationInfo_get_Pattern : NativeConstParameterFunction
		{
			public system_text_regularexpressions_RegexCompilationInfo_get_Pattern() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_RegexCompilationInfo_get_Pattern";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.RegexCompilationInfo _this =
					(System.Text.RegularExpressions.RegexCompilationInfo)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					string _result_ = (string)(_this.Pattern
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_text_regularexpressions_RegexCompilationInfo_set_Pattern : NativeConstParameterFunction
		{
			public system_text_regularexpressions_RegexCompilationInfo_set_Pattern() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_text_regularexpressions_RegexCompilationInfo_set_Pattern";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Text.RegularExpressions.RegexCompilationInfo _this =
					(System.Text.RegularExpressions.RegexCompilationInfo)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					_this.Pattern = (System.String)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

	}
}
