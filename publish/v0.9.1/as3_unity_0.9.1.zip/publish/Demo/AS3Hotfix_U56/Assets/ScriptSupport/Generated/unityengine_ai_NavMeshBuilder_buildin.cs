using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class unityengine_ai_NavMeshBuilder_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getStaticClassCreator("unityengine_ai_NavMeshBuilder_creator", typeof(UnityEngine.AI.NavMeshBuilder)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuilder_buildin.static_unityengine_ai_NavMeshBuilder_collectSources","static_unityengine_ai_NavMeshBuilder_collectSources");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuilder_buildin.static_unityengine_ai_NavMeshBuilder_collectSources_","static_unityengine_ai_NavMeshBuilder_collectSources_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuilder_buildin.static_unityengine_ai_NavMeshBuilder_buildNavMeshData","static_unityengine_ai_NavMeshBuilder_buildNavMeshData");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuilder_buildin.static_unityengine_ai_NavMeshBuilder_updateNavMeshData","static_unityengine_ai_NavMeshBuilder_updateNavMeshData");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuilder_buildin.static_unityengine_ai_NavMeshBuilder_updateNavMeshDataAsync","static_unityengine_ai_NavMeshBuilder_updateNavMeshDataAsync");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuilder_buildin.static_unityengine_ai_NavMeshBuilder_cancel","static_unityengine_ai_NavMeshBuilder_cancel");
		}


		public class static_unityengine_ai_NavMeshBuilder_collectSources : NativeConstParameterFunction
		{
			public static_unityengine_ai_NavMeshBuilder_collectSources() : base(6)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_unityengine_ai_NavMeshBuilder_collectSources";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					UnityEngine.Bounds arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(UnityEngine.Bounds);
					}
					else
					{
						LinkObj<UnityEngine.Bounds> argObj = (LinkObj<UnityEngine.Bounds>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					UnityEngine.AI.NavMeshCollectGeometry arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (UnityEngine.AI.NavMeshCollectGeometry)_temp;
					}
					int arg3 = TypeConverter.ConvertToInt(argements[3]);
					System.Collections.Generic.List<UnityEngine.AI.NavMeshBuildMarkup> arg4;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[4],

							stackframe.player.linktypemapper.getLinkType(argements[4].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[4].rtType,

								functionDefine.signature.parameters[4].type
								);
							success = false;
							return;
						}
						arg4 = (System.Collections.Generic.List<UnityEngine.AI.NavMeshBuildMarkup>)_temp;
					}
					System.Collections.Generic.List<UnityEngine.AI.NavMeshBuildSource> arg5;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[5],

							stackframe.player.linktypemapper.getLinkType(argements[5].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[5].rtType,

								functionDefine.signature.parameters[5].type
								);
							success = false;
							return;
						}
						arg5 = (System.Collections.Generic.List<UnityEngine.AI.NavMeshBuildSource>)_temp;
					}

					UnityEngine.AI.NavMeshBuilder.CollectSources((UnityEngine.Bounds)arg0,(System.Int32)arg1,(UnityEngine.AI.NavMeshCollectGeometry)arg2,(System.Int32)arg3,(System.Collections.Generic.List<UnityEngine.AI.NavMeshBuildMarkup>)arg4,(System.Collections.Generic.List<UnityEngine.AI.NavMeshBuildSource>)arg5)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_unityengine_ai_NavMeshBuilder_collectSources_ : NativeConstParameterFunction
		{
			public static_unityengine_ai_NavMeshBuilder_collectSources_() : base(6)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_unityengine_ai_NavMeshBuilder_collectSources_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					UnityEngine.Transform arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.Transform)_temp;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					UnityEngine.AI.NavMeshCollectGeometry arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (UnityEngine.AI.NavMeshCollectGeometry)_temp;
					}
					int arg3 = TypeConverter.ConvertToInt(argements[3]);
					System.Collections.Generic.List<UnityEngine.AI.NavMeshBuildMarkup> arg4;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[4],

							stackframe.player.linktypemapper.getLinkType(argements[4].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[4].rtType,

								functionDefine.signature.parameters[4].type
								);
							success = false;
							return;
						}
						arg4 = (System.Collections.Generic.List<UnityEngine.AI.NavMeshBuildMarkup>)_temp;
					}
					System.Collections.Generic.List<UnityEngine.AI.NavMeshBuildSource> arg5;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[5],

							stackframe.player.linktypemapper.getLinkType(argements[5].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[5].rtType,

								functionDefine.signature.parameters[5].type
								);
							success = false;
							return;
						}
						arg5 = (System.Collections.Generic.List<UnityEngine.AI.NavMeshBuildSource>)_temp;
					}

					UnityEngine.AI.NavMeshBuilder.CollectSources((UnityEngine.Transform)arg0,(System.Int32)arg1,(UnityEngine.AI.NavMeshCollectGeometry)arg2,(System.Int32)arg3,(System.Collections.Generic.List<UnityEngine.AI.NavMeshBuildMarkup>)arg4,(System.Collections.Generic.List<UnityEngine.AI.NavMeshBuildSource>)arg5)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_unityengine_ai_NavMeshBuilder_buildNavMeshData : NativeConstParameterFunction
		{
			public static_unityengine_ai_NavMeshBuilder_buildNavMeshData() : base(5)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_unityengine_ai_NavMeshBuilder_buildNavMeshData";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					UnityEngine.AI.NavMeshBuildSettings arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(UnityEngine.AI.NavMeshBuildSettings);
					}
					else
					{
						LinkObj<UnityEngine.AI.NavMeshBuildSettings> argObj = (LinkObj<UnityEngine.AI.NavMeshBuildSettings>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.Collections.Generic.List<UnityEngine.AI.NavMeshBuildSource> arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Collections.Generic.List<UnityEngine.AI.NavMeshBuildSource>)_temp;
					}
					UnityEngine.Bounds arg2;

					if (argements[2].rtType == RunTimeDataType.rt_null)
					{
						arg2 = default(UnityEngine.Bounds);
					}
					else
					{
						LinkObj<UnityEngine.Bounds> argObj = (LinkObj<UnityEngine.Bounds>)((ASBinCode.rtData.rtObjectBase)argements[2]).value;
						arg2 = argObj.value;
					}
					UnityEngine.Vector3 arg3;

					if (argements[3].rtType == RunTimeDataType.rt_null)
					{
						arg3 = default(UnityEngine.Vector3);
					}
					else
					{
						LinkObj<UnityEngine.Vector3> argObj = (LinkObj<UnityEngine.Vector3>)((ASBinCode.rtData.rtObjectBase)argements[3]).value;
						arg3 = argObj.value;
					}
					UnityEngine.Quaternion arg4;

					if (argements[4].rtType == RunTimeDataType.rt_null)
					{
						arg4 = default(UnityEngine.Quaternion);
					}
					else
					{
						LinkObj<UnityEngine.Quaternion> argObj = (LinkObj<UnityEngine.Quaternion>)((ASBinCode.rtData.rtObjectBase)argements[4]).value;
						arg4 = argObj.value;
					}

					object _result_ = UnityEngine.AI.NavMeshBuilder.BuildNavMeshData((UnityEngine.AI.NavMeshBuildSettings)arg0,(System.Collections.Generic.List<UnityEngine.AI.NavMeshBuildSource>)arg1,(UnityEngine.Bounds)arg2,(UnityEngine.Vector3)arg3,(UnityEngine.Quaternion)arg4)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_unityengine_ai_NavMeshBuilder_updateNavMeshData : NativeConstParameterFunction
		{
			public static_unityengine_ai_NavMeshBuilder_updateNavMeshData() : base(4)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_unityengine_ai_NavMeshBuilder_updateNavMeshData";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					UnityEngine.AI.NavMeshData arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.AI.NavMeshData)_temp;
					}
					UnityEngine.AI.NavMeshBuildSettings arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(UnityEngine.AI.NavMeshBuildSettings);
					}
					else
					{
						LinkObj<UnityEngine.AI.NavMeshBuildSettings> argObj = (LinkObj<UnityEngine.AI.NavMeshBuildSettings>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}
					System.Collections.Generic.List<UnityEngine.AI.NavMeshBuildSource> arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Collections.Generic.List<UnityEngine.AI.NavMeshBuildSource>)_temp;
					}
					UnityEngine.Bounds arg3;

					if (argements[3].rtType == RunTimeDataType.rt_null)
					{
						arg3 = default(UnityEngine.Bounds);
					}
					else
					{
						LinkObj<UnityEngine.Bounds> argObj = (LinkObj<UnityEngine.Bounds>)((ASBinCode.rtData.rtObjectBase)argements[3]).value;
						arg3 = argObj.value;
					}

					bool _result_ = UnityEngine.AI.NavMeshBuilder.UpdateNavMeshData((UnityEngine.AI.NavMeshData)arg0,(UnityEngine.AI.NavMeshBuildSettings)arg1,(System.Collections.Generic.List<UnityEngine.AI.NavMeshBuildSource>)arg2,(UnityEngine.Bounds)arg3)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_unityengine_ai_NavMeshBuilder_updateNavMeshDataAsync : NativeConstParameterFunction
		{
			public static_unityengine_ai_NavMeshBuilder_updateNavMeshDataAsync() : base(4)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_unityengine_ai_NavMeshBuilder_updateNavMeshDataAsync";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					UnityEngine.AI.NavMeshData arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.AI.NavMeshData)_temp;
					}
					UnityEngine.AI.NavMeshBuildSettings arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(UnityEngine.AI.NavMeshBuildSettings);
					}
					else
					{
						LinkObj<UnityEngine.AI.NavMeshBuildSettings> argObj = (LinkObj<UnityEngine.AI.NavMeshBuildSettings>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}
					System.Collections.Generic.List<UnityEngine.AI.NavMeshBuildSource> arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Collections.Generic.List<UnityEngine.AI.NavMeshBuildSource>)_temp;
					}
					UnityEngine.Bounds arg3;

					if (argements[3].rtType == RunTimeDataType.rt_null)
					{
						arg3 = default(UnityEngine.Bounds);
					}
					else
					{
						LinkObj<UnityEngine.Bounds> argObj = (LinkObj<UnityEngine.Bounds>)((ASBinCode.rtData.rtObjectBase)argements[3]).value;
						arg3 = argObj.value;
					}

					object _result_ = UnityEngine.AI.NavMeshBuilder.UpdateNavMeshDataAsync((UnityEngine.AI.NavMeshData)arg0,(UnityEngine.AI.NavMeshBuildSettings)arg1,(System.Collections.Generic.List<UnityEngine.AI.NavMeshBuildSource>)arg2,(UnityEngine.Bounds)arg3)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_unityengine_ai_NavMeshBuilder_cancel : NativeConstParameterFunction
		{
			public static_unityengine_ai_NavMeshBuilder_cancel() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_unityengine_ai_NavMeshBuilder_cancel";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					UnityEngine.AI.NavMeshData arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.AI.NavMeshData)_temp;
					}

					UnityEngine.AI.NavMeshBuilder.Cancel((UnityEngine.AI.NavMeshData)arg0)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

	}
}
