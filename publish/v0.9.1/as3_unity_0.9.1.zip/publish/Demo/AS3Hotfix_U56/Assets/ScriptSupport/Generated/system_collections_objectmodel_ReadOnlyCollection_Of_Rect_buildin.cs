using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_collections_objectmodel_ReadOnlyCollection_Of_Rect_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_collections_objectmodel_ReadOnlyCollection_Of_Rect_creator", default(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Rect>)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_objectmodel_ReadOnlyCollection_Of_Rect_buildin.system_collections_objectmodel_ReadOnlyCollection_Of_Rect_getThisItem","system_collections_objectmodel_ReadOnlyCollection_Of_Rect_getThisItem");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_objectmodel_ReadOnlyCollection_Of_Rect_buildin.system_collections_objectmodel_ReadOnlyCollection_Of_Rect_contains","system_collections_objectmodel_ReadOnlyCollection_Of_Rect_contains");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_objectmodel_ReadOnlyCollection_Of_Rect_buildin.system_collections_objectmodel_ReadOnlyCollection_Of_Rect_copyTo","system_collections_objectmodel_ReadOnlyCollection_Of_Rect_copyTo");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_objectmodel_ReadOnlyCollection_Of_Rect_buildin.system_collections_objectmodel_ReadOnlyCollection_Of_Rect_indexOf","system_collections_objectmodel_ReadOnlyCollection_Of_Rect_indexOf");
		}


		public class system_collections_objectmodel_ReadOnlyCollection_Of_Rect_getThisItem : NativeConstParameterFunction
		{
			public system_collections_objectmodel_ReadOnlyCollection_Of_Rect_getThisItem() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_objectmodel_ReadOnlyCollection_Of_Rect_getThisItem";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Rect> _this =
					(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Rect>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					UnityEngine.Rect _result_ = _this[(System.Int32)arg0]
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_objectmodel_ReadOnlyCollection_Of_Rect_contains : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_objectmodel_ReadOnlyCollection_Of_Rect_contains() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_objectmodel_ReadOnlyCollection_Of_Rect_contains";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Rect> _this =
					(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Rect>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.Rect arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(UnityEngine.Rect);
					}
					else
					{
						LinkObj<UnityEngine.Rect> argObj = (LinkObj<UnityEngine.Rect>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					bool _result_ = _this.Contains((UnityEngine.Rect)arg0)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Rect>).GetMethod("Contains",new Type[] {typeof(UnityEngine.Rect)});;
				}
				return method;
			}

		}

		public class system_collections_objectmodel_ReadOnlyCollection_Of_Rect_copyTo : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_objectmodel_ReadOnlyCollection_Of_Rect_copyTo() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_objectmodel_ReadOnlyCollection_Of_Rect_copyTo";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Rect> _this =
					(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Rect>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.Rect[] arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.Rect[])_temp;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					_this.CopyTo((UnityEngine.Rect[])arg0,(System.Int32)arg1)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Rect>).GetMethod("CopyTo",new Type[] {typeof(UnityEngine.Rect[]),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_objectmodel_ReadOnlyCollection_Of_Rect_indexOf : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_objectmodel_ReadOnlyCollection_Of_Rect_indexOf() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_objectmodel_ReadOnlyCollection_Of_Rect_indexOf";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Rect> _this =
					(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Rect>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.Rect arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(UnityEngine.Rect);
					}
					else
					{
						LinkObj<UnityEngine.Rect> argObj = (LinkObj<UnityEngine.Rect>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					int _result_ = (int)(_this.IndexOf((UnityEngine.Rect)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.Rect>).GetMethod("IndexOf",new Type[] {typeof(UnityEngine.Rect)});;
				}
				return method;
			}

		}

	}
}
