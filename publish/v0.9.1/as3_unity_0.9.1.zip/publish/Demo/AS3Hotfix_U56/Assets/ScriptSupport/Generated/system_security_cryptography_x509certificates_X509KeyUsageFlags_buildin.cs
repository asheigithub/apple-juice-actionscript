using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_security_cryptography_x509certificates_X509KeyUsageFlags_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_security_cryptography_x509certificates_X509KeyUsageFlags_creator", default(System.Security.Cryptography.X509Certificates.X509KeyUsageFlags)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509KeyUsageFlags_buildin.system_security_cryptography_x509certificates_X509KeyUsageFlags_ctor","system_security_cryptography_x509certificates_X509KeyUsageFlags_ctor");
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509KeyUsageFlags_None_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509KeyUsageFlags.None;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509KeyUsageFlags_EncipherOnly_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509KeyUsageFlags.EncipherOnly;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509KeyUsageFlags_CrlSign_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509KeyUsageFlags.CrlSign;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509KeyUsageFlags_KeyCertSign_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509KeyUsageFlags.KeyCertSign;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509KeyUsageFlags_KeyAgreement_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509KeyUsageFlags.KeyAgreement;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509KeyUsageFlags_DataEncipherment_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509KeyUsageFlags.DataEncipherment;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509KeyUsageFlags_KeyEncipherment_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509KeyUsageFlags.KeyEncipherment;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509KeyUsageFlags_NonRepudiation_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509KeyUsageFlags.NonRepudiation;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509KeyUsageFlags_DigitalSignature_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509KeyUsageFlags.DigitalSignature;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509KeyUsageFlags_DecipherOnly_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509KeyUsageFlags.DecipherOnly;}));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509KeyUsageFlags_buildin.system_security_cryptography_x509certificates_X509KeyUsageFlags_operator_bitOr","system_security_cryptography_x509certificates_X509KeyUsageFlags_operator_bitOr");
		}

		public class system_security_cryptography_x509certificates_X509KeyUsageFlags_ctor : NativeFunctionBase
		{
			public system_security_cryptography_x509certificates_X509KeyUsageFlags_ctor()
			{
				para = new List<RunTimeDataType>();
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509KeyUsageFlags_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override RunTimeValueBase execute(RunTimeValueBase thisObj, SLOT[] argements, object stackframe, out string errormessage, out int errorno)
			{
				errormessage = null; errorno = 0;
				return ASBinCode.rtData.rtUndefined.undefined;

			}
		}

		public class system_security_cryptography_x509certificates_X509KeyUsageFlags_operator_bitOr : ASRuntime.nativefuncs.NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509KeyUsageFlags_operator_bitOr() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509KeyUsageFlags_operator_bitOr";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				System.Security.Cryptography.X509Certificates.X509KeyUsageFlags ts1;

				if (argements[0].rtType == RunTimeDataType.rt_null)
				{
					ts1 = default(System.Security.Cryptography.X509Certificates.X509KeyUsageFlags);
				}
				else
				{
					LinkObj<object> argObj = (LinkObj<object>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
					ts1 = (System.Security.Cryptography.X509Certificates.X509KeyUsageFlags)argObj.value;
				}

				System.Security.Cryptography.X509Certificates.X509KeyUsageFlags ts2;

				if (argements[1].rtType == RunTimeDataType.rt_null)
				{
					ts2 = default(System.Security.Cryptography.X509Certificates.X509KeyUsageFlags);
				}
				else
				{
					LinkObj<object> argObj = (LinkObj<object>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
					ts2 = (System.Security.Cryptography.X509Certificates.X509KeyUsageFlags)argObj.value;
				}

				((StackSlot)returnSlot).setLinkObjectValue(
					bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, ts1 | ts2);

				success = true;
			}
		}

	}
}
