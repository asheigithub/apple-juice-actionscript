using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_collections_specialized_BitVector32_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_collections_specialized_BitVector32_creator", default(System.Collections.Specialized.BitVector32)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_BitVector32_buildin.system_collections_specialized_BitVector32_constructor_","system_collections_specialized_BitVector32_constructor_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_BitVector32_buildin.system_collections_specialized_BitVector32_ctor","system_collections_specialized_BitVector32_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_BitVector32_buildin.system_collections_specialized_BitVector32_get_Data","system_collections_specialized_BitVector32_get_Data");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_BitVector32_buildin.system_collections_specialized_BitVector32_getThisItem","system_collections_specialized_BitVector32_getThisItem");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_BitVector32_buildin.system_collections_specialized_BitVector32_setThisItem","system_collections_specialized_BitVector32_setThisItem");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_BitVector32_buildin.system_collections_specialized_BitVector32_get_Item_","system_collections_specialized_BitVector32_get_Item_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_BitVector32_buildin.system_collections_specialized_BitVector32_set_Item_","system_collections_specialized_BitVector32_set_Item_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_BitVector32_buildin.static_system_collections_specialized_BitVector32_createMask","static_system_collections_specialized_BitVector32_createMask");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_BitVector32_buildin.static_system_collections_specialized_BitVector32_createMask_","static_system_collections_specialized_BitVector32_createMask_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_BitVector32_buildin.static_system_collections_specialized_BitVector32_createSection","static_system_collections_specialized_BitVector32_createSection");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_BitVector32_buildin.static_system_collections_specialized_BitVector32_createSection_","static_system_collections_specialized_BitVector32_createSection_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_BitVector32_buildin.static_system_collections_specialized_BitVector32_toString","static_system_collections_specialized_BitVector32_toString");
		}


		public class system_collections_specialized_BitVector32_constructor_ : NativeConstParameterFunction
		{
			public system_collections_specialized_BitVector32_constructor_() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_BitVector32_constructor_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Collections.Specialized.BitVector32((System.Int32)arg0));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_specialized_BitVector32_ctor : NativeConstParameterFunction
		{
			public system_collections_specialized_BitVector32_ctor() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_BitVector32_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.Collections.Specialized.BitVector32 arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Collections.Specialized.BitVector32);
					}
					else
					{
						LinkObj<System.Collections.Specialized.BitVector32> argObj = (LinkObj<System.Collections.Specialized.BitVector32>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					((LinkObj<System.Collections.Specialized.BitVector32>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new System.Collections.Specialized.BitVector32((System.Collections.Specialized.BitVector32)arg0);
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_specialized_BitVector32_get_Data : NativeConstParameterFunction
		{
			public system_collections_specialized_BitVector32_get_Data() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_BitVector32_get_Data";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.BitVector32 _this =
					(System.Collections.Specialized.BitVector32)((LinkObj<System.Collections.Specialized.BitVector32>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					int _result_ = (int)(_this.Data
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.Collections.Specialized.BitVector32>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_specialized_BitVector32_getThisItem : NativeConstParameterFunction
		{
			public system_collections_specialized_BitVector32_getThisItem() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_BitVector32_getThisItem";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.BitVector32 _this =
					(System.Collections.Specialized.BitVector32)((LinkObj<System.Collections.Specialized.BitVector32>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					System.Collections.Specialized.BitVector32.Section arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Collections.Specialized.BitVector32.Section);
					}
					else
					{
						LinkObj<System.Collections.Specialized.BitVector32.Section> argObj = (LinkObj<System.Collections.Specialized.BitVector32.Section>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					int _result_ = (int)(_this[(System.Collections.Specialized.BitVector32.Section)arg0]
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.Collections.Specialized.BitVector32>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_specialized_BitVector32_setThisItem : NativeConstParameterFunction
		{
			public system_collections_specialized_BitVector32_setThisItem() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_BitVector32_setThisItem";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.BitVector32 _this =
					(System.Collections.Specialized.BitVector32)((LinkObj<System.Collections.Specialized.BitVector32>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					System.Collections.Specialized.BitVector32.Section arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Collections.Specialized.BitVector32.Section);
					}
					else
					{
						LinkObj<System.Collections.Specialized.BitVector32.Section> argObj = (LinkObj<System.Collections.Specialized.BitVector32.Section>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					_this[(System.Collections.Specialized.BitVector32.Section)arg1] = (System.Int32)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<System.Collections.Specialized.BitVector32>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_specialized_BitVector32_get_Item_ : NativeConstParameterFunction
		{
			public system_collections_specialized_BitVector32_get_Item_() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_BitVector32_get_Item_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.BitVector32 _this =
					(System.Collections.Specialized.BitVector32)((LinkObj<System.Collections.Specialized.BitVector32>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					bool _result_ = _this[(System.Int32)arg0]
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					((LinkObj<System.Collections.Specialized.BitVector32>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_specialized_BitVector32_set_Item_ : NativeConstParameterFunction
		{
			public system_collections_specialized_BitVector32_set_Item_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_boolean);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_BitVector32_set_Item_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.BitVector32 _this =
					(System.Collections.Specialized.BitVector32)((LinkObj<System.Collections.Specialized.BitVector32>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					bool arg0 = TypeConverter.ConvertToBoolean(argements[0], stackframe, token).value;
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					_this[(System.Int32)arg1] = (System.Boolean)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<System.Collections.Specialized.BitVector32>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_collections_specialized_BitVector32_createMask : NativeConstParameterFunction
		{
			public static_system_collections_specialized_BitVector32_createMask() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_collections_specialized_BitVector32_createMask";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{

					int _result_ = (int)(System.Collections.Specialized.BitVector32.CreateMask()
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_collections_specialized_BitVector32_createMask_ : NativeConstParameterFunction
		{
			public static_system_collections_specialized_BitVector32_createMask_() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_collections_specialized_BitVector32_createMask_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					int _result_ = (int)(System.Collections.Specialized.BitVector32.CreateMask((System.Int32)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_collections_specialized_BitVector32_createSection : NativeConstParameterFunction
		{
			public static_system_collections_specialized_BitVector32_createSection() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_collections_specialized_BitVector32_createSection";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					short arg0 = (short)TypeConverter.ConvertToInt(argements[0]);

					System.Collections.Specialized.BitVector32.Section _result_ = System.Collections.Specialized.BitVector32.CreateSection((System.Int16)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_collections_specialized_BitVector32_createSection_ : NativeConstParameterFunction
		{
			public static_system_collections_specialized_BitVector32_createSection_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_collections_specialized_BitVector32_createSection_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					short arg0 = (short)TypeConverter.ConvertToInt(argements[0]);
					System.Collections.Specialized.BitVector32.Section arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Collections.Specialized.BitVector32.Section);
					}
					else
					{
						LinkObj<System.Collections.Specialized.BitVector32.Section> argObj = (LinkObj<System.Collections.Specialized.BitVector32.Section>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					System.Collections.Specialized.BitVector32.Section _result_ = System.Collections.Specialized.BitVector32.CreateSection((System.Int16)arg0,(System.Collections.Specialized.BitVector32.Section)arg1)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_collections_specialized_BitVector32_toString : NativeConstParameterFunction
		{
			public static_system_collections_specialized_BitVector32_toString() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_collections_specialized_BitVector32_toString";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Collections.Specialized.BitVector32 arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Collections.Specialized.BitVector32);
					}
					else
					{
						LinkObj<System.Collections.Specialized.BitVector32> argObj = (LinkObj<System.Collections.Specialized.BitVector32>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					string _result_ = (string)(System.Collections.Specialized.BitVector32.ToString((System.Collections.Specialized.BitVector32)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

	}
}
