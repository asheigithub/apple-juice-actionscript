using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_security_authentication_SslProtocols_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_security_authentication_SslProtocols_creator", default(System.Security.Authentication.SslProtocols)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_authentication_SslProtocols_buildin.system_security_authentication_SslProtocols_ctor","system_security_authentication_SslProtocols_ctor");
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_authentication_SslProtocols_None_getter",()=>{ return System.Security.Authentication.SslProtocols.None;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_authentication_SslProtocols_Ssl2_getter",()=>{ return System.Security.Authentication.SslProtocols.Ssl2;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_authentication_SslProtocols_Ssl3_getter",()=>{ return System.Security.Authentication.SslProtocols.Ssl3;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_authentication_SslProtocols_Tls_getter",()=>{ return System.Security.Authentication.SslProtocols.Tls;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_authentication_SslProtocols_Default_getter",()=>{ return System.Security.Authentication.SslProtocols.Default;}));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_authentication_SslProtocols_buildin.system_security_authentication_SslProtocols_operator_bitOr","system_security_authentication_SslProtocols_operator_bitOr");
		}

		public class system_security_authentication_SslProtocols_ctor : NativeFunctionBase
		{
			public system_security_authentication_SslProtocols_ctor()
			{
				para = new List<RunTimeDataType>();
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_authentication_SslProtocols_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override RunTimeValueBase execute(RunTimeValueBase thisObj, SLOT[] argements, object stackframe, out string errormessage, out int errorno)
			{
				errormessage = null; errorno = 0;
				return ASBinCode.rtData.rtUndefined.undefined;

			}
		}

		public class system_security_authentication_SslProtocols_operator_bitOr : ASRuntime.nativefuncs.NativeConstParameterFunction
		{
			public system_security_authentication_SslProtocols_operator_bitOr() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_authentication_SslProtocols_operator_bitOr";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				System.Security.Authentication.SslProtocols ts1;

				if (argements[0].rtType == RunTimeDataType.rt_null)
				{
					ts1 = default(System.Security.Authentication.SslProtocols);
				}
				else
				{
					LinkObj<object> argObj = (LinkObj<object>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
					ts1 = (System.Security.Authentication.SslProtocols)argObj.value;
				}

				System.Security.Authentication.SslProtocols ts2;

				if (argements[1].rtType == RunTimeDataType.rt_null)
				{
					ts2 = default(System.Security.Authentication.SslProtocols);
				}
				else
				{
					LinkObj<object> argObj = (LinkObj<object>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
					ts2 = (System.Security.Authentication.SslProtocols)argObj.value;
				}

				((StackSlot)returnSlot).setLinkObjectValue(
					bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, ts1 | ts2);

				success = true;
			}
		}

	}
}
