using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class unityengine_ai_NavMeshLinkData_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("unityengine_ai_NavMeshLinkData_creator", default(UnityEngine.AI.NavMeshLinkData)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshLinkData_buildin.unityengine_ai_NavMeshLinkData_ctor","unityengine_ai_NavMeshLinkData_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshLinkData_buildin.unityengine_ai_NavMeshLinkData_get_startPosition","unityengine_ai_NavMeshLinkData_get_startPosition");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshLinkData_buildin.unityengine_ai_NavMeshLinkData_set_startPosition","unityengine_ai_NavMeshLinkData_set_startPosition");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshLinkData_buildin.unityengine_ai_NavMeshLinkData_get_endPosition","unityengine_ai_NavMeshLinkData_get_endPosition");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshLinkData_buildin.unityengine_ai_NavMeshLinkData_set_endPosition","unityengine_ai_NavMeshLinkData_set_endPosition");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshLinkData_buildin.unityengine_ai_NavMeshLinkData_get_costModifier","unityengine_ai_NavMeshLinkData_get_costModifier");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshLinkData_buildin.unityengine_ai_NavMeshLinkData_set_costModifier","unityengine_ai_NavMeshLinkData_set_costModifier");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshLinkData_buildin.unityengine_ai_NavMeshLinkData_get_bidirectional","unityengine_ai_NavMeshLinkData_get_bidirectional");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshLinkData_buildin.unityengine_ai_NavMeshLinkData_set_bidirectional","unityengine_ai_NavMeshLinkData_set_bidirectional");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshLinkData_buildin.unityengine_ai_NavMeshLinkData_get_width","unityengine_ai_NavMeshLinkData_get_width");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshLinkData_buildin.unityengine_ai_NavMeshLinkData_set_width","unityengine_ai_NavMeshLinkData_set_width");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshLinkData_buildin.unityengine_ai_NavMeshLinkData_get_area","unityengine_ai_NavMeshLinkData_get_area");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshLinkData_buildin.unityengine_ai_NavMeshLinkData_set_area","unityengine_ai_NavMeshLinkData_set_area");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshLinkData_buildin.unityengine_ai_NavMeshLinkData_get_agentTypeID","unityengine_ai_NavMeshLinkData_get_agentTypeID");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshLinkData_buildin.unityengine_ai_NavMeshLinkData_set_agentTypeID","unityengine_ai_NavMeshLinkData_set_agentTypeID");
		}


		public class unityengine_ai_NavMeshLinkData_ctor : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshLinkData_ctor() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshLinkData_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{

					((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new UnityEngine.AI.NavMeshLinkData();
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshLinkData_get_startPosition : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshLinkData_get_startPosition() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshLinkData_get_startPosition";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshLinkData _this =
					(UnityEngine.AI.NavMeshLinkData)((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					UnityEngine.Vector3 _result_ = _this.startPosition
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshLinkData_set_startPosition : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshLinkData_set_startPosition() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshLinkData_set_startPosition";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshLinkData _this =
					(UnityEngine.AI.NavMeshLinkData)((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					UnityEngine.Vector3 arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(UnityEngine.Vector3);
					}
					else
					{
						LinkObj<UnityEngine.Vector3> argObj = (LinkObj<UnityEngine.Vector3>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					_this.startPosition = (UnityEngine.Vector3)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshLinkData_get_endPosition : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshLinkData_get_endPosition() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshLinkData_get_endPosition";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshLinkData _this =
					(UnityEngine.AI.NavMeshLinkData)((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					UnityEngine.Vector3 _result_ = _this.endPosition
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshLinkData_set_endPosition : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshLinkData_set_endPosition() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshLinkData_set_endPosition";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshLinkData _this =
					(UnityEngine.AI.NavMeshLinkData)((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					UnityEngine.Vector3 arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(UnityEngine.Vector3);
					}
					else
					{
						LinkObj<UnityEngine.Vector3> argObj = (LinkObj<UnityEngine.Vector3>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					_this.endPosition = (UnityEngine.Vector3)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshLinkData_get_costModifier : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshLinkData_get_costModifier() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshLinkData_get_costModifier";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_number;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshLinkData _this =
					(UnityEngine.AI.NavMeshLinkData)((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					double _result_ = (double)(_this.costModifier
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshLinkData_set_costModifier : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshLinkData_set_costModifier() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_number);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshLinkData_set_costModifier";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshLinkData _this =
					(UnityEngine.AI.NavMeshLinkData)((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					float arg0 = (float)TypeConverter.ConvertToNumber(argements[0]);

					_this.costModifier = (System.Single)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshLinkData_get_bidirectional : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshLinkData_get_bidirectional() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshLinkData_get_bidirectional";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshLinkData _this =
					(UnityEngine.AI.NavMeshLinkData)((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					bool _result_ = _this.bidirectional
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshLinkData_set_bidirectional : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshLinkData_set_bidirectional() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_boolean);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshLinkData_set_bidirectional";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshLinkData _this =
					(UnityEngine.AI.NavMeshLinkData)((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					bool arg0 = TypeConverter.ConvertToBoolean(argements[0], stackframe, token).value;

					_this.bidirectional = (System.Boolean)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshLinkData_get_width : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshLinkData_get_width() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshLinkData_get_width";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_number;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshLinkData _this =
					(UnityEngine.AI.NavMeshLinkData)((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					double _result_ = (double)(_this.width
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshLinkData_set_width : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshLinkData_set_width() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_number);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshLinkData_set_width";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshLinkData _this =
					(UnityEngine.AI.NavMeshLinkData)((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					float arg0 = (float)TypeConverter.ConvertToNumber(argements[0]);

					_this.width = (System.Single)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshLinkData_get_area : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshLinkData_get_area() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshLinkData_get_area";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshLinkData _this =
					(UnityEngine.AI.NavMeshLinkData)((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					int _result_ = (int)(_this.area
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshLinkData_set_area : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshLinkData_set_area() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshLinkData_set_area";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshLinkData _this =
					(UnityEngine.AI.NavMeshLinkData)((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					_this.area = (System.Int32)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshLinkData_get_agentTypeID : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshLinkData_get_agentTypeID() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshLinkData_get_agentTypeID";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshLinkData _this =
					(UnityEngine.AI.NavMeshLinkData)((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					int _result_ = (int)(_this.agentTypeID
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshLinkData_set_agentTypeID : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshLinkData_set_agentTypeID() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshLinkData_set_agentTypeID";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshLinkData _this =
					(UnityEngine.AI.NavMeshLinkData)((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					_this.agentTypeID = (System.Int32)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<UnityEngine.AI.NavMeshLinkData>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

	}
}
