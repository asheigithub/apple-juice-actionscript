using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_Decimal_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_Decimal_creator", default(System.Decimal)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.system_Decimal_constructor_","system_Decimal_constructor_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.system_Decimal_constructor__","system_Decimal_constructor__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.system_Decimal_constructor___","system_Decimal_constructor___");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.system_Decimal_constructor____","system_Decimal_constructor____");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.system_Decimal_constructor_____","system_Decimal_constructor_____");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.system_Decimal_constructor______","system_Decimal_constructor______");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.system_Decimal_constructor_______","system_Decimal_constructor_______");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.system_Decimal_ctor","system_Decimal_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.system_Decimal_Zero_getter","system_Decimal_Zero_getter");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.system_Decimal_One_getter","system_Decimal_One_getter");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.system_Decimal_MinusOne_getter","system_Decimal_MinusOne_getter");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.system_Decimal_MaxValue_getter","system_Decimal_MaxValue_getter");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.system_Decimal_MinValue_getter","system_Decimal_MinValue_getter");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_toOACurrency","static_system_Decimal_toOACurrency");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_fromOACurrency","static_system_Decimal_fromOACurrency");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_add","static_system_Decimal_add");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_ceiling","static_system_Decimal_ceiling");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_compare","static_system_Decimal_compare");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.system_Decimal_compareTo_","system_Decimal_compareTo_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_divide","static_system_Decimal_divide");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.system_Decimal_equals___","system_Decimal_equals___");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_equals","static_system_Decimal_equals");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_floor","static_system_Decimal_floor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.system_Decimal_toString___","system_Decimal_toString___");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_parse","static_system_Decimal_parse");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_parse_","static_system_Decimal_parse_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_parse__","static_system_Decimal_parse__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_parse___","static_system_Decimal_parse___");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_tryParse","static_system_Decimal_tryParse");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_tryParse_","static_system_Decimal_tryParse_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_getBits","static_system_Decimal_getBits");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_remainder","static_system_Decimal_remainder");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_multiply","static_system_Decimal_multiply");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_negate","static_system_Decimal_negate");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_round","static_system_Decimal_round");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_round_","static_system_Decimal_round_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_round__","static_system_Decimal_round__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_round___","static_system_Decimal_round___");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_subtract","static_system_Decimal_subtract");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_toByte","static_system_Decimal_toByte");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_toSByte","static_system_Decimal_toSByte");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_toInt16","static_system_Decimal_toInt16");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_toDouble","static_system_Decimal_toDouble");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_toInt32","static_system_Decimal_toInt32");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_toInt64","static_system_Decimal_toInt64");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_toUInt16","static_system_Decimal_toUInt16");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_toUInt32","static_system_Decimal_toUInt32");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_toUInt64","static_system_Decimal_toUInt64");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_toSingle","static_system_Decimal_toSingle");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_truncate","static_system_Decimal_truncate");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Implicit","static_system_Decimal_op_Implicit");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Implicit_","static_system_Decimal_op_Implicit_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Implicit__","static_system_Decimal_op_Implicit__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Implicit___","static_system_Decimal_op_Implicit___");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Implicit____","static_system_Decimal_op_Implicit____");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Implicit_____","static_system_Decimal_op_Implicit_____");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Implicit______","static_system_Decimal_op_Implicit______");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Implicit_______","static_system_Decimal_op_Implicit_______");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Implicit________","static_system_Decimal_op_Implicit________");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Explicit","static_system_Decimal_op_Explicit");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Explicit_","static_system_Decimal_op_Explicit_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Explicit__","static_system_Decimal_op_Explicit__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Explicit___","static_system_Decimal_op_Explicit___");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Explicit____","static_system_Decimal_op_Explicit____");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Explicit_____","static_system_Decimal_op_Explicit_____");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Explicit______","static_system_Decimal_op_Explicit______");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Explicit_______","static_system_Decimal_op_Explicit_______");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Explicit________","static_system_Decimal_op_Explicit________");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Explicit_________","static_system_Decimal_op_Explicit_________");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Explicit__________","static_system_Decimal_op_Explicit__________");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Explicit___________","static_system_Decimal_op_Explicit___________");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Explicit____________","static_system_Decimal_op_Explicit____________");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_UnaryPlus","static_system_Decimal_op_UnaryPlus");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_UnaryNegation","static_system_Decimal_op_UnaryNegation");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Increment","static_system_Decimal_op_Increment");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Decrement","static_system_Decimal_op_Decrement");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Addition","static_system_Decimal_op_Addition");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Subtraction","static_system_Decimal_op_Subtraction");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Multiply","static_system_Decimal_op_Multiply");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Division","static_system_Decimal_op_Division");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Modulus","static_system_Decimal_op_Modulus");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Equality","static_system_Decimal_op_Equality");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_Inequality","static_system_Decimal_op_Inequality");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_LessThan","static_system_Decimal_op_LessThan");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_LessThanOrEqual","static_system_Decimal_op_LessThanOrEqual");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_GreaterThan","static_system_Decimal_op_GreaterThan");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.static_system_Decimal_op_GreaterThanOrEqual","static_system_Decimal_op_GreaterThanOrEqual");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Decimal_buildin.system_Decimal_valueOf","system_Decimal_valueOf");
		}


		public class system_Decimal_constructor_ : NativeConstParameterFunction
		{
			public system_Decimal_constructor_() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_uint);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Decimal_constructor_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					uint arg0 = TypeConverter.ConvertToUInt(argements[0], stackframe, token);

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Decimal((System.UInt32)arg0));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_Decimal_constructor__ : NativeConstParameterFunction
		{
			public system_Decimal_constructor__() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Decimal_constructor__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.Int64 arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Int64);
					}
					else
					{
						LinkObj<System.Int64> argObj = (LinkObj<System.Int64>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Decimal((System.Int64)arg0));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_Decimal_constructor___ : NativeConstParameterFunction
		{
			public system_Decimal_constructor___() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Decimal_constructor___";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.UInt64 arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.UInt64);
					}
					else
					{
						LinkObj<System.UInt64> argObj = (LinkObj<System.UInt64>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Decimal((System.UInt64)arg0));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_Decimal_constructor____ : NativeConstParameterFunction
		{
			public system_Decimal_constructor____() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_number);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Decimal_constructor____";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					float arg0 = (float)TypeConverter.ConvertToNumber(argements[0]);

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Decimal((System.Single)arg0));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_Decimal_constructor_____ : NativeConstParameterFunction
		{
			public system_Decimal_constructor_____() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_number);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Decimal_constructor_____";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					double arg0 = TypeConverter.ConvertToNumber(argements[0]);

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Decimal((System.Double)arg0));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_Decimal_constructor______ : NativeConstParameterFunction
		{
			public system_Decimal_constructor______() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Decimal_constructor______";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.Int32[] arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Int32[])_temp;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Decimal((System.Int32[])arg0));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_Decimal_constructor_______ : NativeConstParameterFunction
		{
			public system_Decimal_constructor_______() : base(5)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_boolean);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Decimal_constructor_______";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					int arg2 = TypeConverter.ConvertToInt(argements[2]);
					bool arg3 = TypeConverter.ConvertToBoolean(argements[3], stackframe, token).value;
					System.Byte arg4;

					if (argements[4].rtType == RunTimeDataType.rt_null)
					{
						arg4 = default(System.Byte);
					}
					else
					{
						LinkObj<System.Byte> argObj = (LinkObj<System.Byte>)((ASBinCode.rtData.rtObjectBase)argements[4]).value;
						arg4 = argObj.value;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Decimal((System.Int32)arg0,(System.Int32)arg1,(System.Int32)arg2,(System.Boolean)arg3,(System.Byte)arg4));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_Decimal_ctor : NativeConstParameterFunction
		{
			public system_Decimal_ctor() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Decimal_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					((LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new System.Decimal((System.Int32)arg0);
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_Decimal_Zero_getter : NativeConstParameterFunction
		{
			public system_Decimal_Zero_getter() : base(0)
			{
				para = new List<RunTimeDataType>();
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Decimal_Zero_getter";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.Decimal _result_ = System.Decimal.Zero					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);

					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_Decimal_One_getter : NativeConstParameterFunction
		{
			public system_Decimal_One_getter() : base(0)
			{
				para = new List<RunTimeDataType>();
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Decimal_One_getter";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.Decimal _result_ = System.Decimal.One					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);

					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_Decimal_MinusOne_getter : NativeConstParameterFunction
		{
			public system_Decimal_MinusOne_getter() : base(0)
			{
				para = new List<RunTimeDataType>();
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Decimal_MinusOne_getter";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.Decimal _result_ = System.Decimal.MinusOne					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);

					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_Decimal_MaxValue_getter : NativeConstParameterFunction
		{
			public system_Decimal_MaxValue_getter() : base(0)
			{
				para = new List<RunTimeDataType>();
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Decimal_MaxValue_getter";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.Decimal _result_ = System.Decimal.MaxValue					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);

					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_Decimal_MinValue_getter : NativeConstParameterFunction
		{
			public system_Decimal_MinValue_getter() : base(0)
			{
				para = new List<RunTimeDataType>();
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Decimal_MinValue_getter";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.Decimal _result_ = System.Decimal.MinValue					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);

					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_toOACurrency : NativeConstParameterFunction
		{
			public static_system_Decimal_toOACurrency() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_toOACurrency";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.Int64 _result_ = System.Decimal.ToOACurrency((System.Decimal)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_fromOACurrency : NativeConstParameterFunction
		{
			public static_system_Decimal_fromOACurrency() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_fromOACurrency";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Int64 arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Int64);
					}
					else
					{
						LinkObj<System.Int64> argObj = (LinkObj<System.Int64>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.Decimal _result_ = System.Decimal.FromOACurrency((System.Int64)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_add : NativeConstParameterFunction
		{
			public static_system_Decimal_add() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_add";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.Decimal arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					System.Decimal _result_ = System.Decimal.Add((System.Decimal)arg0,(System.Decimal)arg1)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_ceiling : NativeConstParameterFunction
		{
			public static_system_Decimal_ceiling() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_ceiling";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.Decimal _result_ = System.Decimal.Ceiling((System.Decimal)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_compare : NativeConstParameterFunction
		{
			public static_system_Decimal_compare() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_compare";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.Decimal arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					int _result_ = (int)(System.Decimal.Compare((System.Decimal)arg0,(System.Decimal)arg1)
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_Decimal_compareTo_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_Decimal_compareTo_() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Decimal_compareTo_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Decimal _this =
					(System.Decimal)((LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					int _result_ = (int)(_this.CompareTo((System.Decimal)arg0)
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Decimal).GetMethod("CompareTo",new Type[] {typeof(System.Decimal)});;
				}
				return method;
			}

		}

		public class static_system_Decimal_divide : NativeConstParameterFunction
		{
			public static_system_Decimal_divide() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_divide";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.Decimal arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					System.Decimal _result_ = System.Decimal.Divide((System.Decimal)arg0,(System.Decimal)arg1)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_Decimal_equals___ : NativeConstParameterFunction,IMethodGetter
		{
			public system_Decimal_equals___() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Decimal_equals___";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Decimal _this =
					(System.Decimal)((LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					bool _result_ = _this.Equals((System.Decimal)arg0)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					((LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Decimal).GetMethod("Equals",new Type[] {typeof(System.Decimal)});;
				}
				return method;
			}

		}

		public class static_system_Decimal_equals : NativeConstParameterFunction
		{
			public static_system_Decimal_equals() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_equals";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.Decimal arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					bool _result_ = System.Decimal.Equals((System.Decimal)arg0,(System.Decimal)arg1)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_floor : NativeConstParameterFunction
		{
			public static_system_Decimal_floor() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_floor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.Decimal _result_ = System.Decimal.Floor((System.Decimal)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_Decimal_toString___ : NativeConstParameterFunction,IMethodGetter
		{
			public system_Decimal_toString___() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Decimal_toString___";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Decimal _this =
					(System.Decimal)((LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					string _result_ = (string)(_this.ToString((System.String)arg0)
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Decimal).GetMethod("ToString",new Type[] {typeof(System.String)});;
				}
				return method;
			}

		}

		public class static_system_Decimal_parse : NativeConstParameterFunction
		{
			public static_system_Decimal_parse() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_parse";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					System.Decimal _result_ = System.Decimal.Parse((System.String)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_parse_ : NativeConstParameterFunction
		{
			public static_system_Decimal_parse_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_parse_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					System.Globalization.NumberStyles arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Globalization.NumberStyles)_temp;
					}

					System.Decimal _result_ = System.Decimal.Parse((System.String)arg0,(System.Globalization.NumberStyles)arg1)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_parse__ : NativeConstParameterFunction
		{
			public static_system_Decimal_parse__() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_parse__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					System.IFormatProvider arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.IFormatProvider)_temp;
					}

					System.Decimal _result_ = System.Decimal.Parse((System.String)arg0,(System.IFormatProvider)arg1)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_parse___ : NativeConstParameterFunction
		{
			public static_system_Decimal_parse___() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_parse___";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					System.Globalization.NumberStyles arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Globalization.NumberStyles)_temp;
					}
					System.IFormatProvider arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.IFormatProvider)_temp;
					}

					System.Decimal _result_ = System.Decimal.Parse((System.String)arg0,(System.Globalization.NumberStyles)arg1,(System.IFormatProvider)arg2)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_tryParse : NativeConstParameterFunction
		{
			public static_system_Decimal_tryParse() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_tryParse";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					System.Decimal arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}
					ASRuntime.nativefuncs.linksystem.RefOutStore arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (ASRuntime.nativefuncs.linksystem.RefOutStore)_temp;
					}

					bool _result_ = System.Decimal.TryParse((System.String)arg0,out arg1)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					if (arg2 != null)
					{
						arg2.Clear();
					}

					if (arg2 != null)
					{
						arg2.SetValue(functionDefine.signature.parameters[1].name, arg1);
					}

					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_tryParse_ : NativeConstParameterFunction
		{
			public static_system_Decimal_tryParse_() : base(5)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_tryParse_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					System.Globalization.NumberStyles arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Globalization.NumberStyles)_temp;
					}
					System.IFormatProvider arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.IFormatProvider)_temp;
					}
					System.Decimal arg3;

					if (argements[3].rtType == RunTimeDataType.rt_null)
					{
						arg3 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[3]).value;
						arg3 = argObj.value;
					}
					ASRuntime.nativefuncs.linksystem.RefOutStore arg4;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[4],

							stackframe.player.linktypemapper.getLinkType(argements[4].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[4].rtType,

								functionDefine.signature.parameters[4].type
								);
							success = false;
							return;
						}
						arg4 = (ASRuntime.nativefuncs.linksystem.RefOutStore)_temp;
					}

					bool _result_ = System.Decimal.TryParse((System.String)arg0,(System.Globalization.NumberStyles)arg1,(System.IFormatProvider)arg2,out arg3)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					if (arg4 != null)
					{
						arg4.Clear();
					}

					if (arg4 != null)
					{
						arg4.SetValue(functionDefine.signature.parameters[3].name, arg3);
					}

					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_getBits : NativeConstParameterFunction
		{
			public static_system_Decimal_getBits() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_getBits";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					object _result_ = System.Decimal.GetBits((System.Decimal)arg0)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_remainder : NativeConstParameterFunction
		{
			public static_system_Decimal_remainder() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_remainder";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.Decimal arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					System.Decimal _result_ = System.Decimal.Remainder((System.Decimal)arg0,(System.Decimal)arg1)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_multiply : NativeConstParameterFunction
		{
			public static_system_Decimal_multiply() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_multiply";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.Decimal arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					System.Decimal _result_ = System.Decimal.Multiply((System.Decimal)arg0,(System.Decimal)arg1)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_negate : NativeConstParameterFunction
		{
			public static_system_Decimal_negate() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_negate";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.Decimal _result_ = System.Decimal.Negate((System.Decimal)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_round : NativeConstParameterFunction
		{
			public static_system_Decimal_round() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_round";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.Decimal _result_ = System.Decimal.Round((System.Decimal)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_round_ : NativeConstParameterFunction
		{
			public static_system_Decimal_round_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_round_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					System.Decimal _result_ = System.Decimal.Round((System.Decimal)arg0,(System.Int32)arg1)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_round__ : NativeConstParameterFunction
		{
			public static_system_Decimal_round__() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_round__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.MidpointRounding arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.MidpointRounding)_temp;
					}

					System.Decimal _result_ = System.Decimal.Round((System.Decimal)arg0,(System.MidpointRounding)arg1)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_round___ : NativeConstParameterFunction
		{
			public static_system_Decimal_round___() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_round___";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					System.MidpointRounding arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.MidpointRounding)_temp;
					}

					System.Decimal _result_ = System.Decimal.Round((System.Decimal)arg0,(System.Int32)arg1,(System.MidpointRounding)arg2)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_subtract : NativeConstParameterFunction
		{
			public static_system_Decimal_subtract() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_subtract";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.Decimal arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					System.Decimal _result_ = System.Decimal.Subtract((System.Decimal)arg0,(System.Decimal)arg1)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_toByte : NativeConstParameterFunction
		{
			public static_system_Decimal_toByte() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_toByte";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.Byte _result_ = System.Decimal.ToByte((System.Decimal)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_toSByte : NativeConstParameterFunction
		{
			public static_system_Decimal_toSByte() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_toSByte";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.SByte _result_ = System.Decimal.ToSByte((System.Decimal)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_toInt16 : NativeConstParameterFunction
		{
			public static_system_Decimal_toInt16() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_toInt16";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					int _result_ = (int)(System.Decimal.ToInt16((System.Decimal)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_toDouble : NativeConstParameterFunction
		{
			public static_system_Decimal_toDouble() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_toDouble";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_number;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					double _result_ = (double)(System.Decimal.ToDouble((System.Decimal)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_toInt32 : NativeConstParameterFunction
		{
			public static_system_Decimal_toInt32() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_toInt32";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					int _result_ = (int)(System.Decimal.ToInt32((System.Decimal)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_toInt64 : NativeConstParameterFunction
		{
			public static_system_Decimal_toInt64() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_toInt64";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.Int64 _result_ = System.Decimal.ToInt64((System.Decimal)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_toUInt16 : NativeConstParameterFunction
		{
			public static_system_Decimal_toUInt16() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_toUInt16";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_uint;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					uint _result_ = (uint)(System.Decimal.ToUInt16((System.Decimal)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_toUInt32 : NativeConstParameterFunction
		{
			public static_system_Decimal_toUInt32() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_toUInt32";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_uint;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					uint _result_ = (uint)(System.Decimal.ToUInt32((System.Decimal)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_toUInt64 : NativeConstParameterFunction
		{
			public static_system_Decimal_toUInt64() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_toUInt64";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.UInt64 _result_ = System.Decimal.ToUInt64((System.Decimal)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_toSingle : NativeConstParameterFunction
		{
			public static_system_Decimal_toSingle() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_toSingle";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_number;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					double _result_ = (double)(System.Decimal.ToSingle((System.Decimal)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_truncate : NativeConstParameterFunction
		{
			public static_system_Decimal_truncate() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_truncate";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.Decimal _result_ = System.Decimal.Truncate((System.Decimal)arg0)
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Implicit : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Implicit() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Implicit";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Byte arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Byte);
					}
					else
					{
						LinkObj<System.Byte> argObj = (LinkObj<System.Byte>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.Decimal _result_ = (System.Decimal)arg0
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Implicit_ : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Implicit_() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Implicit_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.SByte arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.SByte);
					}
					else
					{
						LinkObj<System.SByte> argObj = (LinkObj<System.SByte>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.Decimal _result_ = (System.Decimal)arg0
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Implicit__ : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Implicit__() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Implicit__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					short arg0 = (short)TypeConverter.ConvertToInt(argements[0]);

					System.Decimal _result_ = (System.Decimal)arg0
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Implicit___ : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Implicit___() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_uint);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Implicit___";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					ushort arg0 = (ushort)TypeConverter.ConvertToUInt(argements[0], stackframe, token);

					System.Decimal _result_ = (System.Decimal)arg0
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Implicit____ : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Implicit____() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Implicit____";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Char arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Char);
					}
					else
					{
						LinkObj<System.Char> argObj = (LinkObj<System.Char>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.Decimal _result_ = (System.Decimal)arg0
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Implicit_____ : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Implicit_____() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Implicit_____";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					System.Decimal _result_ = (System.Decimal)arg0
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Implicit______ : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Implicit______() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_uint);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Implicit______";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					uint arg0 = TypeConverter.ConvertToUInt(argements[0], stackframe, token);

					System.Decimal _result_ = (System.Decimal)arg0
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Implicit_______ : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Implicit_______() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Implicit_______";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Int64 arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Int64);
					}
					else
					{
						LinkObj<System.Int64> argObj = (LinkObj<System.Int64>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.Decimal _result_ = (System.Decimal)arg0
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Implicit________ : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Implicit________() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Implicit________";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.UInt64 arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.UInt64);
					}
					else
					{
						LinkObj<System.UInt64> argObj = (LinkObj<System.UInt64>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.Decimal _result_ = (System.Decimal)arg0
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Explicit : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Explicit() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_number);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Explicit";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					float arg0 = (float)TypeConverter.ConvertToNumber(argements[0]);

					System.Decimal _result_ = (System.Decimal)arg0
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Explicit_ : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Explicit_() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_number);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Explicit_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					double arg0 = TypeConverter.ConvertToNumber(argements[0]);

					System.Decimal _result_ = (System.Decimal)arg0
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Explicit__ : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Explicit__() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Explicit__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.Byte _result_ = (System.Byte)arg0
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Explicit___ : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Explicit___() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Explicit___";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.SByte _result_ = (System.SByte)arg0
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Explicit____ : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Explicit____() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Explicit____";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.Char _result_ = (System.Char)arg0
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Explicit_____ : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Explicit_____() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Explicit_____";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					int _result_ = (int)((System.Int16)arg0
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Explicit______ : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Explicit______() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Explicit______";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_uint;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					uint _result_ = (uint)((System.UInt16)arg0
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Explicit_______ : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Explicit_______() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Explicit_______";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					int _result_ = (int)((System.Int32)arg0
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Explicit________ : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Explicit________() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Explicit________";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_uint;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					uint _result_ = (uint)((System.UInt32)arg0
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Explicit_________ : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Explicit_________() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Explicit_________";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.Int64 _result_ = (System.Int64)arg0
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Explicit__________ : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Explicit__________() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Explicit__________";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.UInt64 _result_ = (System.UInt64)arg0
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Explicit___________ : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Explicit___________() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Explicit___________";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_number;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					double _result_ = (double)((System.Single)arg0
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Explicit____________ : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Explicit____________() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Explicit____________";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_number;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					double _result_ = (double)((System.Double)arg0
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_UnaryPlus : NativeConstParameterFunction
		{
			public static_system_Decimal_op_UnaryPlus() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_UnaryPlus";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.Decimal _result_ = +arg0					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_UnaryNegation : NativeConstParameterFunction
		{
			public static_system_Decimal_op_UnaryNegation() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_UnaryNegation";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.Decimal _result_ = -arg0					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Increment : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Increment() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Increment";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.Decimal _result_ = ++arg0					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Decrement : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Decrement() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Decrement";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					System.Decimal _result_ = --arg0					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Addition : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Addition() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Addition";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.Decimal arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					System.Decimal _result_ = arg0 + arg1					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Subtraction : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Subtraction() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Subtraction";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.Decimal arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					System.Decimal _result_ = arg0 - arg1					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Multiply : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Multiply() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Multiply";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.Decimal arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					System.Decimal _result_ = arg0 * arg1					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Division : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Division() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Division";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.Decimal arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					System.Decimal _result_ = arg0 / arg1					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Modulus : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Modulus() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Modulus";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.Decimal arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					System.Decimal _result_ = arg0 % arg1					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Equality : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Equality() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Equality";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.Decimal arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					bool _result_ = arg0 == arg1					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_Inequality : NativeConstParameterFunction
		{
			public static_system_Decimal_op_Inequality() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_Inequality";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.Decimal arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					bool _result_ = arg0 != arg1					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_LessThan : NativeConstParameterFunction
		{
			public static_system_Decimal_op_LessThan() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_LessThan";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.Decimal arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					bool _result_ = arg0 < arg1					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_LessThanOrEqual : NativeConstParameterFunction
		{
			public static_system_Decimal_op_LessThanOrEqual() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_LessThanOrEqual";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.Decimal arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					bool _result_ = arg0 <= arg1					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_GreaterThan : NativeConstParameterFunction
		{
			public static_system_Decimal_op_GreaterThan() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_GreaterThan";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.Decimal arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					bool _result_ = arg0 > arg1					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_Decimal_op_GreaterThanOrEqual : NativeConstParameterFunction
		{
			public static_system_Decimal_op_GreaterThanOrEqual() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_Decimal_op_GreaterThanOrEqual";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Decimal arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.Decimal arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Decimal);
					}
					else
					{
						LinkObj<System.Decimal> argObj = (LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					bool _result_ = arg0 >= arg1					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_Decimal_valueOf : NativeConstParameterFunction
		{
			public system_Decimal_valueOf() : base(0)
			{
				para = new List<RunTimeDataType>();
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Decimal_valueOf";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_number;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Decimal _this =
					(System.Decimal)((LinkObj<System.Decimal>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					double _result_ = (double)(_this					)
					;
					returnSlot.setValue(_result_);


					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

	}
}
