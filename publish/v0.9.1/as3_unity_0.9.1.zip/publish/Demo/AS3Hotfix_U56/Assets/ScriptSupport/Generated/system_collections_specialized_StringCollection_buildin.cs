using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_collections_specialized_StringCollection_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_collections_specialized_StringCollection_creator", default(System.Collections.Specialized.StringCollection)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_StringCollection_buildin.system_collections_specialized_StringCollection_ctor","system_collections_specialized_StringCollection_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_StringCollection_buildin._system_collections_specialized_StringCollectionAdapter_ctor","_system_collections_specialized_StringCollectionAdapter_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_StringCollection_buildin.system_collections_specialized_StringCollection_getThisItem","system_collections_specialized_StringCollection_getThisItem");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_StringCollection_buildin.system_collections_specialized_StringCollection_setThisItem","system_collections_specialized_StringCollection_setThisItem");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_StringCollection_buildin.system_collections_specialized_StringCollection_add","system_collections_specialized_StringCollection_add");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_StringCollection_buildin.system_collections_specialized_StringCollection_addRange","system_collections_specialized_StringCollection_addRange");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_StringCollection_buildin.system_collections_specialized_StringCollection_contains","system_collections_specialized_StringCollection_contains");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_StringCollection_buildin.system_collections_specialized_StringCollection_copyTo","system_collections_specialized_StringCollection_copyTo");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_StringCollection_buildin.system_collections_specialized_StringCollection_getEnumerator","system_collections_specialized_StringCollection_getEnumerator");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_StringCollection_buildin.system_collections_specialized_StringCollection_indexOf","system_collections_specialized_StringCollection_indexOf");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_StringCollection_buildin.system_collections_specialized_StringCollection_insert","system_collections_specialized_StringCollection_insert");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_StringCollection_buildin.system_collections_specialized_StringCollection_get_IsReadOnly","system_collections_specialized_StringCollection_get_IsReadOnly");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_StringCollection_buildin.system_collections_specialized_StringCollection_remove","system_collections_specialized_StringCollection_remove");
		}

		public class system_collections_specialized_StringCollectionAdapter :System.Collections.Specialized.StringCollection ,ASRuntime.ICrossExtendAdapter
		{

			public ASBinCode.rtti.Class AS3Class { get { return typeclass; } }

			public ASBinCode.rtData.rtObjectBase AS3Object { get { return bindAS3Object; } }

			protected Player player;
			private Class typeclass;
			private ASBinCode.rtData.rtObjectBase bindAS3Object;

			public void SetAS3RuntimeEnvironment(Player player, Class typeclass, ASBinCode.rtData.rtObjectBase bindAS3Object)
			{
				this.player = player;
				this.typeclass = typeclass;
				this.bindAS3Object = bindAS3Object;
			}

			public system_collections_specialized_StringCollectionAdapter():base(){}

		}
		public class system_collections_specialized_StringCollection_ctor : NativeConstParameterFunction
		{
			public system_collections_specialized_StringCollection_ctor() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_StringCollection_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{

					((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new System.Collections.Specialized.StringCollection();
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class _system_collections_specialized_StringCollectionAdapter_ctor : NativeConstParameterFunction,ICrossExtendAdapterCreator
		{
			public _system_collections_specialized_StringCollectionAdapter_ctor() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public Type GetAdapterType()
			{
				return typeof(system_collections_specialized_StringCollectionAdapter);
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "_system_collections_specialized_StringCollectionAdapter_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{

					((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new system_collections_specialized_StringCollectionAdapter();

					((ICrossExtendAdapter)((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value)
						.SetAS3RuntimeEnvironment(stackframe.player, ((ASBinCode.rtData.rtObjectBase)thisObj).value._class, (ASBinCode.rtData.rtObjectBase)thisObj);


					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_specialized_StringCollection_getThisItem : NativeConstParameterFunction
		{
			public system_collections_specialized_StringCollection_getThisItem() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_StringCollection_getThisItem";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.StringCollection _this =
					(System.Collections.Specialized.StringCollection)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					string _result_ = (string)(_this[(System.Int32)arg0]
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_specialized_StringCollection_setThisItem : NativeConstParameterFunction
		{
			public system_collections_specialized_StringCollection_setThisItem() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_StringCollection_setThisItem";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.StringCollection _this =
					(System.Collections.Specialized.StringCollection)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					_this[(System.Int32)arg1] = (System.String)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_specialized_StringCollection_add : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_specialized_StringCollection_add() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_StringCollection_add";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.StringCollection _this =
					(System.Collections.Specialized.StringCollection)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					int _result_ = (int)(_this.Add((System.String)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Specialized.StringCollection).GetMethod("Add",new Type[] {typeof(System.String)});;
				}
				return method;
			}

		}

		public class system_collections_specialized_StringCollection_addRange : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_specialized_StringCollection_addRange() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_StringCollection_addRange";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.StringCollection _this =
					(System.Collections.Specialized.StringCollection)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.String[] arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.String[])_temp;
					}

					_this.AddRange((System.String[])arg0)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Specialized.StringCollection).GetMethod("AddRange",new Type[] {typeof(System.String[])});;
				}
				return method;
			}

		}

		public class system_collections_specialized_StringCollection_contains : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_specialized_StringCollection_contains() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_StringCollection_contains";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.StringCollection _this =
					(System.Collections.Specialized.StringCollection)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					bool _result_ = _this.Contains((System.String)arg0)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Specialized.StringCollection).GetMethod("Contains",new Type[] {typeof(System.String)});;
				}
				return method;
			}

		}

		public class system_collections_specialized_StringCollection_copyTo : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_specialized_StringCollection_copyTo() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_StringCollection_copyTo";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.StringCollection _this =
					(System.Collections.Specialized.StringCollection)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.String[] arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.String[])_temp;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					_this.CopyTo((System.String[])arg0,(System.Int32)arg1)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Specialized.StringCollection).GetMethod("CopyTo",new Type[] {typeof(System.String[]),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_specialized_StringCollection_getEnumerator : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_specialized_StringCollection_getEnumerator() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_StringCollection_getEnumerator";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.StringCollection _this =
					(System.Collections.Specialized.StringCollection)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.GetEnumerator()
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Specialized.StringCollection).GetMethod("GetEnumerator",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_collections_specialized_StringCollection_indexOf : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_specialized_StringCollection_indexOf() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_StringCollection_indexOf";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.StringCollection _this =
					(System.Collections.Specialized.StringCollection)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					int _result_ = (int)(_this.IndexOf((System.String)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Specialized.StringCollection).GetMethod("IndexOf",new Type[] {typeof(System.String)});;
				}
				return method;
			}

		}

		public class system_collections_specialized_StringCollection_insert : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_specialized_StringCollection_insert() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_StringCollection_insert";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.StringCollection _this =
					(System.Collections.Specialized.StringCollection)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);

					_this.Insert((System.Int32)arg0,(System.String)arg1)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Specialized.StringCollection).GetMethod("Insert",new Type[] {typeof(System.Int32),typeof(System.String)});;
				}
				return method;
			}

		}

		public class system_collections_specialized_StringCollection_get_IsReadOnly : NativeConstParameterFunction
		{
			public system_collections_specialized_StringCollection_get_IsReadOnly() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_StringCollection_get_IsReadOnly";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.StringCollection _this =
					(System.Collections.Specialized.StringCollection)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					bool _result_ = _this.IsReadOnly
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_specialized_StringCollection_remove : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_specialized_StringCollection_remove() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_StringCollection_remove";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.StringCollection _this =
					(System.Collections.Specialized.StringCollection)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					_this.Remove((System.String)arg0)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Specialized.StringCollection).GetMethod("Remove",new Type[] {typeof(System.String)});;
				}
				return method;
			}

		}

	}
}
