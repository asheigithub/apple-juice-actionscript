using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_creator", default(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.UI.RectMask2D>)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_buildin.system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_getThisItem","system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_getThisItem");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_buildin.system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_contains","system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_contains");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_buildin.system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_copyTo","system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_copyTo");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_buildin.system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_indexOf","system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_indexOf");
		}


		public class system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_getThisItem : NativeConstParameterFunction
		{
			public system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_getThisItem() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_getThisItem";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					object _result_ = _this[(System.Int32)arg0]
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_contains : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_contains() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_contains";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.UI.RectMask2D arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.UI.RectMask2D)_temp;
					}

					bool _result_ = _this.Contains((UnityEngine.UI.RectMask2D)arg0)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.UI.RectMask2D>).GetMethod("Contains",new Type[] {typeof(UnityEngine.UI.RectMask2D)});;
				}
				return method;
			}

		}

		public class system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_copyTo : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_copyTo() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_copyTo";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.UI.RectMask2D[] arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.UI.RectMask2D[])_temp;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					_this.CopyTo((UnityEngine.UI.RectMask2D[])arg0,(System.Int32)arg1)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.UI.RectMask2D>).GetMethod("CopyTo",new Type[] {typeof(UnityEngine.UI.RectMask2D[]),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_indexOf : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_indexOf() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_objectmodel_ReadOnlyCollection_Of_RectMask2D_indexOf";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.UI.RectMask2D arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.UI.RectMask2D)_temp;
					}

					int _result_ = (int)(_this.IndexOf((UnityEngine.UI.RectMask2D)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.ObjectModel.ReadOnlyCollection<UnityEngine.UI.RectMask2D>).GetMethod("IndexOf",new Type[] {typeof(UnityEngine.UI.RectMask2D)});;
				}
				return method;
			}

		}

	}
}
