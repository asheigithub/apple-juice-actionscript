using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_collections_specialized_NameObjectCollectionBase_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_collections_specialized_NameObjectCollectionBase_creator", default(System.Collections.Specialized.NameObjectCollectionBase)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_NameObjectCollectionBase_buildin.system_collections_specialized_NameObjectCollectionBase_get_Keys","system_collections_specialized_NameObjectCollectionBase_get_Keys");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_NameObjectCollectionBase_buildin.system_collections_specialized_NameObjectCollectionBase_onDeserialization","system_collections_specialized_NameObjectCollectionBase_onDeserialization");
		}


		public class system_collections_specialized_NameObjectCollectionBase_get_Keys : NativeConstParameterFunction
		{
			public system_collections_specialized_NameObjectCollectionBase_get_Keys() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_NameObjectCollectionBase_get_Keys";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.NameObjectCollectionBase _this =
					(System.Collections.Specialized.NameObjectCollectionBase)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.Keys
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_specialized_NameObjectCollectionBase_onDeserialization : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_specialized_NameObjectCollectionBase_onDeserialization() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_NameObjectCollectionBase_onDeserialization";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.NameObjectCollectionBase _this =
					(System.Collections.Specialized.NameObjectCollectionBase)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Object arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Object)_temp;
					}

					_this.OnDeserialization((System.Object)arg0)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Specialized.NameObjectCollectionBase).GetMethod("OnDeserialization",new Type[] {typeof(System.Object)});;
				}
				return method;
			}

		}

	}
}
