using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_security_cryptography_x509certificates_PublicKey_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_security_cryptography_x509certificates_PublicKey_creator", default(System.Security.Cryptography.X509Certificates.PublicKey)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_PublicKey_buildin.system_security_cryptography_x509certificates_PublicKey_ctor","system_security_cryptography_x509certificates_PublicKey_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_PublicKey_buildin.system_security_cryptography_x509certificates_PublicKey_get_EncodedKeyValue","system_security_cryptography_x509certificates_PublicKey_get_EncodedKeyValue");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_PublicKey_buildin.system_security_cryptography_x509certificates_PublicKey_get_EncodedParameters","system_security_cryptography_x509certificates_PublicKey_get_EncodedParameters");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_PublicKey_buildin.system_security_cryptography_x509certificates_PublicKey_get_Key","system_security_cryptography_x509certificates_PublicKey_get_Key");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_PublicKey_buildin.system_security_cryptography_x509certificates_PublicKey_get_Oid","system_security_cryptography_x509certificates_PublicKey_get_Oid");
		}


		public class system_security_cryptography_x509certificates_PublicKey_ctor : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_PublicKey_ctor() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_PublicKey_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.Security.Cryptography.Oid arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Security.Cryptography.Oid)_temp;
					}
					System.Security.Cryptography.AsnEncodedData arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Security.Cryptography.AsnEncodedData)_temp;
					}
					System.Security.Cryptography.AsnEncodedData arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Security.Cryptography.AsnEncodedData)_temp;
					}

					((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new System.Security.Cryptography.X509Certificates.PublicKey((System.Security.Cryptography.Oid)arg0,(System.Security.Cryptography.AsnEncodedData)arg1,(System.Security.Cryptography.AsnEncodedData)arg2);
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_PublicKey_get_EncodedKeyValue : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_PublicKey_get_EncodedKeyValue() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_PublicKey_get_EncodedKeyValue";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.PublicKey _this =
					(System.Security.Cryptography.X509Certificates.PublicKey)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.EncodedKeyValue
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_PublicKey_get_EncodedParameters : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_PublicKey_get_EncodedParameters() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_PublicKey_get_EncodedParameters";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.PublicKey _this =
					(System.Security.Cryptography.X509Certificates.PublicKey)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.EncodedParameters
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_PublicKey_get_Key : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_PublicKey_get_Key() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_PublicKey_get_Key";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.PublicKey _this =
					(System.Security.Cryptography.X509Certificates.PublicKey)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.Key
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_PublicKey_get_Oid : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_PublicKey_get_Oid() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_PublicKey_get_Oid";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.PublicKey _this =
					(System.Security.Cryptography.X509Certificates.PublicKey)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.Oid
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

	}
}
