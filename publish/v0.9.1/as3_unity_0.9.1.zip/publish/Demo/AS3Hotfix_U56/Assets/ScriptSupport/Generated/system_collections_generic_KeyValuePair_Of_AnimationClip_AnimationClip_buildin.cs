using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_collections_generic_KeyValuePair_Of_AnimationClip_AnimationClip_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_collections_generic_KeyValuePair_Of_AnimationClip_AnimationClip_creator", default(System.Collections.Generic.KeyValuePair<UnityEngine.AnimationClip,UnityEngine.AnimationClip>)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_KeyValuePair_Of_AnimationClip_AnimationClip_buildin.system_collections_generic_KeyValuePair_Of_AnimationClip_AnimationClip_ctor","system_collections_generic_KeyValuePair_Of_AnimationClip_AnimationClip_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_KeyValuePair_Of_AnimationClip_AnimationClip_buildin.system_collections_generic_KeyValuePair_Of_AnimationClip_AnimationClip_get_Key","system_collections_generic_KeyValuePair_Of_AnimationClip_AnimationClip_get_Key");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_KeyValuePair_Of_AnimationClip_AnimationClip_buildin.system_collections_generic_KeyValuePair_Of_AnimationClip_AnimationClip_get_Value","system_collections_generic_KeyValuePair_Of_AnimationClip_AnimationClip_get_Value");
		}


		public class system_collections_generic_KeyValuePair_Of_AnimationClip_AnimationClip_ctor : NativeConstParameterFunction
		{
			public system_collections_generic_KeyValuePair_Of_AnimationClip_AnimationClip_ctor() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_KeyValuePair_Of_AnimationClip_AnimationClip_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					UnityEngine.AnimationClip arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.AnimationClip)_temp;
					}
					UnityEngine.AnimationClip arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (UnityEngine.AnimationClip)_temp;
					}

					((LinkObj<System.Collections.Generic.KeyValuePair<UnityEngine.AnimationClip,UnityEngine.AnimationClip>>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new System.Collections.Generic.KeyValuePair<UnityEngine.AnimationClip,UnityEngine.AnimationClip>((UnityEngine.AnimationClip)arg0,(UnityEngine.AnimationClip)arg1);
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_generic_KeyValuePair_Of_AnimationClip_AnimationClip_get_Key : NativeConstParameterFunction
		{
			public system_collections_generic_KeyValuePair_Of_AnimationClip_AnimationClip_get_Key() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_KeyValuePair_Of_AnimationClip_AnimationClip_get_Key";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.KeyValuePair<UnityEngine.AnimationClip,UnityEngine.AnimationClip> _this =
					(System.Collections.Generic.KeyValuePair<UnityEngine.AnimationClip,UnityEngine.AnimationClip>)((LinkObj<System.Collections.Generic.KeyValuePair<UnityEngine.AnimationClip,UnityEngine.AnimationClip>>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					object _result_ = _this.Key
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					((LinkObj<System.Collections.Generic.KeyValuePair<UnityEngine.AnimationClip,UnityEngine.AnimationClip>>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_generic_KeyValuePair_Of_AnimationClip_AnimationClip_get_Value : NativeConstParameterFunction
		{
			public system_collections_generic_KeyValuePair_Of_AnimationClip_AnimationClip_get_Value() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_KeyValuePair_Of_AnimationClip_AnimationClip_get_Value";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.KeyValuePair<UnityEngine.AnimationClip,UnityEngine.AnimationClip> _this =
					(System.Collections.Generic.KeyValuePair<UnityEngine.AnimationClip,UnityEngine.AnimationClip>)((LinkObj<System.Collections.Generic.KeyValuePair<UnityEngine.AnimationClip,UnityEngine.AnimationClip>>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					object _result_ = _this.Value
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					((LinkObj<System.Collections.Generic.KeyValuePair<UnityEngine.AnimationClip,UnityEngine.AnimationClip>>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

	}
}
