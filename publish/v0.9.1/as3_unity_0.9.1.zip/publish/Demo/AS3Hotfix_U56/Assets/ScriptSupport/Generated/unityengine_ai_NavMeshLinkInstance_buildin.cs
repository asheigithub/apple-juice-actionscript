using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class unityengine_ai_NavMeshLinkInstance_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("unityengine_ai_NavMeshLinkInstance_creator", default(UnityEngine.AI.NavMeshLinkInstance)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshLinkInstance_buildin.unityengine_ai_NavMeshLinkInstance_ctor","unityengine_ai_NavMeshLinkInstance_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshLinkInstance_buildin.unityengine_ai_NavMeshLinkInstance_get_valid","unityengine_ai_NavMeshLinkInstance_get_valid");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshLinkInstance_buildin.unityengine_ai_NavMeshLinkInstance_remove","unityengine_ai_NavMeshLinkInstance_remove");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshLinkInstance_buildin.unityengine_ai_NavMeshLinkInstance_get_owner","unityengine_ai_NavMeshLinkInstance_get_owner");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshLinkInstance_buildin.unityengine_ai_NavMeshLinkInstance_set_owner","unityengine_ai_NavMeshLinkInstance_set_owner");
		}


		public class unityengine_ai_NavMeshLinkInstance_ctor : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshLinkInstance_ctor() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshLinkInstance_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{

					((LinkObj<UnityEngine.AI.NavMeshLinkInstance>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new UnityEngine.AI.NavMeshLinkInstance();
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshLinkInstance_get_valid : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshLinkInstance_get_valid() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshLinkInstance_get_valid";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshLinkInstance _this =
					(UnityEngine.AI.NavMeshLinkInstance)((LinkObj<UnityEngine.AI.NavMeshLinkInstance>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					bool _result_ = _this.valid
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					((LinkObj<UnityEngine.AI.NavMeshLinkInstance>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshLinkInstance_remove : NativeConstParameterFunction,IMethodGetter
		{
			public unityengine_ai_NavMeshLinkInstance_remove() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshLinkInstance_remove";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshLinkInstance _this =
					(UnityEngine.AI.NavMeshLinkInstance)((LinkObj<UnityEngine.AI.NavMeshLinkInstance>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					_this.Remove()
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<UnityEngine.AI.NavMeshLinkInstance>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(UnityEngine.AI.NavMeshLinkInstance).GetMethod("Remove",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class unityengine_ai_NavMeshLinkInstance_get_owner : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshLinkInstance_get_owner() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshLinkInstance_get_owner";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshLinkInstance _this =
					(UnityEngine.AI.NavMeshLinkInstance)((LinkObj<UnityEngine.AI.NavMeshLinkInstance>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					object _result_ = _this.owner
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					((LinkObj<UnityEngine.AI.NavMeshLinkInstance>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshLinkInstance_set_owner : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshLinkInstance_set_owner() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshLinkInstance_set_owner";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshLinkInstance _this =
					(UnityEngine.AI.NavMeshLinkInstance)((LinkObj<UnityEngine.AI.NavMeshLinkInstance>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					UnityEngine.Object arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.Object)_temp;
					}

					_this.owner = (UnityEngine.Object)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<UnityEngine.AI.NavMeshLinkInstance>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

	}
}
