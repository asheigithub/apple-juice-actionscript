using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_collections_specialized_NameObjectCollectionBase_KeysCollection_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_collections_specialized_NameObjectCollectionBase_KeysCollection_creator", default(System.Collections.Specialized.NameObjectCollectionBase.KeysCollection)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_NameObjectCollectionBase_KeysCollection_buildin.system_collections_specialized_NameObjectCollectionBase_KeysCollection_get","system_collections_specialized_NameObjectCollectionBase_KeysCollection_get");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_NameObjectCollectionBase_KeysCollection_buildin.system_collections_specialized_NameObjectCollectionBase_KeysCollection_getThisItem","system_collections_specialized_NameObjectCollectionBase_KeysCollection_getThisItem");
		}


		public class system_collections_specialized_NameObjectCollectionBase_KeysCollection_get : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_specialized_NameObjectCollectionBase_KeysCollection_get() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_NameObjectCollectionBase_KeysCollection_get";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.NameObjectCollectionBase.KeysCollection _this =
					(System.Collections.Specialized.NameObjectCollectionBase.KeysCollection)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					string _result_ = (string)(_this.Get((System.Int32)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Specialized.NameObjectCollectionBase.KeysCollection).GetMethod("Get",new Type[] {typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_specialized_NameObjectCollectionBase_KeysCollection_getThisItem : NativeConstParameterFunction
		{
			public system_collections_specialized_NameObjectCollectionBase_KeysCollection_getThisItem() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_NameObjectCollectionBase_KeysCollection_getThisItem";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.NameObjectCollectionBase.KeysCollection _this =
					(System.Collections.Specialized.NameObjectCollectionBase.KeysCollection)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					string _result_ = (string)(_this[(System.Int32)arg0]
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

	}
}
