using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_text_regularexpressions_RegexRunnerFactory_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_text_regularexpressions_RegexRunnerFactory_creator", default(System.Text.RegularExpressions.RegexRunnerFactory)));
		}


	}
}
