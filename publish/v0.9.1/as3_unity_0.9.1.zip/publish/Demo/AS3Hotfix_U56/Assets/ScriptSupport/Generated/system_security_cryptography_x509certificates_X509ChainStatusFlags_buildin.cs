using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_security_cryptography_x509certificates_X509ChainStatusFlags_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_security_cryptography_x509certificates_X509ChainStatusFlags_creator", default(System.Security.Cryptography.X509Certificates.X509ChainStatusFlags)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509ChainStatusFlags_buildin.system_security_cryptography_x509certificates_X509ChainStatusFlags_ctor","system_security_cryptography_x509certificates_X509ChainStatusFlags_ctor");
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_NoError_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.NoError;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_NotTimeValid_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.NotTimeValid;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_NotTimeNested_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.NotTimeNested;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_Revoked_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.Revoked;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_NotSignatureValid_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.NotSignatureValid;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_NotValidForUsage_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.NotValidForUsage;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_UntrustedRoot_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.UntrustedRoot;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_RevocationStatusUnknown_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.RevocationStatusUnknown;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_Cyclic_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.Cyclic;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_InvalidExtension_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.InvalidExtension;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_InvalidPolicyConstraints_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.InvalidPolicyConstraints;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_InvalidBasicConstraints_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.InvalidBasicConstraints;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_InvalidNameConstraints_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.InvalidNameConstraints;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_HasNotSupportedNameConstraint_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.HasNotSupportedNameConstraint;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_HasNotDefinedNameConstraint_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.HasNotDefinedNameConstraint;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_HasNotPermittedNameConstraint_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.HasNotPermittedNameConstraint;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_HasExcludedNameConstraint_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.HasExcludedNameConstraint;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_PartialChain_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.PartialChain;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_CtlNotTimeValid_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.CtlNotTimeValid;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_CtlNotSignatureValid_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.CtlNotSignatureValid;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_CtlNotValidForUsage_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.CtlNotValidForUsage;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_OfflineRevocation_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.OfflineRevocation;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_security_cryptography_x509certificates_X509ChainStatusFlags_NoIssuanceChainPolicy_getter",()=>{ return System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.NoIssuanceChainPolicy;}));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509ChainStatusFlags_buildin.system_security_cryptography_x509certificates_X509ChainStatusFlags_operator_bitOr","system_security_cryptography_x509certificates_X509ChainStatusFlags_operator_bitOr");
		}

		public class system_security_cryptography_x509certificates_X509ChainStatusFlags_ctor : NativeFunctionBase
		{
			public system_security_cryptography_x509certificates_X509ChainStatusFlags_ctor()
			{
				para = new List<RunTimeDataType>();
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509ChainStatusFlags_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override RunTimeValueBase execute(RunTimeValueBase thisObj, SLOT[] argements, object stackframe, out string errormessage, out int errorno)
			{
				errormessage = null; errorno = 0;
				return ASBinCode.rtData.rtUndefined.undefined;

			}
		}

		public class system_security_cryptography_x509certificates_X509ChainStatusFlags_operator_bitOr : ASRuntime.nativefuncs.NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509ChainStatusFlags_operator_bitOr() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509ChainStatusFlags_operator_bitOr";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				System.Security.Cryptography.X509Certificates.X509ChainStatusFlags ts1;

				if (argements[0].rtType == RunTimeDataType.rt_null)
				{
					ts1 = default(System.Security.Cryptography.X509Certificates.X509ChainStatusFlags);
				}
				else
				{
					LinkObj<object> argObj = (LinkObj<object>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
					ts1 = (System.Security.Cryptography.X509Certificates.X509ChainStatusFlags)argObj.value;
				}

				System.Security.Cryptography.X509Certificates.X509ChainStatusFlags ts2;

				if (argements[1].rtType == RunTimeDataType.rt_null)
				{
					ts2 = default(System.Security.Cryptography.X509Certificates.X509ChainStatusFlags);
				}
				else
				{
					LinkObj<object> argObj = (LinkObj<object>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
					ts2 = (System.Security.Cryptography.X509Certificates.X509ChainStatusFlags)argObj.value;
				}

				((StackSlot)returnSlot).setLinkObjectValue(
					bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, ts1 | ts2);

				success = true;
			}
		}

	}
}
