using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_io_WaitForChangedResult_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_io_WaitForChangedResult_creator", default(System.IO.WaitForChangedResult)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_io_WaitForChangedResult_buildin.system_io_WaitForChangedResult_ctor","system_io_WaitForChangedResult_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_io_WaitForChangedResult_buildin.system_io_WaitForChangedResult_get_ChangeType","system_io_WaitForChangedResult_get_ChangeType");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_io_WaitForChangedResult_buildin.system_io_WaitForChangedResult_set_ChangeType","system_io_WaitForChangedResult_set_ChangeType");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_io_WaitForChangedResult_buildin.system_io_WaitForChangedResult_get_Name","system_io_WaitForChangedResult_get_Name");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_io_WaitForChangedResult_buildin.system_io_WaitForChangedResult_set_Name","system_io_WaitForChangedResult_set_Name");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_io_WaitForChangedResult_buildin.system_io_WaitForChangedResult_get_OldName","system_io_WaitForChangedResult_get_OldName");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_io_WaitForChangedResult_buildin.system_io_WaitForChangedResult_set_OldName","system_io_WaitForChangedResult_set_OldName");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_io_WaitForChangedResult_buildin.system_io_WaitForChangedResult_get_TimedOut","system_io_WaitForChangedResult_get_TimedOut");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_io_WaitForChangedResult_buildin.system_io_WaitForChangedResult_set_TimedOut","system_io_WaitForChangedResult_set_TimedOut");
		}


		public class system_io_WaitForChangedResult_ctor : NativeConstParameterFunction
		{
			public system_io_WaitForChangedResult_ctor() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_io_WaitForChangedResult_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{

					((LinkObj<System.IO.WaitForChangedResult>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new System.IO.WaitForChangedResult();
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_io_WaitForChangedResult_get_ChangeType : NativeConstParameterFunction
		{
			public system_io_WaitForChangedResult_get_ChangeType() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_io_WaitForChangedResult_get_ChangeType";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.IO.WaitForChangedResult _this =
					(System.IO.WaitForChangedResult)((LinkObj<System.IO.WaitForChangedResult>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					System.IO.WatcherChangeTypes _result_ = _this.ChangeType
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<System.IO.WaitForChangedResult>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_io_WaitForChangedResult_set_ChangeType : NativeConstParameterFunction
		{
			public system_io_WaitForChangedResult_set_ChangeType() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_io_WaitForChangedResult_set_ChangeType";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.IO.WaitForChangedResult _this =
					(System.IO.WaitForChangedResult)((LinkObj<System.IO.WaitForChangedResult>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					System.IO.WatcherChangeTypes arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.IO.WatcherChangeTypes)_temp;
					}

					_this.ChangeType = (System.IO.WatcherChangeTypes)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<System.IO.WaitForChangedResult>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_io_WaitForChangedResult_get_Name : NativeConstParameterFunction
		{
			public system_io_WaitForChangedResult_get_Name() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_io_WaitForChangedResult_get_Name";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.IO.WaitForChangedResult _this =
					(System.IO.WaitForChangedResult)((LinkObj<System.IO.WaitForChangedResult>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					string _result_ = (string)(_this.Name
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.IO.WaitForChangedResult>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_io_WaitForChangedResult_set_Name : NativeConstParameterFunction
		{
			public system_io_WaitForChangedResult_set_Name() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_io_WaitForChangedResult_set_Name";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.IO.WaitForChangedResult _this =
					(System.IO.WaitForChangedResult)((LinkObj<System.IO.WaitForChangedResult>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					_this.Name = (System.String)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<System.IO.WaitForChangedResult>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_io_WaitForChangedResult_get_OldName : NativeConstParameterFunction
		{
			public system_io_WaitForChangedResult_get_OldName() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_io_WaitForChangedResult_get_OldName";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.IO.WaitForChangedResult _this =
					(System.IO.WaitForChangedResult)((LinkObj<System.IO.WaitForChangedResult>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					string _result_ = (string)(_this.OldName
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.IO.WaitForChangedResult>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_io_WaitForChangedResult_set_OldName : NativeConstParameterFunction
		{
			public system_io_WaitForChangedResult_set_OldName() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_io_WaitForChangedResult_set_OldName";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.IO.WaitForChangedResult _this =
					(System.IO.WaitForChangedResult)((LinkObj<System.IO.WaitForChangedResult>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					_this.OldName = (System.String)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<System.IO.WaitForChangedResult>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_io_WaitForChangedResult_get_TimedOut : NativeConstParameterFunction
		{
			public system_io_WaitForChangedResult_get_TimedOut() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_io_WaitForChangedResult_get_TimedOut";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.IO.WaitForChangedResult _this =
					(System.IO.WaitForChangedResult)((LinkObj<System.IO.WaitForChangedResult>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					bool _result_ = _this.TimedOut
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					((LinkObj<System.IO.WaitForChangedResult>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_io_WaitForChangedResult_set_TimedOut : NativeConstParameterFunction
		{
			public system_io_WaitForChangedResult_set_TimedOut() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_boolean);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_io_WaitForChangedResult_set_TimedOut";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.IO.WaitForChangedResult _this =
					(System.IO.WaitForChangedResult)((LinkObj<System.IO.WaitForChangedResult>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					bool arg0 = TypeConverter.ConvertToBoolean(argements[0], stackframe, token).value;

					_this.TimedOut = (System.Boolean)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<System.IO.WaitForChangedResult>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

	}
}
