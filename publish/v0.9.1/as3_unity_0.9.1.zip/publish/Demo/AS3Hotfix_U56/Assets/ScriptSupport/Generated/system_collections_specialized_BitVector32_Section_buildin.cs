using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_collections_specialized_BitVector32_Section_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_collections_specialized_BitVector32_Section_creator", default(System.Collections.Specialized.BitVector32.Section)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_BitVector32_Section_buildin.system_collections_specialized_BitVector32_Section_ctor","system_collections_specialized_BitVector32_Section_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_BitVector32_Section_buildin.system_collections_specialized_BitVector32_Section_get_Mask","system_collections_specialized_BitVector32_Section_get_Mask");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_BitVector32_Section_buildin.system_collections_specialized_BitVector32_Section_get_Offset","system_collections_specialized_BitVector32_Section_get_Offset");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_BitVector32_Section_buildin.system_collections_specialized_BitVector32_Section_equals__","system_collections_specialized_BitVector32_Section_equals__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_BitVector32_Section_buildin.static_system_collections_specialized_BitVector32_Section_toString","static_system_collections_specialized_BitVector32_Section_toString");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_BitVector32_Section_buildin.static_system_collections_specialized_BitVector32_Section_op_Equality","static_system_collections_specialized_BitVector32_Section_op_Equality");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_BitVector32_Section_buildin.static_system_collections_specialized_BitVector32_Section_op_Inequality","static_system_collections_specialized_BitVector32_Section_op_Inequality");
		}


		public class system_collections_specialized_BitVector32_Section_ctor : NativeConstParameterFunction
		{
			public system_collections_specialized_BitVector32_Section_ctor() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_BitVector32_Section_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{

					((LinkObj<System.Collections.Specialized.BitVector32.Section>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new System.Collections.Specialized.BitVector32.Section();
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_specialized_BitVector32_Section_get_Mask : NativeConstParameterFunction
		{
			public system_collections_specialized_BitVector32_Section_get_Mask() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_BitVector32_Section_get_Mask";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.BitVector32.Section _this =
					(System.Collections.Specialized.BitVector32.Section)((LinkObj<System.Collections.Specialized.BitVector32.Section>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					int _result_ = (int)(_this.Mask
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.Collections.Specialized.BitVector32.Section>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_specialized_BitVector32_Section_get_Offset : NativeConstParameterFunction
		{
			public system_collections_specialized_BitVector32_Section_get_Offset() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_BitVector32_Section_get_Offset";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.BitVector32.Section _this =
					(System.Collections.Specialized.BitVector32.Section)((LinkObj<System.Collections.Specialized.BitVector32.Section>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					int _result_ = (int)(_this.Offset
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<System.Collections.Specialized.BitVector32.Section>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_specialized_BitVector32_Section_equals__ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_specialized_BitVector32_Section_equals__() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_BitVector32_Section_equals__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.BitVector32.Section _this =
					(System.Collections.Specialized.BitVector32.Section)((LinkObj<System.Collections.Specialized.BitVector32.Section>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					System.Collections.Specialized.BitVector32.Section arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Collections.Specialized.BitVector32.Section);
					}
					else
					{
						LinkObj<System.Collections.Specialized.BitVector32.Section> argObj = (LinkObj<System.Collections.Specialized.BitVector32.Section>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					bool _result_ = _this.Equals((System.Collections.Specialized.BitVector32.Section)arg0)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					((LinkObj<System.Collections.Specialized.BitVector32.Section>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Specialized.BitVector32.Section).GetMethod("Equals",new Type[] {typeof(System.Collections.Specialized.BitVector32.Section)});;
				}
				return method;
			}

		}

		public class static_system_collections_specialized_BitVector32_Section_toString : NativeConstParameterFunction
		{
			public static_system_collections_specialized_BitVector32_Section_toString() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_collections_specialized_BitVector32_Section_toString";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Collections.Specialized.BitVector32.Section arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Collections.Specialized.BitVector32.Section);
					}
					else
					{
						LinkObj<System.Collections.Specialized.BitVector32.Section> argObj = (LinkObj<System.Collections.Specialized.BitVector32.Section>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					string _result_ = (string)(System.Collections.Specialized.BitVector32.Section.ToString((System.Collections.Specialized.BitVector32.Section)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_collections_specialized_BitVector32_Section_op_Equality : NativeConstParameterFunction
		{
			public static_system_collections_specialized_BitVector32_Section_op_Equality() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_collections_specialized_BitVector32_Section_op_Equality";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Collections.Specialized.BitVector32.Section arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Collections.Specialized.BitVector32.Section);
					}
					else
					{
						LinkObj<System.Collections.Specialized.BitVector32.Section> argObj = (LinkObj<System.Collections.Specialized.BitVector32.Section>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.Collections.Specialized.BitVector32.Section arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Collections.Specialized.BitVector32.Section);
					}
					else
					{
						LinkObj<System.Collections.Specialized.BitVector32.Section> argObj = (LinkObj<System.Collections.Specialized.BitVector32.Section>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					bool _result_ = arg0 == arg1					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_collections_specialized_BitVector32_Section_op_Inequality : NativeConstParameterFunction
		{
			public static_system_collections_specialized_BitVector32_Section_op_Inequality() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_collections_specialized_BitVector32_Section_op_Inequality";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Collections.Specialized.BitVector32.Section arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.Collections.Specialized.BitVector32.Section);
					}
					else
					{
						LinkObj<System.Collections.Specialized.BitVector32.Section> argObj = (LinkObj<System.Collections.Specialized.BitVector32.Section>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}
					System.Collections.Specialized.BitVector32.Section arg1;

					if (argements[1].rtType == RunTimeDataType.rt_null)
					{
						arg1 = default(System.Collections.Specialized.BitVector32.Section);
					}
					else
					{
						LinkObj<System.Collections.Specialized.BitVector32.Section> argObj = (LinkObj<System.Collections.Specialized.BitVector32.Section>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
						arg1 = argObj.value;
					}

					bool _result_ = arg0 != arg1					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

	}
}
