using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_security_cryptography_x509certificates_X509Certificate_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_security_cryptography_x509certificates_X509Certificate_creator", default(System.Security.Cryptography.X509Certificates.X509Certificate)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_constructor_","system_security_cryptography_x509certificates_X509Certificate_constructor_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_constructor__","system_security_cryptography_x509certificates_X509Certificate_constructor__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_constructor___","system_security_cryptography_x509certificates_X509Certificate_constructor___");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_constructor____","system_security_cryptography_x509certificates_X509Certificate_constructor____");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_constructor_____","system_security_cryptography_x509certificates_X509Certificate_constructor_____");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_constructor______","system_security_cryptography_x509certificates_X509Certificate_constructor______");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_constructor_______","system_security_cryptography_x509certificates_X509Certificate_constructor_______");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_constructor________","system_security_cryptography_x509certificates_X509Certificate_constructor________");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_constructor_________","system_security_cryptography_x509certificates_X509Certificate_constructor_________");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_constructor__________","system_security_cryptography_x509certificates_X509Certificate_constructor__________");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_constructor___________","system_security_cryptography_x509certificates_X509Certificate_constructor___________");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_constructor____________","system_security_cryptography_x509certificates_X509Certificate_constructor____________");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_ctor","system_security_cryptography_x509certificates_X509Certificate_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin._system_security_cryptography_x509certificates_X509CertificateAdapter_ctor","_system_security_cryptography_x509certificates_X509CertificateAdapter_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.static_system_security_cryptography_x509certificates_X509Certificate_createFromCertFile","static_system_security_cryptography_x509certificates_X509Certificate_createFromCertFile");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.static_system_security_cryptography_x509certificates_X509Certificate_createFromSignedFile","static_system_security_cryptography_x509certificates_X509Certificate_createFromSignedFile");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_get_Handle","system_security_cryptography_x509certificates_X509Certificate_get_Handle");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_getSerialNumber","system_security_cryptography_x509certificates_X509Certificate_getSerialNumber");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_getSerialNumberString","system_security_cryptography_x509certificates_X509Certificate_getSerialNumberString");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_getKeyAlgorithmParameters","system_security_cryptography_x509certificates_X509Certificate_getKeyAlgorithmParameters");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_getKeyAlgorithmParametersString","system_security_cryptography_x509certificates_X509Certificate_getKeyAlgorithmParametersString");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_getKeyAlgorithm","system_security_cryptography_x509certificates_X509Certificate_getKeyAlgorithm");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_getPublicKey","system_security_cryptography_x509certificates_X509Certificate_getPublicKey");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_getPublicKeyString","system_security_cryptography_x509certificates_X509Certificate_getPublicKeyString");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_getRawCertData","system_security_cryptography_x509certificates_X509Certificate_getRawCertData");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_getRawCertDataString","system_security_cryptography_x509certificates_X509Certificate_getRawCertDataString");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_getCertHash","system_security_cryptography_x509certificates_X509Certificate_getCertHash");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_getCertHashString","system_security_cryptography_x509certificates_X509Certificate_getCertHashString");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_getEffectiveDateString","system_security_cryptography_x509certificates_X509Certificate_getEffectiveDateString");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_getExpirationDateString","system_security_cryptography_x509certificates_X509Certificate_getExpirationDateString");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_equals___","system_security_cryptography_x509certificates_X509Certificate_equals___");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_toString___","system_security_cryptography_x509certificates_X509Certificate_toString___");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_getFormat","system_security_cryptography_x509certificates_X509Certificate_getFormat");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_get_Issuer","system_security_cryptography_x509certificates_X509Certificate_get_Issuer");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_get_Subject","system_security_cryptography_x509certificates_X509Certificate_get_Subject");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_import_","system_security_cryptography_x509certificates_X509Certificate_import_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_import__","system_security_cryptography_x509certificates_X509Certificate_import__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_import___","system_security_cryptography_x509certificates_X509Certificate_import___");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_import____","system_security_cryptography_x509certificates_X509Certificate_import____");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_import_____","system_security_cryptography_x509certificates_X509Certificate_import_____");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_import______","system_security_cryptography_x509certificates_X509Certificate_import______");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_export","system_security_cryptography_x509certificates_X509Certificate_export");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_export_","system_security_cryptography_x509certificates_X509Certificate_export_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_export__","system_security_cryptography_x509certificates_X509Certificate_export__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_security_cryptography_x509certificates_X509Certificate_buildin.system_security_cryptography_x509certificates_X509Certificate_reset","system_security_cryptography_x509certificates_X509Certificate_reset");
		}

		public class system_security_cryptography_x509certificates_X509CertificateAdapter :System.Security.Cryptography.X509Certificates.X509Certificate ,ASRuntime.ICrossExtendAdapter
		{

			public ASBinCode.rtti.Class AS3Class { get { return typeclass; } }

			public ASBinCode.rtData.rtObjectBase AS3Object { get { return bindAS3Object; } }

			protected Player player;
			private Class typeclass;
			private ASBinCode.rtData.rtObjectBase bindAS3Object;

			public void SetAS3RuntimeEnvironment(Player player, Class typeclass, ASBinCode.rtData.rtObjectBase bindAS3Object)
			{
				this.player = player;
				this.typeclass = typeclass;
				this.bindAS3Object = bindAS3Object;
			}

			public system_security_cryptography_x509certificates_X509CertificateAdapter():base(){}
			private ASBinCode.rtData.rtFunction _as3function_0;
			private int _as3functionId_0 =-1;
			public override System.Byte[] GetSerialNumber()
			{

				if (_as3function_0 == null)
					_as3function_0 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "getSerialNumber");
				if (_as3functionId_0 == -1)
				{
					_as3functionId_0 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("getSerialNumber").bindField).functionId;
				}

				if (_as3function_0 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_0
				)
				))
				)
				)
				{
					return base.GetSerialNumber();
				}
				else
				{
					return (System.Byte[])player.InvokeFunction(_as3function_0,0,null,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_1;
			private int _as3functionId_1 =-1;
			public override System.String GetSerialNumberString()
			{

				if (_as3function_1 == null)
					_as3function_1 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "getSerialNumberString");
				if (_as3functionId_1 == -1)
				{
					_as3functionId_1 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("getSerialNumberString").bindField).functionId;
				}

				if (_as3function_1 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_1
				)
				))
				)
				)
				{
					return base.GetSerialNumberString();
				}
				else
				{
					return (System.String)player.InvokeFunction(_as3function_1,0,null,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_2;
			private int _as3functionId_2 =-1;
			public override System.Byte[] GetKeyAlgorithmParameters()
			{

				if (_as3function_2 == null)
					_as3function_2 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "getKeyAlgorithmParameters");
				if (_as3functionId_2 == -1)
				{
					_as3functionId_2 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("getKeyAlgorithmParameters").bindField).functionId;
				}

				if (_as3function_2 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_2
				)
				))
				)
				)
				{
					return base.GetKeyAlgorithmParameters();
				}
				else
				{
					return (System.Byte[])player.InvokeFunction(_as3function_2,0,null,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_3;
			private int _as3functionId_3 =-1;
			public override System.String GetKeyAlgorithmParametersString()
			{

				if (_as3function_3 == null)
					_as3function_3 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "getKeyAlgorithmParametersString");
				if (_as3functionId_3 == -1)
				{
					_as3functionId_3 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("getKeyAlgorithmParametersString").bindField).functionId;
				}

				if (_as3function_3 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_3
				)
				))
				)
				)
				{
					return base.GetKeyAlgorithmParametersString();
				}
				else
				{
					return (System.String)player.InvokeFunction(_as3function_3,0,null,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_4;
			private int _as3functionId_4 =-1;
			public override System.String GetKeyAlgorithm()
			{

				if (_as3function_4 == null)
					_as3function_4 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "getKeyAlgorithm");
				if (_as3functionId_4 == -1)
				{
					_as3functionId_4 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("getKeyAlgorithm").bindField).functionId;
				}

				if (_as3function_4 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_4
				)
				))
				)
				)
				{
					return base.GetKeyAlgorithm();
				}
				else
				{
					return (System.String)player.InvokeFunction(_as3function_4,0,null,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_5;
			private int _as3functionId_5 =-1;
			public override System.Byte[] GetPublicKey()
			{

				if (_as3function_5 == null)
					_as3function_5 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "getPublicKey");
				if (_as3functionId_5 == -1)
				{
					_as3functionId_5 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("getPublicKey").bindField).functionId;
				}

				if (_as3function_5 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_5
				)
				))
				)
				)
				{
					return base.GetPublicKey();
				}
				else
				{
					return (System.Byte[])player.InvokeFunction(_as3function_5,0,null,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_6;
			private int _as3functionId_6 =-1;
			public override System.String GetPublicKeyString()
			{

				if (_as3function_6 == null)
					_as3function_6 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "getPublicKeyString");
				if (_as3functionId_6 == -1)
				{
					_as3functionId_6 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("getPublicKeyString").bindField).functionId;
				}

				if (_as3function_6 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_6
				)
				))
				)
				)
				{
					return base.GetPublicKeyString();
				}
				else
				{
					return (System.String)player.InvokeFunction(_as3function_6,0,null,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_7;
			private int _as3functionId_7 =-1;
			public override System.Byte[] GetRawCertData()
			{

				if (_as3function_7 == null)
					_as3function_7 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "getRawCertData");
				if (_as3functionId_7 == -1)
				{
					_as3functionId_7 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("getRawCertData").bindField).functionId;
				}

				if (_as3function_7 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_7
				)
				))
				)
				)
				{
					return base.GetRawCertData();
				}
				else
				{
					return (System.Byte[])player.InvokeFunction(_as3function_7,0,null,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_8;
			private int _as3functionId_8 =-1;
			public override System.String GetRawCertDataString()
			{

				if (_as3function_8 == null)
					_as3function_8 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "getRawCertDataString");
				if (_as3functionId_8 == -1)
				{
					_as3functionId_8 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("getRawCertDataString").bindField).functionId;
				}

				if (_as3function_8 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_8
				)
				))
				)
				)
				{
					return base.GetRawCertDataString();
				}
				else
				{
					return (System.String)player.InvokeFunction(_as3function_8,0,null,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_9;
			private int _as3functionId_9 =-1;
			public override System.Byte[] GetCertHash()
			{

				if (_as3function_9 == null)
					_as3function_9 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "getCertHash");
				if (_as3functionId_9 == -1)
				{
					_as3functionId_9 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("getCertHash").bindField).functionId;
				}

				if (_as3function_9 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_9
				)
				))
				)
				)
				{
					return base.GetCertHash();
				}
				else
				{
					return (System.Byte[])player.InvokeFunction(_as3function_9,0,null,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_10;
			private int _as3functionId_10 =-1;
			public override System.String GetCertHashString()
			{

				if (_as3function_10 == null)
					_as3function_10 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "getCertHashString");
				if (_as3functionId_10 == -1)
				{
					_as3functionId_10 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("getCertHashString").bindField).functionId;
				}

				if (_as3function_10 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_10
				)
				))
				)
				)
				{
					return base.GetCertHashString();
				}
				else
				{
					return (System.String)player.InvokeFunction(_as3function_10,0,null,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_11;
			private int _as3functionId_11 =-1;
			public override System.String GetEffectiveDateString()
			{

				if (_as3function_11 == null)
					_as3function_11 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "getEffectiveDateString");
				if (_as3functionId_11 == -1)
				{
					_as3functionId_11 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("getEffectiveDateString").bindField).functionId;
				}

				if (_as3function_11 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_11
				)
				))
				)
				)
				{
					return base.GetEffectiveDateString();
				}
				else
				{
					return (System.String)player.InvokeFunction(_as3function_11,0,null,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_12;
			private int _as3functionId_12 =-1;
			public override System.String GetExpirationDateString()
			{

				if (_as3function_12 == null)
					_as3function_12 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "getExpirationDateString");
				if (_as3functionId_12 == -1)
				{
					_as3functionId_12 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("getExpirationDateString").bindField).functionId;
				}

				if (_as3function_12 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_12
				)
				))
				)
				)
				{
					return base.GetExpirationDateString();
				}
				else
				{
					return (System.String)player.InvokeFunction(_as3function_12,0,null,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_13;
			private int _as3functionId_13 =-1;
			public override System.Boolean Equals(System.Security.Cryptography.X509Certificates.X509Certificate other)
			{

				if (_as3function_13 == null)
					_as3function_13 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "equals___");
				if (_as3functionId_13 == -1)
				{
					_as3functionId_13 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("equals___").bindField).functionId;
				}

				if (_as3function_13 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_13
				)
				))
				)
				)
				{
					return base.Equals(other);
				}
				else
				{
					return (System.Boolean)player.InvokeFunction(_as3function_13,1,other,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_14;
			private int _as3functionId_14 =-1;
			public override System.String ToString(System.Boolean fVerbose)
			{

				if (_as3function_14 == null)
					_as3function_14 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "toString___");
				if (_as3functionId_14 == -1)
				{
					_as3functionId_14 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("toString___").bindField).functionId;
				}

				if (_as3function_14 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_14
				)
				))
				)
				)
				{
					return base.ToString(fVerbose);
				}
				else
				{
					return (System.String)player.InvokeFunction(_as3function_14,1,fVerbose,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_15;
			private int _as3functionId_15 =-1;
			public override System.String GetFormat()
			{

				if (_as3function_15 == null)
					_as3function_15 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "getFormat");
				if (_as3functionId_15 == -1)
				{
					_as3functionId_15 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("getFormat").bindField).functionId;
				}

				if (_as3function_15 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_15
				)
				))
				)
				)
				{
					return base.GetFormat();
				}
				else
				{
					return (System.String)player.InvokeFunction(_as3function_15,0,null,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_16;
			private int _as3functionId_16 =-1;
			public override void Import(System.Byte[] rawData)
			{

				if (_as3function_16 == null)
					_as3function_16 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "import_");
				if (_as3functionId_16 == -1)
				{
					_as3functionId_16 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("import_").bindField).functionId;
				}

				if (_as3function_16 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_16
				)
				))
				)
				)
				{
base.Import(rawData);
				}
				else
				{
					player.InvokeFunction(_as3function_16,1,rawData,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_17;
			private int _as3functionId_17 =-1;
			public override void Import(System.Byte[] rawData,System.String password,System.Security.Cryptography.X509Certificates.X509KeyStorageFlags keyStorageFlags)
			{

				if (_as3function_17 == null)
					_as3function_17 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "import__");
				if (_as3functionId_17 == -1)
				{
					_as3functionId_17 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("import__").bindField).functionId;
				}

				if (_as3function_17 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_17
				)
				))
				)
				)
				{
base.Import(rawData,password,keyStorageFlags);
				}
				else
				{
					player.InvokeFunction(_as3function_17,3,rawData,password,keyStorageFlags,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_18;
			private int _as3functionId_18 =-1;
			public override void Import(System.Byte[] rawData,System.Security.SecureString password,System.Security.Cryptography.X509Certificates.X509KeyStorageFlags keyStorageFlags)
			{

				if (_as3function_18 == null)
					_as3function_18 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "import___");
				if (_as3functionId_18 == -1)
				{
					_as3functionId_18 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("import___").bindField).functionId;
				}

				if (_as3function_18 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_18
				)
				))
				)
				)
				{
base.Import(rawData,password,keyStorageFlags);
				}
				else
				{
					player.InvokeFunction(_as3function_18,3,rawData,password,keyStorageFlags,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_19;
			private int _as3functionId_19 =-1;
			public override void Import(System.String fileName)
			{

				if (_as3function_19 == null)
					_as3function_19 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "import____");
				if (_as3functionId_19 == -1)
				{
					_as3functionId_19 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("import____").bindField).functionId;
				}

				if (_as3function_19 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_19
				)
				))
				)
				)
				{
base.Import(fileName);
				}
				else
				{
					player.InvokeFunction(_as3function_19,1,fileName,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_20;
			private int _as3functionId_20 =-1;
			public override void Import(System.String fileName,System.String password,System.Security.Cryptography.X509Certificates.X509KeyStorageFlags keyStorageFlags)
			{

				if (_as3function_20 == null)
					_as3function_20 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "import_____");
				if (_as3functionId_20 == -1)
				{
					_as3functionId_20 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("import_____").bindField).functionId;
				}

				if (_as3function_20 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_20
				)
				))
				)
				)
				{
base.Import(fileName,password,keyStorageFlags);
				}
				else
				{
					player.InvokeFunction(_as3function_20,3,fileName,password,keyStorageFlags,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_21;
			private int _as3functionId_21 =-1;
			public override void Import(System.String fileName,System.Security.SecureString password,System.Security.Cryptography.X509Certificates.X509KeyStorageFlags keyStorageFlags)
			{

				if (_as3function_21 == null)
					_as3function_21 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "import______");
				if (_as3functionId_21 == -1)
				{
					_as3functionId_21 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("import______").bindField).functionId;
				}

				if (_as3function_21 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_21
				)
				))
				)
				)
				{
base.Import(fileName,password,keyStorageFlags);
				}
				else
				{
					player.InvokeFunction(_as3function_21,3,fileName,password,keyStorageFlags,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_22;
			private int _as3functionId_22 =-1;
			public override System.Byte[] Export(System.Security.Cryptography.X509Certificates.X509ContentType contentType)
			{

				if (_as3function_22 == null)
					_as3function_22 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "export");
				if (_as3functionId_22 == -1)
				{
					_as3functionId_22 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("export").bindField).functionId;
				}

				if (_as3function_22 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_22
				)
				))
				)
				)
				{
					return base.Export(contentType);
				}
				else
				{
					return (System.Byte[])player.InvokeFunction(_as3function_22,1,contentType,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_23;
			private int _as3functionId_23 =-1;
			public override System.Byte[] Export(System.Security.Cryptography.X509Certificates.X509ContentType contentType,System.String password)
			{

				if (_as3function_23 == null)
					_as3function_23 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "export_");
				if (_as3functionId_23 == -1)
				{
					_as3functionId_23 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("export_").bindField).functionId;
				}

				if (_as3function_23 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_23
				)
				))
				)
				)
				{
					return base.Export(contentType,password);
				}
				else
				{
					return (System.Byte[])player.InvokeFunction(_as3function_23,2,contentType,password,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_24;
			private int _as3functionId_24 =-1;
			public override System.Byte[] Export(System.Security.Cryptography.X509Certificates.X509ContentType contentType,System.Security.SecureString password)
			{

				if (_as3function_24 == null)
					_as3function_24 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "export__");
				if (_as3functionId_24 == -1)
				{
					_as3functionId_24 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("export__").bindField).functionId;
				}

				if (_as3function_24 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_24
				)
				))
				)
				)
				{
					return base.Export(contentType,password);
				}
				else
				{
					return (System.Byte[])player.InvokeFunction(_as3function_24,2,contentType,password,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_25;
			private int _as3functionId_25 =-1;
			public override void Reset()
			{

				if (_as3function_25 == null)
					_as3function_25 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "reset");
				if (_as3functionId_25 == -1)
				{
					_as3functionId_25 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("reset").bindField).functionId;
				}

				if (_as3function_25 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_25
				)
				))
				)
				)
				{
base.Reset();
				}
				else
				{
					player.InvokeFunction(_as3function_25,0,null,null,null,null,null,null);
				}
			}


		}
		public class system_security_cryptography_x509certificates_X509Certificate_constructor_ : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Certificate_constructor_() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_constructor_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.Byte[] arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Byte[])_temp;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Security.Cryptography.X509Certificates.X509Certificate((System.Byte[])arg0));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Certificate_constructor__ : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Certificate_constructor__() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_constructor__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.Byte[] arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Byte[])_temp;
					}
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Security.Cryptography.X509Certificates.X509Certificate((System.Byte[])arg0,(System.String)arg1));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Certificate_constructor___ : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Certificate_constructor___() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_constructor___";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.Byte[] arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Byte[])_temp;
					}
					System.Security.SecureString arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Security.SecureString)_temp;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Security.Cryptography.X509Certificates.X509Certificate((System.Byte[])arg0,(System.Security.SecureString)arg1));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Certificate_constructor____ : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Certificate_constructor____() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_constructor____";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.Byte[] arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Byte[])_temp;
					}
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);
					System.Security.Cryptography.X509Certificates.X509KeyStorageFlags arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Security.Cryptography.X509Certificates.X509KeyStorageFlags)_temp;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Security.Cryptography.X509Certificates.X509Certificate((System.Byte[])arg0,(System.String)arg1,(System.Security.Cryptography.X509Certificates.X509KeyStorageFlags)arg2));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Certificate_constructor_____ : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Certificate_constructor_____() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_constructor_____";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.Byte[] arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Byte[])_temp;
					}
					System.Security.SecureString arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Security.SecureString)_temp;
					}
					System.Security.Cryptography.X509Certificates.X509KeyStorageFlags arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Security.Cryptography.X509Certificates.X509KeyStorageFlags)_temp;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Security.Cryptography.X509Certificates.X509Certificate((System.Byte[])arg0,(System.Security.SecureString)arg1,(System.Security.Cryptography.X509Certificates.X509KeyStorageFlags)arg2));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Certificate_constructor______ : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Certificate_constructor______() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_constructor______";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Security.Cryptography.X509Certificates.X509Certificate((System.String)arg0));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Certificate_constructor_______ : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Certificate_constructor_______() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_constructor_______";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Security.Cryptography.X509Certificates.X509Certificate((System.String)arg0,(System.String)arg1));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Certificate_constructor________ : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Certificate_constructor________() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_constructor________";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					System.Security.SecureString arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Security.SecureString)_temp;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Security.Cryptography.X509Certificates.X509Certificate((System.String)arg0,(System.Security.SecureString)arg1));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Certificate_constructor_________ : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Certificate_constructor_________() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_constructor_________";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);
					System.Security.Cryptography.X509Certificates.X509KeyStorageFlags arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Security.Cryptography.X509Certificates.X509KeyStorageFlags)_temp;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Security.Cryptography.X509Certificates.X509Certificate((System.String)arg0,(System.String)arg1,(System.Security.Cryptography.X509Certificates.X509KeyStorageFlags)arg2));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Certificate_constructor__________ : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Certificate_constructor__________() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_constructor__________";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					System.Security.SecureString arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Security.SecureString)_temp;
					}
					System.Security.Cryptography.X509Certificates.X509KeyStorageFlags arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Security.Cryptography.X509Certificates.X509KeyStorageFlags)_temp;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Security.Cryptography.X509Certificates.X509Certificate((System.String)arg0,(System.Security.SecureString)arg1,(System.Security.Cryptography.X509Certificates.X509KeyStorageFlags)arg2));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Certificate_constructor___________ : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Certificate_constructor___________() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_constructor___________";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.IntPtr arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(System.IntPtr);
					}
					else
					{
						LinkObj<System.IntPtr> argObj = (LinkObj<System.IntPtr>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Security.Cryptography.X509Certificates.X509Certificate((System.IntPtr)arg0));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Certificate_constructor____________ : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Certificate_constructor____________() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_constructor____________";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.Security.Cryptography.X509Certificates.X509Certificate arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Security.Cryptography.X509Certificates.X509Certificate)_temp;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Security.Cryptography.X509Certificates.X509Certificate((System.Security.Cryptography.X509Certificates.X509Certificate)arg0));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Certificate_ctor : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Certificate_ctor() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{

					((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new System.Security.Cryptography.X509Certificates.X509Certificate();
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class _system_security_cryptography_x509certificates_X509CertificateAdapter_ctor : NativeConstParameterFunction,ICrossExtendAdapterCreator
		{
			public _system_security_cryptography_x509certificates_X509CertificateAdapter_ctor() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public Type GetAdapterType()
			{
				return typeof(system_security_cryptography_x509certificates_X509CertificateAdapter);
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "_system_security_cryptography_x509certificates_X509CertificateAdapter_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{

					((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new system_security_cryptography_x509certificates_X509CertificateAdapter();

					((ICrossExtendAdapter)((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value)
						.SetAS3RuntimeEnvironment(stackframe.player, ((ASBinCode.rtData.rtObjectBase)thisObj).value._class, (ASBinCode.rtData.rtObjectBase)thisObj);


					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_security_cryptography_x509certificates_X509Certificate_createFromCertFile : NativeConstParameterFunction
		{
			public static_system_security_cryptography_x509certificates_X509Certificate_createFromCertFile() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_security_cryptography_x509certificates_X509Certificate_createFromCertFile";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					object _result_ = System.Security.Cryptography.X509Certificates.X509Certificate.CreateFromCertFile((System.String)arg0)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class static_system_security_cryptography_x509certificates_X509Certificate_createFromSignedFile : NativeConstParameterFunction
		{
			public static_system_security_cryptography_x509certificates_X509Certificate_createFromSignedFile() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_security_cryptography_x509certificates_X509Certificate_createFromSignedFile";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					object _result_ = System.Security.Cryptography.X509Certificates.X509Certificate.CreateFromSignedFile((System.String)arg0)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Certificate_get_Handle : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Certificate_get_Handle() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_get_Handle";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					System.IntPtr _result_ = _this.Handle
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Certificate_getSerialNumber : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_getSerialNumber() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_getSerialNumber";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.GetSerialNumber()
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("GetSerialNumber",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_getSerialNumberString : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_getSerialNumberString() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_getSerialNumberString";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					string _result_ = (string)(_this.GetSerialNumberString()
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("GetSerialNumberString",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_getKeyAlgorithmParameters : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_getKeyAlgorithmParameters() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_getKeyAlgorithmParameters";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.GetKeyAlgorithmParameters()
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("GetKeyAlgorithmParameters",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_getKeyAlgorithmParametersString : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_getKeyAlgorithmParametersString() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_getKeyAlgorithmParametersString";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					string _result_ = (string)(_this.GetKeyAlgorithmParametersString()
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("GetKeyAlgorithmParametersString",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_getKeyAlgorithm : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_getKeyAlgorithm() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_getKeyAlgorithm";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					string _result_ = (string)(_this.GetKeyAlgorithm()
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("GetKeyAlgorithm",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_getPublicKey : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_getPublicKey() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_getPublicKey";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.GetPublicKey()
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("GetPublicKey",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_getPublicKeyString : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_getPublicKeyString() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_getPublicKeyString";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					string _result_ = (string)(_this.GetPublicKeyString()
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("GetPublicKeyString",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_getRawCertData : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_getRawCertData() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_getRawCertData";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.GetRawCertData()
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("GetRawCertData",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_getRawCertDataString : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_getRawCertDataString() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_getRawCertDataString";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					string _result_ = (string)(_this.GetRawCertDataString()
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("GetRawCertDataString",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_getCertHash : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_getCertHash() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_getCertHash";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.GetCertHash()
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("GetCertHash",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_getCertHashString : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_getCertHashString() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_getCertHashString";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					string _result_ = (string)(_this.GetCertHashString()
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("GetCertHashString",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_getEffectiveDateString : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_getEffectiveDateString() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_getEffectiveDateString";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					string _result_ = (string)(_this.GetEffectiveDateString()
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("GetEffectiveDateString",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_getExpirationDateString : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_getExpirationDateString() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_getExpirationDateString";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					string _result_ = (string)(_this.GetExpirationDateString()
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("GetExpirationDateString",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_equals___ : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_equals___() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_equals___";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Security.Cryptography.X509Certificates.X509Certificate arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Security.Cryptography.X509Certificates.X509Certificate)_temp;
					}

					bool _result_ = _this.Equals((System.Security.Cryptography.X509Certificates.X509Certificate)arg0)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("Equals",new Type[] {typeof(System.Security.Cryptography.X509Certificates.X509Certificate)});;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_toString___ : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_toString___() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_boolean);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_toString___";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					bool arg0 = TypeConverter.ConvertToBoolean(argements[0], stackframe, token).value;

					string _result_ = (string)(_this.ToString((System.Boolean)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("ToString",new Type[] {typeof(System.Boolean)});;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_getFormat : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_getFormat() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_getFormat";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					string _result_ = (string)(_this.GetFormat()
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("GetFormat",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_get_Issuer : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Certificate_get_Issuer() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_get_Issuer";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					string _result_ = (string)(_this.Issuer
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Certificate_get_Subject : NativeConstParameterFunction
		{
			public system_security_cryptography_x509certificates_X509Certificate_get_Subject() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_get_Subject";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_string;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					string _result_ = (string)(_this.Subject
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_security_cryptography_x509certificates_X509Certificate_import_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_import_() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_import_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Byte[] arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Byte[])_temp;
					}

					_this.Import((System.Byte[])arg0)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("Import",new Type[] {typeof(System.Byte[])});;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_import__ : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_import__() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_import__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Byte[] arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Byte[])_temp;
					}
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);
					System.Security.Cryptography.X509Certificates.X509KeyStorageFlags arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Security.Cryptography.X509Certificates.X509KeyStorageFlags)_temp;
					}

					_this.Import((System.Byte[])arg0,(System.String)arg1,(System.Security.Cryptography.X509Certificates.X509KeyStorageFlags)arg2)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("Import",new Type[] {typeof(System.Byte[]),typeof(System.String),typeof(System.Security.Cryptography.X509Certificates.X509KeyStorageFlags)});;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_import___ : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_import___() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_import___";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Byte[] arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Byte[])_temp;
					}
					System.Security.SecureString arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Security.SecureString)_temp;
					}
					System.Security.Cryptography.X509Certificates.X509KeyStorageFlags arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Security.Cryptography.X509Certificates.X509KeyStorageFlags)_temp;
					}

					_this.Import((System.Byte[])arg0,(System.Security.SecureString)arg1,(System.Security.Cryptography.X509Certificates.X509KeyStorageFlags)arg2)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("Import",new Type[] {typeof(System.Byte[]),typeof(System.Security.SecureString),typeof(System.Security.Cryptography.X509Certificates.X509KeyStorageFlags)});;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_import____ : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_import____() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_import____";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);

					_this.Import((System.String)arg0)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("Import",new Type[] {typeof(System.String)});;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_import_____ : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_import_____() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_import_____";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);
					System.Security.Cryptography.X509Certificates.X509KeyStorageFlags arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Security.Cryptography.X509Certificates.X509KeyStorageFlags)_temp;
					}

					_this.Import((System.String)arg0,(System.String)arg1,(System.Security.Cryptography.X509Certificates.X509KeyStorageFlags)arg2)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("Import",new Type[] {typeof(System.String),typeof(System.String),typeof(System.Security.Cryptography.X509Certificates.X509KeyStorageFlags)});;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_import______ : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_import______() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_string);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_import______";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					string arg0 = TypeConverter.ConvertToString(argements[0], stackframe, token);
					System.Security.SecureString arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Security.SecureString)_temp;
					}
					System.Security.Cryptography.X509Certificates.X509KeyStorageFlags arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Security.Cryptography.X509Certificates.X509KeyStorageFlags)_temp;
					}

					_this.Import((System.String)arg0,(System.Security.SecureString)arg1,(System.Security.Cryptography.X509Certificates.X509KeyStorageFlags)arg2)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("Import",new Type[] {typeof(System.String),typeof(System.Security.SecureString),typeof(System.Security.Cryptography.X509Certificates.X509KeyStorageFlags)});;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_export : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_export() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_export";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Security.Cryptography.X509Certificates.X509ContentType arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Security.Cryptography.X509Certificates.X509ContentType)_temp;
					}

					object _result_ = _this.Export((System.Security.Cryptography.X509Certificates.X509ContentType)arg0)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("Export",new Type[] {typeof(System.Security.Cryptography.X509Certificates.X509ContentType)});;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_export_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_export_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_string);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_export_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Security.Cryptography.X509Certificates.X509ContentType arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Security.Cryptography.X509Certificates.X509ContentType)_temp;
					}
					string arg1 = TypeConverter.ConvertToString(argements[1], stackframe, token);

					object _result_ = _this.Export((System.Security.Cryptography.X509Certificates.X509ContentType)arg0,(System.String)arg1)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("Export",new Type[] {typeof(System.Security.Cryptography.X509Certificates.X509ContentType),typeof(System.String)});;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_export__ : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_export__() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_export__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Security.Cryptography.X509Certificates.X509ContentType arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Security.Cryptography.X509Certificates.X509ContentType)_temp;
					}
					System.Security.SecureString arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Security.SecureString)_temp;
					}

					object _result_ = _this.Export((System.Security.Cryptography.X509Certificates.X509ContentType)arg0,(System.Security.SecureString)arg1)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("Export",new Type[] {typeof(System.Security.Cryptography.X509Certificates.X509ContentType),typeof(System.Security.SecureString)});;
				}
				return method;
			}

		}

		public class system_security_cryptography_x509certificates_X509Certificate_reset : NativeConstParameterFunction,IMethodGetter
		{
			public system_security_cryptography_x509certificates_X509Certificate_reset() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_security_cryptography_x509certificates_X509Certificate_reset";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Security.Cryptography.X509Certificates.X509Certificate _this =
					(System.Security.Cryptography.X509Certificates.X509Certificate)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					_this.Reset()
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Security.Cryptography.X509Certificates.X509Certificate).GetMethod("Reset",Type.EmptyTypes);;
				}
				return method;
			}

		}

	}
}
