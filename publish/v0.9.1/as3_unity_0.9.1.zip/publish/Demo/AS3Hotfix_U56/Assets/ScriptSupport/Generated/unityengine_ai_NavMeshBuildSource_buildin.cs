using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class unityengine_ai_NavMeshBuildSource_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("unityengine_ai_NavMeshBuildSource_creator", default(UnityEngine.AI.NavMeshBuildSource)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuildSource_buildin.unityengine_ai_NavMeshBuildSource_ctor","unityengine_ai_NavMeshBuildSource_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuildSource_buildin.unityengine_ai_NavMeshBuildSource_get_transform","unityengine_ai_NavMeshBuildSource_get_transform");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuildSource_buildin.unityengine_ai_NavMeshBuildSource_set_transform","unityengine_ai_NavMeshBuildSource_set_transform");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuildSource_buildin.unityengine_ai_NavMeshBuildSource_get_size","unityengine_ai_NavMeshBuildSource_get_size");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuildSource_buildin.unityengine_ai_NavMeshBuildSource_set_size","unityengine_ai_NavMeshBuildSource_set_size");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuildSource_buildin.unityengine_ai_NavMeshBuildSource_get_shape","unityengine_ai_NavMeshBuildSource_get_shape");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuildSource_buildin.unityengine_ai_NavMeshBuildSource_set_shape","unityengine_ai_NavMeshBuildSource_set_shape");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuildSource_buildin.unityengine_ai_NavMeshBuildSource_get_area","unityengine_ai_NavMeshBuildSource_get_area");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuildSource_buildin.unityengine_ai_NavMeshBuildSource_set_area","unityengine_ai_NavMeshBuildSource_set_area");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuildSource_buildin.unityengine_ai_NavMeshBuildSource_get_sourceObject","unityengine_ai_NavMeshBuildSource_get_sourceObject");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuildSource_buildin.unityengine_ai_NavMeshBuildSource_set_sourceObject","unityengine_ai_NavMeshBuildSource_set_sourceObject");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuildSource_buildin.unityengine_ai_NavMeshBuildSource_get_component","unityengine_ai_NavMeshBuildSource_get_component");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.unityengine_ai_NavMeshBuildSource_buildin.unityengine_ai_NavMeshBuildSource_set_component","unityengine_ai_NavMeshBuildSource_set_component");
		}


		public class unityengine_ai_NavMeshBuildSource_ctor : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshBuildSource_ctor() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshBuildSource_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{

					((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new UnityEngine.AI.NavMeshBuildSource();
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshBuildSource_get_transform : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshBuildSource_get_transform() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshBuildSource_get_transform";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshBuildSource _this =
					(UnityEngine.AI.NavMeshBuildSource)((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					UnityEngine.Matrix4x4 _result_ = _this.transform
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshBuildSource_set_transform : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshBuildSource_set_transform() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshBuildSource_set_transform";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshBuildSource _this =
					(UnityEngine.AI.NavMeshBuildSource)((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					UnityEngine.Matrix4x4 arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(UnityEngine.Matrix4x4);
					}
					else
					{
						LinkObj<UnityEngine.Matrix4x4> argObj = (LinkObj<UnityEngine.Matrix4x4>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					_this.transform = (UnityEngine.Matrix4x4)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshBuildSource_get_size : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshBuildSource_get_size() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshBuildSource_get_size";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshBuildSource _this =
					(UnityEngine.AI.NavMeshBuildSource)((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					UnityEngine.Vector3 _result_ = _this.size
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshBuildSource_set_size : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshBuildSource_set_size() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshBuildSource_set_size";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshBuildSource _this =
					(UnityEngine.AI.NavMeshBuildSource)((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					UnityEngine.Vector3 arg0;

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						arg0 = default(UnityEngine.Vector3);
					}
					else
					{
						LinkObj<UnityEngine.Vector3> argObj = (LinkObj<UnityEngine.Vector3>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
						arg0 = argObj.value;
					}

					_this.size = (UnityEngine.Vector3)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshBuildSource_get_shape : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshBuildSource_get_shape() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshBuildSource_get_shape";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshBuildSource _this =
					(UnityEngine.AI.NavMeshBuildSource)((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					UnityEngine.AI.NavMeshBuildSourceShape _result_ = _this.shape
					;
					((StackSlot)returnSlot).setLinkObjectValue(bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, _result_);
					((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshBuildSource_set_shape : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshBuildSource_set_shape() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshBuildSource_set_shape";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshBuildSource _this =
					(UnityEngine.AI.NavMeshBuildSource)((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					UnityEngine.AI.NavMeshBuildSourceShape arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.AI.NavMeshBuildSourceShape)_temp;
					}

					_this.shape = (UnityEngine.AI.NavMeshBuildSourceShape)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshBuildSource_get_area : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshBuildSource_get_area() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshBuildSource_get_area";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshBuildSource _this =
					(UnityEngine.AI.NavMeshBuildSource)((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					int _result_ = (int)(_this.area
					)
					;
					returnSlot.setValue(_result_);

					((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshBuildSource_set_area : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshBuildSource_set_area() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshBuildSource_set_area";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshBuildSource _this =
					(UnityEngine.AI.NavMeshBuildSource)((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					_this.area = (System.Int32)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshBuildSource_get_sourceObject : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshBuildSource_get_sourceObject() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshBuildSource_get_sourceObject";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshBuildSource _this =
					(UnityEngine.AI.NavMeshBuildSource)((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					object _result_ = _this.sourceObject
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshBuildSource_set_sourceObject : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshBuildSource_set_sourceObject() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshBuildSource_set_sourceObject";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshBuildSource _this =
					(UnityEngine.AI.NavMeshBuildSource)((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					UnityEngine.Object arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.Object)_temp;
					}

					_this.sourceObject = (UnityEngine.Object)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshBuildSource_get_component : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshBuildSource_get_component() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshBuildSource_get_component";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshBuildSource _this =
					(UnityEngine.AI.NavMeshBuildSource)((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{

					object _result_ = _this.component
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class unityengine_ai_NavMeshBuildSource_set_component : NativeConstParameterFunction
		{
			public unityengine_ai_NavMeshBuildSource_set_component() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "unityengine_ai_NavMeshBuildSource_set_component";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				UnityEngine.AI.NavMeshBuildSource _this =
					(UnityEngine.AI.NavMeshBuildSource)((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value;

				try
				{
					UnityEngine.Component arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.Component)_temp;
					}

					_this.component = (UnityEngine.Component)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					((LinkObj<UnityEngine.AI.NavMeshBuildSource>)((ASBinCode.rtData.rtObjectBase) thisObj).value).value = _this;
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

	}
}
