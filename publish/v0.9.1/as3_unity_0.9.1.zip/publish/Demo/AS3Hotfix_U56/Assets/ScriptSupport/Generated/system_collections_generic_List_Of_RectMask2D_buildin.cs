using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_collections_generic_List_Of_RectMask2D_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_collections_generic_List_Of_RectMask2D_creator", default(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_constructor_","system_collections_generic_List_Of_RectMask2D_constructor_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_ctor","system_collections_generic_List_Of_RectMask2D_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin._system_collections_generic_List_Of_RectMask2DAdapter_ctor","_system_collections_generic_List_Of_RectMask2DAdapter_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_get_Capacity","system_collections_generic_List_Of_RectMask2D_get_Capacity");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_set_Capacity","system_collections_generic_List_Of_RectMask2D_set_Capacity");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_getThisItem","system_collections_generic_List_Of_RectMask2D_getThisItem");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_setThisItem","system_collections_generic_List_Of_RectMask2D_setThisItem");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_add","system_collections_generic_List_Of_RectMask2D_add");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_asReadOnly","system_collections_generic_List_Of_RectMask2D_asReadOnly");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_binarySearch_","system_collections_generic_List_Of_RectMask2D_binarySearch_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_contains","system_collections_generic_List_Of_RectMask2D_contains");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_copyTo","system_collections_generic_List_Of_RectMask2D_copyTo");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_copyTo_","system_collections_generic_List_Of_RectMask2D_copyTo_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_copyTo__","system_collections_generic_List_Of_RectMask2D_copyTo__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_exists","system_collections_generic_List_Of_RectMask2D_exists");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_find","system_collections_generic_List_Of_RectMask2D_find");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_findAll","system_collections_generic_List_Of_RectMask2D_findAll");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_findIndex","system_collections_generic_List_Of_RectMask2D_findIndex");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_findIndex_","system_collections_generic_List_Of_RectMask2D_findIndex_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_findIndex__","system_collections_generic_List_Of_RectMask2D_findIndex__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_findLast","system_collections_generic_List_Of_RectMask2D_findLast");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_findLastIndex","system_collections_generic_List_Of_RectMask2D_findLastIndex");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_findLastIndex_","system_collections_generic_List_Of_RectMask2D_findLastIndex_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_findLastIndex__","system_collections_generic_List_Of_RectMask2D_findLastIndex__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_forEach","system_collections_generic_List_Of_RectMask2D_forEach");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_getRange","system_collections_generic_List_Of_RectMask2D_getRange");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_indexOf","system_collections_generic_List_Of_RectMask2D_indexOf");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_indexOf_","system_collections_generic_List_Of_RectMask2D_indexOf_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_indexOf__","system_collections_generic_List_Of_RectMask2D_indexOf__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_insert","system_collections_generic_List_Of_RectMask2D_insert");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_lastIndexOf","system_collections_generic_List_Of_RectMask2D_lastIndexOf");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_lastIndexOf_","system_collections_generic_List_Of_RectMask2D_lastIndexOf_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_lastIndexOf__","system_collections_generic_List_Of_RectMask2D_lastIndexOf__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_remove","system_collections_generic_List_Of_RectMask2D_remove");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_removeAll","system_collections_generic_List_Of_RectMask2D_removeAll");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_removeRange","system_collections_generic_List_Of_RectMask2D_removeRange");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_reverse","system_collections_generic_List_Of_RectMask2D_reverse");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_reverse_","system_collections_generic_List_Of_RectMask2D_reverse_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_sort","system_collections_generic_List_Of_RectMask2D_sort");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_sort___","system_collections_generic_List_Of_RectMask2D_sort___");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_toArray","system_collections_generic_List_Of_RectMask2D_toArray");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_trimExcess","system_collections_generic_List_Of_RectMask2D_trimExcess");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_RectMask2D_buildin.system_collections_generic_List_Of_RectMask2D_trueForAll","system_collections_generic_List_Of_RectMask2D_trueForAll");
		}

		public class system_collections_generic_List_Of_RectMask2DAdapter :System.Collections.Generic.List<UnityEngine.UI.RectMask2D> ,ASRuntime.ICrossExtendAdapter
		{

			public ASBinCode.rtti.Class AS3Class { get { return typeclass; } }

			public ASBinCode.rtData.rtObjectBase AS3Object { get { return bindAS3Object; } }

			protected Player player;
			private Class typeclass;
			private ASBinCode.rtData.rtObjectBase bindAS3Object;

			public void SetAS3RuntimeEnvironment(Player player, Class typeclass, ASBinCode.rtData.rtObjectBase bindAS3Object)
			{
				this.player = player;
				this.typeclass = typeclass;
				this.bindAS3Object = bindAS3Object;
			}

			public system_collections_generic_List_Of_RectMask2DAdapter():base(){}

		}
		public class system_collections_generic_List_Of_RectMask2D_constructor_ : NativeConstParameterFunction
		{
			public system_collections_generic_List_Of_RectMask2D_constructor_() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_constructor_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Collections.Generic.List<UnityEngine.UI.RectMask2D>((System.Int32)arg0));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_generic_List_Of_RectMask2D_ctor : NativeConstParameterFunction
		{
			public system_collections_generic_List_Of_RectMask2D_ctor() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{

					((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new System.Collections.Generic.List<UnityEngine.UI.RectMask2D>();
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class _system_collections_generic_List_Of_RectMask2DAdapter_ctor : NativeConstParameterFunction,ICrossExtendAdapterCreator
		{
			public _system_collections_generic_List_Of_RectMask2DAdapter_ctor() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public Type GetAdapterType()
			{
				return typeof(system_collections_generic_List_Of_RectMask2DAdapter);
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "_system_collections_generic_List_Of_RectMask2DAdapter_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{

					((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new system_collections_generic_List_Of_RectMask2DAdapter();

					((ICrossExtendAdapter)((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value)
						.SetAS3RuntimeEnvironment(stackframe.player, ((ASBinCode.rtData.rtObjectBase)thisObj).value._class, (ASBinCode.rtData.rtObjectBase)thisObj);


					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_generic_List_Of_RectMask2D_get_Capacity : NativeConstParameterFunction
		{
			public system_collections_generic_List_Of_RectMask2D_get_Capacity() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_get_Capacity";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					int _result_ = (int)(_this.Capacity
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_generic_List_Of_RectMask2D_set_Capacity : NativeConstParameterFunction
		{
			public system_collections_generic_List_Of_RectMask2D_set_Capacity() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_set_Capacity";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					_this.Capacity = (System.Int32)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_generic_List_Of_RectMask2D_getThisItem : NativeConstParameterFunction
		{
			public system_collections_generic_List_Of_RectMask2D_getThisItem() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_getThisItem";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					object _result_ = _this[(System.Int32)arg0]
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_generic_List_Of_RectMask2D_setThisItem : NativeConstParameterFunction
		{
			public system_collections_generic_List_Of_RectMask2D_setThisItem() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_setThisItem";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.UI.RectMask2D arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.UI.RectMask2D)_temp;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					_this[(System.Int32)arg1] = (UnityEngine.UI.RectMask2D)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_generic_List_Of_RectMask2D_add : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_add() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_add";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.UI.RectMask2D arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.UI.RectMask2D)_temp;
					}

					_this.Add((UnityEngine.UI.RectMask2D)arg0)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("Add",new Type[] {typeof(UnityEngine.UI.RectMask2D)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_asReadOnly : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_asReadOnly() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_asReadOnly";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.AsReadOnly()
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("AsReadOnly",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_binarySearch_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_binarySearch_() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_binarySearch_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.UI.RectMask2D arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.UI.RectMask2D)_temp;
					}

					int _result_ = (int)(_this.BinarySearch((UnityEngine.UI.RectMask2D)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("BinarySearch",new Type[] {typeof(UnityEngine.UI.RectMask2D)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_contains : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_contains() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_contains";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.UI.RectMask2D arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.UI.RectMask2D)_temp;
					}

					bool _result_ = _this.Contains((UnityEngine.UI.RectMask2D)arg0)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("Contains",new Type[] {typeof(UnityEngine.UI.RectMask2D)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_copyTo : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_copyTo() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_copyTo";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.UI.RectMask2D[] arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.UI.RectMask2D[])_temp;
					}

					_this.CopyTo((UnityEngine.UI.RectMask2D[])arg0)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("CopyTo",new Type[] {typeof(UnityEngine.UI.RectMask2D[])});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_copyTo_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_copyTo_() : base(4)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_copyTo_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					UnityEngine.UI.RectMask2D[] arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (UnityEngine.UI.RectMask2D[])_temp;
					}
					int arg2 = TypeConverter.ConvertToInt(argements[2]);
					int arg3 = TypeConverter.ConvertToInt(argements[3]);

					_this.CopyTo((System.Int32)arg0,(UnityEngine.UI.RectMask2D[])arg1,(System.Int32)arg2,(System.Int32)arg3)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("CopyTo",new Type[] {typeof(System.Int32),typeof(UnityEngine.UI.RectMask2D[]),typeof(System.Int32),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_copyTo__ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_copyTo__() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_copyTo__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.UI.RectMask2D[] arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.UI.RectMask2D[])_temp;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					_this.CopyTo((UnityEngine.UI.RectMask2D[])arg0,(System.Int32)arg1)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("CopyTo",new Type[] {typeof(UnityEngine.UI.RectMask2D[]),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_exists : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_exists() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_exists";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Predicate<UnityEngine.UI.RectMask2D> arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Predicate<UnityEngine.UI.RectMask2D>)_temp;
					}

					bool _result_ = _this.Exists((System.Predicate<UnityEngine.UI.RectMask2D>)arg0)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("Exists",new Type[] {typeof(System.Predicate<UnityEngine.UI.RectMask2D>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_find : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_find() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_find";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Predicate<UnityEngine.UI.RectMask2D> arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Predicate<UnityEngine.UI.RectMask2D>)_temp;
					}

					object _result_ = _this.Find((System.Predicate<UnityEngine.UI.RectMask2D>)arg0)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("Find",new Type[] {typeof(System.Predicate<UnityEngine.UI.RectMask2D>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_findAll : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_findAll() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_findAll";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Predicate<UnityEngine.UI.RectMask2D> arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Predicate<UnityEngine.UI.RectMask2D>)_temp;
					}

					object _result_ = _this.FindAll((System.Predicate<UnityEngine.UI.RectMask2D>)arg0)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("FindAll",new Type[] {typeof(System.Predicate<UnityEngine.UI.RectMask2D>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_findIndex : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_findIndex() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_findIndex";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Predicate<UnityEngine.UI.RectMask2D> arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Predicate<UnityEngine.UI.RectMask2D>)_temp;
					}

					int _result_ = (int)(_this.FindIndex((System.Predicate<UnityEngine.UI.RectMask2D>)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("FindIndex",new Type[] {typeof(System.Predicate<UnityEngine.UI.RectMask2D>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_findIndex_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_findIndex_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_findIndex_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					System.Predicate<UnityEngine.UI.RectMask2D> arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Predicate<UnityEngine.UI.RectMask2D>)_temp;
					}

					int _result_ = (int)(_this.FindIndex((System.Int32)arg0,(System.Predicate<UnityEngine.UI.RectMask2D>)arg1)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("FindIndex",new Type[] {typeof(System.Int32),typeof(System.Predicate<UnityEngine.UI.RectMask2D>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_findIndex__ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_findIndex__() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_findIndex__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					System.Predicate<UnityEngine.UI.RectMask2D> arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Predicate<UnityEngine.UI.RectMask2D>)_temp;
					}

					int _result_ = (int)(_this.FindIndex((System.Int32)arg0,(System.Int32)arg1,(System.Predicate<UnityEngine.UI.RectMask2D>)arg2)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("FindIndex",new Type[] {typeof(System.Int32),typeof(System.Int32),typeof(System.Predicate<UnityEngine.UI.RectMask2D>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_findLast : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_findLast() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_findLast";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Predicate<UnityEngine.UI.RectMask2D> arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Predicate<UnityEngine.UI.RectMask2D>)_temp;
					}

					object _result_ = _this.FindLast((System.Predicate<UnityEngine.UI.RectMask2D>)arg0)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("FindLast",new Type[] {typeof(System.Predicate<UnityEngine.UI.RectMask2D>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_findLastIndex : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_findLastIndex() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_findLastIndex";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Predicate<UnityEngine.UI.RectMask2D> arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Predicate<UnityEngine.UI.RectMask2D>)_temp;
					}

					int _result_ = (int)(_this.FindLastIndex((System.Predicate<UnityEngine.UI.RectMask2D>)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("FindLastIndex",new Type[] {typeof(System.Predicate<UnityEngine.UI.RectMask2D>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_findLastIndex_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_findLastIndex_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_findLastIndex_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					System.Predicate<UnityEngine.UI.RectMask2D> arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Predicate<UnityEngine.UI.RectMask2D>)_temp;
					}

					int _result_ = (int)(_this.FindLastIndex((System.Int32)arg0,(System.Predicate<UnityEngine.UI.RectMask2D>)arg1)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("FindLastIndex",new Type[] {typeof(System.Int32),typeof(System.Predicate<UnityEngine.UI.RectMask2D>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_findLastIndex__ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_findLastIndex__() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_findLastIndex__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					System.Predicate<UnityEngine.UI.RectMask2D> arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Predicate<UnityEngine.UI.RectMask2D>)_temp;
					}

					int _result_ = (int)(_this.FindLastIndex((System.Int32)arg0,(System.Int32)arg1,(System.Predicate<UnityEngine.UI.RectMask2D>)arg2)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("FindLastIndex",new Type[] {typeof(System.Int32),typeof(System.Int32),typeof(System.Predicate<UnityEngine.UI.RectMask2D>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_forEach : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_forEach() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_forEach";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Action<UnityEngine.UI.RectMask2D> arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Action<UnityEngine.UI.RectMask2D>)_temp;
					}

					_this.ForEach((System.Action<UnityEngine.UI.RectMask2D>)arg0)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("ForEach",new Type[] {typeof(System.Action<UnityEngine.UI.RectMask2D>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_getRange : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_getRange() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_getRange";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					object _result_ = _this.GetRange((System.Int32)arg0,(System.Int32)arg1)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("GetRange",new Type[] {typeof(System.Int32),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_indexOf : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_indexOf() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_indexOf";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.UI.RectMask2D arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.UI.RectMask2D)_temp;
					}

					int _result_ = (int)(_this.IndexOf((UnityEngine.UI.RectMask2D)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("IndexOf",new Type[] {typeof(UnityEngine.UI.RectMask2D)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_indexOf_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_indexOf_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_indexOf_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.UI.RectMask2D arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.UI.RectMask2D)_temp;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					int _result_ = (int)(_this.IndexOf((UnityEngine.UI.RectMask2D)arg0,(System.Int32)arg1)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("IndexOf",new Type[] {typeof(UnityEngine.UI.RectMask2D),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_indexOf__ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_indexOf__() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_indexOf__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.UI.RectMask2D arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.UI.RectMask2D)_temp;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					int arg2 = TypeConverter.ConvertToInt(argements[2]);

					int _result_ = (int)(_this.IndexOf((UnityEngine.UI.RectMask2D)arg0,(System.Int32)arg1,(System.Int32)arg2)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("IndexOf",new Type[] {typeof(UnityEngine.UI.RectMask2D),typeof(System.Int32),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_insert : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_insert() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_insert";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					UnityEngine.UI.RectMask2D arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (UnityEngine.UI.RectMask2D)_temp;
					}

					_this.Insert((System.Int32)arg0,(UnityEngine.UI.RectMask2D)arg1)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("Insert",new Type[] {typeof(System.Int32),typeof(UnityEngine.UI.RectMask2D)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_lastIndexOf : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_lastIndexOf() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_lastIndexOf";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.UI.RectMask2D arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.UI.RectMask2D)_temp;
					}

					int _result_ = (int)(_this.LastIndexOf((UnityEngine.UI.RectMask2D)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("LastIndexOf",new Type[] {typeof(UnityEngine.UI.RectMask2D)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_lastIndexOf_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_lastIndexOf_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_lastIndexOf_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.UI.RectMask2D arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.UI.RectMask2D)_temp;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					int _result_ = (int)(_this.LastIndexOf((UnityEngine.UI.RectMask2D)arg0,(System.Int32)arg1)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("LastIndexOf",new Type[] {typeof(UnityEngine.UI.RectMask2D),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_lastIndexOf__ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_lastIndexOf__() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_lastIndexOf__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.UI.RectMask2D arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.UI.RectMask2D)_temp;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					int arg2 = TypeConverter.ConvertToInt(argements[2]);

					int _result_ = (int)(_this.LastIndexOf((UnityEngine.UI.RectMask2D)arg0,(System.Int32)arg1,(System.Int32)arg2)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("LastIndexOf",new Type[] {typeof(UnityEngine.UI.RectMask2D),typeof(System.Int32),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_remove : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_remove() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_remove";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.UI.RectMask2D arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.UI.RectMask2D)_temp;
					}

					bool _result_ = _this.Remove((UnityEngine.UI.RectMask2D)arg0)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("Remove",new Type[] {typeof(UnityEngine.UI.RectMask2D)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_removeAll : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_removeAll() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_removeAll";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Predicate<UnityEngine.UI.RectMask2D> arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Predicate<UnityEngine.UI.RectMask2D>)_temp;
					}

					int _result_ = (int)(_this.RemoveAll((System.Predicate<UnityEngine.UI.RectMask2D>)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("RemoveAll",new Type[] {typeof(System.Predicate<UnityEngine.UI.RectMask2D>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_removeRange : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_removeRange() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_removeRange";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					_this.RemoveRange((System.Int32)arg0,(System.Int32)arg1)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("RemoveRange",new Type[] {typeof(System.Int32),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_reverse : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_reverse() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_reverse";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					_this.Reverse()
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("Reverse",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_reverse_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_reverse_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_reverse_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					_this.Reverse((System.Int32)arg0,(System.Int32)arg1)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("Reverse",new Type[] {typeof(System.Int32),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_sort : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_sort() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_sort";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					_this.Sort()
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("Sort",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_sort___ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_sort___() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_sort___";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Comparison<UnityEngine.UI.RectMask2D> arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Comparison<UnityEngine.UI.RectMask2D>)_temp;
					}

					_this.Sort((System.Comparison<UnityEngine.UI.RectMask2D>)arg0)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("Sort",new Type[] {typeof(System.Comparison<UnityEngine.UI.RectMask2D>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_toArray : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_toArray() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_toArray";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.ToArray()
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("ToArray",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_trimExcess : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_trimExcess() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_trimExcess";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					_this.TrimExcess()
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("TrimExcess",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_RectMask2D_trueForAll : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_RectMask2D_trueForAll() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_RectMask2D_trueForAll";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.UI.RectMask2D> _this =
					(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Predicate<UnityEngine.UI.RectMask2D> arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Predicate<UnityEngine.UI.RectMask2D>)_temp;
					}

					bool _result_ = _this.TrueForAll((System.Predicate<UnityEngine.UI.RectMask2D>)arg0)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.UI.RectMask2D>).GetMethod("TrueForAll",new Type[] {typeof(System.Predicate<UnityEngine.UI.RectMask2D>)});;
				}
				return method;
			}

		}

	}
}
