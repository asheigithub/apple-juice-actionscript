using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_collections_SortedList_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_collections_SortedList_creator", default(System.Collections.SortedList)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_SortedList_buildin.system_collections_SortedList_constructor_","system_collections_SortedList_constructor_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_SortedList_buildin.system_collections_SortedList_constructor__","system_collections_SortedList_constructor__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_SortedList_buildin.system_collections_SortedList_constructor___","system_collections_SortedList_constructor___");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_SortedList_buildin.system_collections_SortedList_constructor____","system_collections_SortedList_constructor____");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_SortedList_buildin.system_collections_SortedList_constructor_____","system_collections_SortedList_constructor_____");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_SortedList_buildin.system_collections_SortedList_ctor","system_collections_SortedList_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_SortedList_buildin._system_collections_SortedListAdapter_ctor","_system_collections_SortedListAdapter_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_SortedList_buildin.system_collections_SortedList_get_Capacity","system_collections_SortedList_get_Capacity");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_SortedList_buildin.system_collections_SortedList_set_Capacity","system_collections_SortedList_set_Capacity");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_SortedList_buildin.system_collections_SortedList_containsKey","system_collections_SortedList_containsKey");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_SortedList_buildin.system_collections_SortedList_containsValue","system_collections_SortedList_containsValue");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_SortedList_buildin.system_collections_SortedList_getByIndex","system_collections_SortedList_getByIndex");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_SortedList_buildin.system_collections_SortedList_getKey","system_collections_SortedList_getKey");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_SortedList_buildin.system_collections_SortedList_getKeyList","system_collections_SortedList_getKeyList");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_SortedList_buildin.system_collections_SortedList_getValueList","system_collections_SortedList_getValueList");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_SortedList_buildin.system_collections_SortedList_indexOfKey","system_collections_SortedList_indexOfKey");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_SortedList_buildin.system_collections_SortedList_indexOfValue","system_collections_SortedList_indexOfValue");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_SortedList_buildin.system_collections_SortedList_removeAt","system_collections_SortedList_removeAt");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_SortedList_buildin.system_collections_SortedList_setByIndex","system_collections_SortedList_setByIndex");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_SortedList_buildin.static_system_collections_SortedList_synchronized","static_system_collections_SortedList_synchronized");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_SortedList_buildin.system_collections_SortedList_trimToSize","system_collections_SortedList_trimToSize");
		}

		public class system_collections_SortedListAdapter :System.Collections.SortedList ,ASRuntime.ICrossExtendAdapter
		{

			public ASBinCode.rtti.Class AS3Class { get { return typeclass; } }

			public ASBinCode.rtData.rtObjectBase AS3Object { get { return bindAS3Object; } }

			protected Player player;
			private Class typeclass;
			private ASBinCode.rtData.rtObjectBase bindAS3Object;

			public void SetAS3RuntimeEnvironment(Player player, Class typeclass, ASBinCode.rtData.rtObjectBase bindAS3Object)
			{
				this.player = player;
				this.typeclass = typeclass;
				this.bindAS3Object = bindAS3Object;
			}

			public system_collections_SortedListAdapter():base(){}
			private ASBinCode.rtData.rtFunction _as3function_0;
			private int _as3functionId_0 =-1;
			public override void Add(System.Object key,System.Object value)
			{

				if (_as3function_0 == null)
					_as3function_0 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "add");
				if (_as3functionId_0 == -1)
				{
					_as3functionId_0 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("add").bindField).functionId;
				}

				if (_as3function_0 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_0
				)
				))
				)
				)
				{
base.Add(key,value);
				}
				else
				{
					player.InvokeFunction(_as3function_0,2,key,value,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_1;
			private int _as3functionId_1 =-1;
			public override void Clear()
			{

				if (_as3function_1 == null)
					_as3function_1 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "clear");
				if (_as3functionId_1 == -1)
				{
					_as3functionId_1 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("clear").bindField).functionId;
				}

				if (_as3function_1 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_1
				)
				))
				)
				)
				{
base.Clear();
				}
				else
				{
					player.InvokeFunction(_as3function_1,0,null,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_2;
			private int _as3functionId_2 =-1;
			public override System.Object Clone()
			{

				if (_as3function_2 == null)
					_as3function_2 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "clone");
				if (_as3functionId_2 == -1)
				{
					_as3functionId_2 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("clone").bindField).functionId;
				}

				if (_as3function_2 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_2
				)
				))
				)
				)
				{
					return base.Clone();
				}
				else
				{
					return (System.Object)player.InvokeFunction(_as3function_2,0,null,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_3;
			private int _as3functionId_3 =-1;
			public override System.Boolean Contains(System.Object key)
			{

				if (_as3function_3 == null)
					_as3function_3 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "contains");
				if (_as3functionId_3 == -1)
				{
					_as3functionId_3 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("contains").bindField).functionId;
				}

				if (_as3function_3 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_3
				)
				))
				)
				)
				{
					return base.Contains(key);
				}
				else
				{
					return (System.Boolean)player.InvokeFunction(_as3function_3,1,key,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_4;
			private int _as3functionId_4 =-1;
			public override System.Boolean ContainsKey(System.Object key)
			{

				if (_as3function_4 == null)
					_as3function_4 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "containsKey");
				if (_as3functionId_4 == -1)
				{
					_as3functionId_4 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("containsKey").bindField).functionId;
				}

				if (_as3function_4 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_4
				)
				))
				)
				)
				{
					return base.ContainsKey(key);
				}
				else
				{
					return (System.Boolean)player.InvokeFunction(_as3function_4,1,key,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_5;
			private int _as3functionId_5 =-1;
			public override System.Boolean ContainsValue(System.Object value)
			{

				if (_as3function_5 == null)
					_as3function_5 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "containsValue");
				if (_as3functionId_5 == -1)
				{
					_as3functionId_5 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("containsValue").bindField).functionId;
				}

				if (_as3function_5 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_5
				)
				))
				)
				)
				{
					return base.ContainsValue(value);
				}
				else
				{
					return (System.Boolean)player.InvokeFunction(_as3function_5,1,value,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_6;
			private int _as3functionId_6 =-1;
			public override void CopyTo(System.Array array,System.Int32 arrayIndex)
			{

				if (_as3function_6 == null)
					_as3function_6 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "copyTo");
				if (_as3functionId_6 == -1)
				{
					_as3functionId_6 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("copyTo").bindField).functionId;
				}

				if (_as3function_6 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_6
				)
				))
				)
				)
				{
base.CopyTo(array,arrayIndex);
				}
				else
				{
					player.InvokeFunction(_as3function_6,2,array,arrayIndex,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_7;
			private int _as3functionId_7 =-1;
			public override System.Object GetByIndex(System.Int32 index)
			{

				if (_as3function_7 == null)
					_as3function_7 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "getByIndex");
				if (_as3functionId_7 == -1)
				{
					_as3functionId_7 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("getByIndex").bindField).functionId;
				}

				if (_as3function_7 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_7
				)
				))
				)
				)
				{
					return base.GetByIndex(index);
				}
				else
				{
					return (System.Object)player.InvokeFunction(_as3function_7,1,index,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_8;
			private int _as3functionId_8 =-1;
			public override System.Collections.IDictionaryEnumerator GetEnumerator()
			{

				if (_as3function_8 == null)
					_as3function_8 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "getEnumerator");
				if (_as3functionId_8 == -1)
				{
					_as3functionId_8 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("getEnumerator").bindField).functionId;
				}

				if (_as3function_8 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_8
				)
				))
				)
				)
				{
					return base.GetEnumerator();
				}
				else
				{
					return (System.Collections.IDictionaryEnumerator)player.InvokeFunction(_as3function_8,0,null,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_9;
			private int _as3functionId_9 =-1;
			public override System.Object GetKey(System.Int32 index)
			{

				if (_as3function_9 == null)
					_as3function_9 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "getKey");
				if (_as3functionId_9 == -1)
				{
					_as3functionId_9 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("getKey").bindField).functionId;
				}

				if (_as3function_9 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_9
				)
				))
				)
				)
				{
					return base.GetKey(index);
				}
				else
				{
					return (System.Object)player.InvokeFunction(_as3function_9,1,index,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_10;
			private int _as3functionId_10 =-1;
			public override System.Collections.IList GetKeyList()
			{

				if (_as3function_10 == null)
					_as3function_10 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "getKeyList");
				if (_as3functionId_10 == -1)
				{
					_as3functionId_10 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("getKeyList").bindField).functionId;
				}

				if (_as3function_10 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_10
				)
				))
				)
				)
				{
					return base.GetKeyList();
				}
				else
				{
					return (System.Collections.IList)player.InvokeFunction(_as3function_10,0,null,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_11;
			private int _as3functionId_11 =-1;
			public override System.Collections.IList GetValueList()
			{

				if (_as3function_11 == null)
					_as3function_11 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "getValueList");
				if (_as3functionId_11 == -1)
				{
					_as3functionId_11 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("getValueList").bindField).functionId;
				}

				if (_as3function_11 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_11
				)
				))
				)
				)
				{
					return base.GetValueList();
				}
				else
				{
					return (System.Collections.IList)player.InvokeFunction(_as3function_11,0,null,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_12;
			private int _as3functionId_12 =-1;
			public override System.Int32 IndexOfKey(System.Object key)
			{

				if (_as3function_12 == null)
					_as3function_12 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "indexOfKey");
				if (_as3functionId_12 == -1)
				{
					_as3functionId_12 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("indexOfKey").bindField).functionId;
				}

				if (_as3function_12 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_12
				)
				))
				)
				)
				{
					return base.IndexOfKey(key);
				}
				else
				{
					return (System.Int32)player.InvokeFunction(_as3function_12,1,key,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_13;
			private int _as3functionId_13 =-1;
			public override System.Int32 IndexOfValue(System.Object value)
			{

				if (_as3function_13 == null)
					_as3function_13 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "indexOfValue");
				if (_as3functionId_13 == -1)
				{
					_as3functionId_13 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("indexOfValue").bindField).functionId;
				}

				if (_as3function_13 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_13
				)
				))
				)
				)
				{
					return base.IndexOfValue(value);
				}
				else
				{
					return (System.Int32)player.InvokeFunction(_as3function_13,1,value,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_14;
			private int _as3functionId_14 =-1;
			public override void RemoveAt(System.Int32 index)
			{

				if (_as3function_14 == null)
					_as3function_14 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "removeAt");
				if (_as3functionId_14 == -1)
				{
					_as3functionId_14 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("removeAt").bindField).functionId;
				}

				if (_as3function_14 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_14
				)
				))
				)
				)
				{
base.RemoveAt(index);
				}
				else
				{
					player.InvokeFunction(_as3function_14,1,index,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_15;
			private int _as3functionId_15 =-1;
			public override void Remove(System.Object key)
			{

				if (_as3function_15 == null)
					_as3function_15 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "remove");
				if (_as3functionId_15 == -1)
				{
					_as3functionId_15 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("remove").bindField).functionId;
				}

				if (_as3function_15 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_15
				)
				))
				)
				)
				{
base.Remove(key);
				}
				else
				{
					player.InvokeFunction(_as3function_15,1,key,null,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_16;
			private int _as3functionId_16 =-1;
			public override void SetByIndex(System.Int32 index,System.Object value)
			{

				if (_as3function_16 == null)
					_as3function_16 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "setByIndex");
				if (_as3functionId_16 == -1)
				{
					_as3functionId_16 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("setByIndex").bindField).functionId;
				}

				if (_as3function_16 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_16
				)
				))
				)
				)
				{
base.SetByIndex(index,value);
				}
				else
				{
					player.InvokeFunction(_as3function_16,2,index,value,null,null,null,null);
				}
			}

			private ASBinCode.rtData.rtFunction _as3function_17;
			private int _as3functionId_17 =-1;
			public override void TrimToSize()
			{

				if (_as3function_17 == null)
					_as3function_17 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "trimToSize");
				if (_as3functionId_17 == -1)
				{
					_as3functionId_17 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("trimToSize").bindField).functionId;
				}

				if (_as3function_17 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_17
				)
				))
				)
				)
				{
base.TrimToSize();
				}
				else
				{
					player.InvokeFunction(_as3function_17,0,null,null,null,null,null,null);
				}
			}


		}
		public class system_collections_SortedList_constructor_ : NativeConstParameterFunction
		{
			public system_collections_SortedList_constructor_() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_SortedList_constructor_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Collections.SortedList((System.Int32)arg0));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_SortedList_constructor__ : NativeConstParameterFunction
		{
			public system_collections_SortedList_constructor__() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_SortedList_constructor__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.Collections.IComparer arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Collections.IComparer)_temp;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Collections.SortedList((System.Collections.IComparer)arg0));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_SortedList_constructor___ : NativeConstParameterFunction
		{
			public system_collections_SortedList_constructor___() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_SortedList_constructor___";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.Collections.IComparer arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Collections.IComparer)_temp;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Collections.SortedList((System.Collections.IComparer)arg0,(System.Int32)arg1));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_SortedList_constructor____ : NativeConstParameterFunction
		{
			public system_collections_SortedList_constructor____() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_SortedList_constructor____";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.Collections.IDictionary arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Collections.IDictionary)_temp;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Collections.SortedList((System.Collections.IDictionary)arg0));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_SortedList_constructor_____ : NativeConstParameterFunction
		{
			public system_collections_SortedList_constructor_____() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_SortedList_constructor_____";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.Collections.IDictionary arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Collections.IDictionary)_temp;
					}
					System.Collections.IComparer arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Collections.IComparer)_temp;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Collections.SortedList((System.Collections.IDictionary)arg0,(System.Collections.IComparer)arg1));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_SortedList_ctor : NativeConstParameterFunction
		{
			public system_collections_SortedList_ctor() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_SortedList_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{

					((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new System.Collections.SortedList();
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class _system_collections_SortedListAdapter_ctor : NativeConstParameterFunction,ICrossExtendAdapterCreator
		{
			public _system_collections_SortedListAdapter_ctor() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public Type GetAdapterType()
			{
				return typeof(system_collections_SortedListAdapter);
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "_system_collections_SortedListAdapter_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{

					((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new system_collections_SortedListAdapter();

					((ICrossExtendAdapter)((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value)
						.SetAS3RuntimeEnvironment(stackframe.player, ((ASBinCode.rtData.rtObjectBase)thisObj).value._class, (ASBinCode.rtData.rtObjectBase)thisObj);


					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_SortedList_get_Capacity : NativeConstParameterFunction
		{
			public system_collections_SortedList_get_Capacity() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_SortedList_get_Capacity";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.SortedList _this =
					(System.Collections.SortedList)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					int _result_ = (int)(_this.Capacity
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_SortedList_set_Capacity : NativeConstParameterFunction
		{
			public system_collections_SortedList_set_Capacity() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_SortedList_set_Capacity";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.SortedList _this =
					(System.Collections.SortedList)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					_this.Capacity = (System.Int32)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_SortedList_containsKey : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_SortedList_containsKey() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_SortedList_containsKey";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.SortedList _this =
					(System.Collections.SortedList)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Object arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Object)_temp;
					}

					bool _result_ = _this.ContainsKey((System.Object)arg0)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.SortedList).GetMethod("ContainsKey",new Type[] {typeof(System.Object)});;
				}
				return method;
			}

		}

		public class system_collections_SortedList_containsValue : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_SortedList_containsValue() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_SortedList_containsValue";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.SortedList _this =
					(System.Collections.SortedList)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Object arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Object)_temp;
					}

					bool _result_ = _this.ContainsValue((System.Object)arg0)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.SortedList).GetMethod("ContainsValue",new Type[] {typeof(System.Object)});;
				}
				return method;
			}

		}

		public class system_collections_SortedList_getByIndex : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_SortedList_getByIndex() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_SortedList_getByIndex";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.SortedList _this =
					(System.Collections.SortedList)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					object _result_ = _this.GetByIndex((System.Int32)arg0)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.SortedList).GetMethod("GetByIndex",new Type[] {typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_SortedList_getKey : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_SortedList_getKey() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_SortedList_getKey";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.SortedList _this =
					(System.Collections.SortedList)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					object _result_ = _this.GetKey((System.Int32)arg0)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.SortedList).GetMethod("GetKey",new Type[] {typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_SortedList_getKeyList : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_SortedList_getKeyList() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_SortedList_getKeyList";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.SortedList _this =
					(System.Collections.SortedList)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.GetKeyList()
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.SortedList).GetMethod("GetKeyList",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_collections_SortedList_getValueList : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_SortedList_getValueList() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_SortedList_getValueList";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.SortedList _this =
					(System.Collections.SortedList)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.GetValueList()
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.SortedList).GetMethod("GetValueList",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_collections_SortedList_indexOfKey : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_SortedList_indexOfKey() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_SortedList_indexOfKey";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.SortedList _this =
					(System.Collections.SortedList)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Object arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Object)_temp;
					}

					int _result_ = (int)(_this.IndexOfKey((System.Object)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.SortedList).GetMethod("IndexOfKey",new Type[] {typeof(System.Object)});;
				}
				return method;
			}

		}

		public class system_collections_SortedList_indexOfValue : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_SortedList_indexOfValue() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_SortedList_indexOfValue";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.SortedList _this =
					(System.Collections.SortedList)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Object arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Object)_temp;
					}

					int _result_ = (int)(_this.IndexOfValue((System.Object)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.SortedList).GetMethod("IndexOfValue",new Type[] {typeof(System.Object)});;
				}
				return method;
			}

		}

		public class system_collections_SortedList_removeAt : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_SortedList_removeAt() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_SortedList_removeAt";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.SortedList _this =
					(System.Collections.SortedList)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					_this.RemoveAt((System.Int32)arg0)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.SortedList).GetMethod("RemoveAt",new Type[] {typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_SortedList_setByIndex : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_SortedList_setByIndex() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_SortedList_setByIndex";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.SortedList _this =
					(System.Collections.SortedList)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					System.Object arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Object)_temp;
					}

					_this.SetByIndex((System.Int32)arg0,(System.Object)arg1)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.SortedList).GetMethod("SetByIndex",new Type[] {typeof(System.Int32),typeof(System.Object)});;
				}
				return method;
			}

		}

		public class static_system_collections_SortedList_synchronized : NativeConstParameterFunction
		{
			public static_system_collections_SortedList_synchronized() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "static_system_collections_SortedList_synchronized";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				try
				{
					System.Collections.SortedList arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Collections.SortedList)_temp;
					}

					object _result_ = System.Collections.SortedList.Synchronized((System.Collections.SortedList)arg0)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_SortedList_trimToSize : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_SortedList_trimToSize() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_SortedList_trimToSize";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.SortedList _this =
					(System.Collections.SortedList)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					_this.TrimToSize()
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.SortedList).GetMethod("TrimToSize",Type.EmptyTypes);;
				}
				return method;
			}

		}

	}
}
