using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_collections_generic_List_Of_Sprite_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_collections_generic_List_Of_Sprite_creator", default(System.Collections.Generic.List<UnityEngine.Sprite>)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_constructor_","system_collections_generic_List_Of_Sprite_constructor_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_ctor","system_collections_generic_List_Of_Sprite_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin._system_collections_generic_List_Of_SpriteAdapter_ctor","_system_collections_generic_List_Of_SpriteAdapter_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_get_Capacity","system_collections_generic_List_Of_Sprite_get_Capacity");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_set_Capacity","system_collections_generic_List_Of_Sprite_set_Capacity");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_getThisItem","system_collections_generic_List_Of_Sprite_getThisItem");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_setThisItem","system_collections_generic_List_Of_Sprite_setThisItem");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_add","system_collections_generic_List_Of_Sprite_add");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_asReadOnly","system_collections_generic_List_Of_Sprite_asReadOnly");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_binarySearch_","system_collections_generic_List_Of_Sprite_binarySearch_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_contains","system_collections_generic_List_Of_Sprite_contains");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_copyTo","system_collections_generic_List_Of_Sprite_copyTo");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_copyTo_","system_collections_generic_List_Of_Sprite_copyTo_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_copyTo__","system_collections_generic_List_Of_Sprite_copyTo__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_exists","system_collections_generic_List_Of_Sprite_exists");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_find","system_collections_generic_List_Of_Sprite_find");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_findAll","system_collections_generic_List_Of_Sprite_findAll");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_findIndex","system_collections_generic_List_Of_Sprite_findIndex");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_findIndex_","system_collections_generic_List_Of_Sprite_findIndex_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_findIndex__","system_collections_generic_List_Of_Sprite_findIndex__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_findLast","system_collections_generic_List_Of_Sprite_findLast");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_findLastIndex","system_collections_generic_List_Of_Sprite_findLastIndex");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_findLastIndex_","system_collections_generic_List_Of_Sprite_findLastIndex_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_findLastIndex__","system_collections_generic_List_Of_Sprite_findLastIndex__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_forEach","system_collections_generic_List_Of_Sprite_forEach");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_getRange","system_collections_generic_List_Of_Sprite_getRange");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_indexOf","system_collections_generic_List_Of_Sprite_indexOf");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_indexOf_","system_collections_generic_List_Of_Sprite_indexOf_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_indexOf__","system_collections_generic_List_Of_Sprite_indexOf__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_insert","system_collections_generic_List_Of_Sprite_insert");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_lastIndexOf","system_collections_generic_List_Of_Sprite_lastIndexOf");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_lastIndexOf_","system_collections_generic_List_Of_Sprite_lastIndexOf_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_lastIndexOf__","system_collections_generic_List_Of_Sprite_lastIndexOf__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_remove","system_collections_generic_List_Of_Sprite_remove");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_removeAll","system_collections_generic_List_Of_Sprite_removeAll");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_removeRange","system_collections_generic_List_Of_Sprite_removeRange");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_reverse","system_collections_generic_List_Of_Sprite_reverse");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_reverse_","system_collections_generic_List_Of_Sprite_reverse_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_sort","system_collections_generic_List_Of_Sprite_sort");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_sort___","system_collections_generic_List_Of_Sprite_sort___");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_toArray","system_collections_generic_List_Of_Sprite_toArray");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_trimExcess","system_collections_generic_List_Of_Sprite_trimExcess");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_generic_List_Of_Sprite_buildin.system_collections_generic_List_Of_Sprite_trueForAll","system_collections_generic_List_Of_Sprite_trueForAll");
		}

		public class system_collections_generic_List_Of_SpriteAdapter :System.Collections.Generic.List<UnityEngine.Sprite> ,ASRuntime.ICrossExtendAdapter
		{

			public ASBinCode.rtti.Class AS3Class { get { return typeclass; } }

			public ASBinCode.rtData.rtObjectBase AS3Object { get { return bindAS3Object; } }

			protected Player player;
			private Class typeclass;
			private ASBinCode.rtData.rtObjectBase bindAS3Object;

			public void SetAS3RuntimeEnvironment(Player player, Class typeclass, ASBinCode.rtData.rtObjectBase bindAS3Object)
			{
				this.player = player;
				this.typeclass = typeclass;
				this.bindAS3Object = bindAS3Object;
			}

			public system_collections_generic_List_Of_SpriteAdapter():base(){}

		}
		public class system_collections_generic_List_Of_Sprite_constructor_ : NativeConstParameterFunction
		{
			public system_collections_generic_List_Of_Sprite_constructor_() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_constructor_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Collections.Generic.List<UnityEngine.Sprite>((System.Int32)arg0));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_generic_List_Of_Sprite_ctor : NativeConstParameterFunction
		{
			public system_collections_generic_List_Of_Sprite_ctor() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{

					((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new System.Collections.Generic.List<UnityEngine.Sprite>();
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class _system_collections_generic_List_Of_SpriteAdapter_ctor : NativeConstParameterFunction,ICrossExtendAdapterCreator
		{
			public _system_collections_generic_List_Of_SpriteAdapter_ctor() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public Type GetAdapterType()
			{
				return typeof(system_collections_generic_List_Of_SpriteAdapter);
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "_system_collections_generic_List_Of_SpriteAdapter_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{

					((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new system_collections_generic_List_Of_SpriteAdapter();

					((ICrossExtendAdapter)((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value)
						.SetAS3RuntimeEnvironment(stackframe.player, ((ASBinCode.rtData.rtObjectBase)thisObj).value._class, (ASBinCode.rtData.rtObjectBase)thisObj);


					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_generic_List_Of_Sprite_get_Capacity : NativeConstParameterFunction
		{
			public system_collections_generic_List_Of_Sprite_get_Capacity() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_get_Capacity";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					int _result_ = (int)(_this.Capacity
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_generic_List_Of_Sprite_set_Capacity : NativeConstParameterFunction
		{
			public system_collections_generic_List_Of_Sprite_set_Capacity() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_set_Capacity";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					_this.Capacity = (System.Int32)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_generic_List_Of_Sprite_getThisItem : NativeConstParameterFunction
		{
			public system_collections_generic_List_Of_Sprite_getThisItem() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_getThisItem";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					object _result_ = _this[(System.Int32)arg0]
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_generic_List_Of_Sprite_setThisItem : NativeConstParameterFunction
		{
			public system_collections_generic_List_Of_Sprite_setThisItem() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_setThisItem";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.Sprite arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.Sprite)_temp;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					_this[(System.Int32)arg1] = (UnityEngine.Sprite)arg0
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_generic_List_Of_Sprite_add : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_add() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_add";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.Sprite arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.Sprite)_temp;
					}

					_this.Add((UnityEngine.Sprite)arg0)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("Add",new Type[] {typeof(UnityEngine.Sprite)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_asReadOnly : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_asReadOnly() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_asReadOnly";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.AsReadOnly()
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("AsReadOnly",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_binarySearch_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_binarySearch_() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_binarySearch_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.Sprite arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.Sprite)_temp;
					}

					int _result_ = (int)(_this.BinarySearch((UnityEngine.Sprite)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("BinarySearch",new Type[] {typeof(UnityEngine.Sprite)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_contains : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_contains() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_contains";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.Sprite arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.Sprite)_temp;
					}

					bool _result_ = _this.Contains((UnityEngine.Sprite)arg0)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("Contains",new Type[] {typeof(UnityEngine.Sprite)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_copyTo : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_copyTo() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_copyTo";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.Sprite[] arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.Sprite[])_temp;
					}

					_this.CopyTo((UnityEngine.Sprite[])arg0)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("CopyTo",new Type[] {typeof(UnityEngine.Sprite[])});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_copyTo_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_copyTo_() : base(4)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_copyTo_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					UnityEngine.Sprite[] arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (UnityEngine.Sprite[])_temp;
					}
					int arg2 = TypeConverter.ConvertToInt(argements[2]);
					int arg3 = TypeConverter.ConvertToInt(argements[3]);

					_this.CopyTo((System.Int32)arg0,(UnityEngine.Sprite[])arg1,(System.Int32)arg2,(System.Int32)arg3)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("CopyTo",new Type[] {typeof(System.Int32),typeof(UnityEngine.Sprite[]),typeof(System.Int32),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_copyTo__ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_copyTo__() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_copyTo__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.Sprite[] arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.Sprite[])_temp;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					_this.CopyTo((UnityEngine.Sprite[])arg0,(System.Int32)arg1)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("CopyTo",new Type[] {typeof(UnityEngine.Sprite[]),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_exists : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_exists() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_exists";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Predicate<UnityEngine.Sprite> arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Predicate<UnityEngine.Sprite>)_temp;
					}

					bool _result_ = _this.Exists((System.Predicate<UnityEngine.Sprite>)arg0)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("Exists",new Type[] {typeof(System.Predicate<UnityEngine.Sprite>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_find : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_find() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_find";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Predicate<UnityEngine.Sprite> arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Predicate<UnityEngine.Sprite>)_temp;
					}

					object _result_ = _this.Find((System.Predicate<UnityEngine.Sprite>)arg0)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("Find",new Type[] {typeof(System.Predicate<UnityEngine.Sprite>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_findAll : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_findAll() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_findAll";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Predicate<UnityEngine.Sprite> arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Predicate<UnityEngine.Sprite>)_temp;
					}

					object _result_ = _this.FindAll((System.Predicate<UnityEngine.Sprite>)arg0)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("FindAll",new Type[] {typeof(System.Predicate<UnityEngine.Sprite>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_findIndex : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_findIndex() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_findIndex";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Predicate<UnityEngine.Sprite> arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Predicate<UnityEngine.Sprite>)_temp;
					}

					int _result_ = (int)(_this.FindIndex((System.Predicate<UnityEngine.Sprite>)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("FindIndex",new Type[] {typeof(System.Predicate<UnityEngine.Sprite>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_findIndex_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_findIndex_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_findIndex_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					System.Predicate<UnityEngine.Sprite> arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Predicate<UnityEngine.Sprite>)_temp;
					}

					int _result_ = (int)(_this.FindIndex((System.Int32)arg0,(System.Predicate<UnityEngine.Sprite>)arg1)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("FindIndex",new Type[] {typeof(System.Int32),typeof(System.Predicate<UnityEngine.Sprite>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_findIndex__ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_findIndex__() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_findIndex__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					System.Predicate<UnityEngine.Sprite> arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Predicate<UnityEngine.Sprite>)_temp;
					}

					int _result_ = (int)(_this.FindIndex((System.Int32)arg0,(System.Int32)arg1,(System.Predicate<UnityEngine.Sprite>)arg2)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("FindIndex",new Type[] {typeof(System.Int32),typeof(System.Int32),typeof(System.Predicate<UnityEngine.Sprite>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_findLast : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_findLast() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_findLast";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Predicate<UnityEngine.Sprite> arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Predicate<UnityEngine.Sprite>)_temp;
					}

					object _result_ = _this.FindLast((System.Predicate<UnityEngine.Sprite>)arg0)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("FindLast",new Type[] {typeof(System.Predicate<UnityEngine.Sprite>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_findLastIndex : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_findLastIndex() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_findLastIndex";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Predicate<UnityEngine.Sprite> arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Predicate<UnityEngine.Sprite>)_temp;
					}

					int _result_ = (int)(_this.FindLastIndex((System.Predicate<UnityEngine.Sprite>)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("FindLastIndex",new Type[] {typeof(System.Predicate<UnityEngine.Sprite>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_findLastIndex_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_findLastIndex_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_findLastIndex_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					System.Predicate<UnityEngine.Sprite> arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Predicate<UnityEngine.Sprite>)_temp;
					}

					int _result_ = (int)(_this.FindLastIndex((System.Int32)arg0,(System.Predicate<UnityEngine.Sprite>)arg1)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("FindLastIndex",new Type[] {typeof(System.Int32),typeof(System.Predicate<UnityEngine.Sprite>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_findLastIndex__ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_findLastIndex__() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_findLastIndex__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					System.Predicate<UnityEngine.Sprite> arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.Predicate<UnityEngine.Sprite>)_temp;
					}

					int _result_ = (int)(_this.FindLastIndex((System.Int32)arg0,(System.Int32)arg1,(System.Predicate<UnityEngine.Sprite>)arg2)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("FindLastIndex",new Type[] {typeof(System.Int32),typeof(System.Int32),typeof(System.Predicate<UnityEngine.Sprite>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_forEach : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_forEach() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_forEach";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Action<UnityEngine.Sprite> arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Action<UnityEngine.Sprite>)_temp;
					}

					_this.ForEach((System.Action<UnityEngine.Sprite>)arg0)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("ForEach",new Type[] {typeof(System.Action<UnityEngine.Sprite>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_getRange : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_getRange() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_getRange";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					object _result_ = _this.GetRange((System.Int32)arg0,(System.Int32)arg1)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("GetRange",new Type[] {typeof(System.Int32),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_indexOf : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_indexOf() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_indexOf";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.Sprite arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.Sprite)_temp;
					}

					int _result_ = (int)(_this.IndexOf((UnityEngine.Sprite)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("IndexOf",new Type[] {typeof(UnityEngine.Sprite)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_indexOf_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_indexOf_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_indexOf_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.Sprite arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.Sprite)_temp;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					int _result_ = (int)(_this.IndexOf((UnityEngine.Sprite)arg0,(System.Int32)arg1)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("IndexOf",new Type[] {typeof(UnityEngine.Sprite),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_indexOf__ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_indexOf__() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_indexOf__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.Sprite arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.Sprite)_temp;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					int arg2 = TypeConverter.ConvertToInt(argements[2]);

					int _result_ = (int)(_this.IndexOf((UnityEngine.Sprite)arg0,(System.Int32)arg1,(System.Int32)arg2)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("IndexOf",new Type[] {typeof(UnityEngine.Sprite),typeof(System.Int32),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_insert : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_insert() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_insert";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					UnityEngine.Sprite arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (UnityEngine.Sprite)_temp;
					}

					_this.Insert((System.Int32)arg0,(UnityEngine.Sprite)arg1)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("Insert",new Type[] {typeof(System.Int32),typeof(UnityEngine.Sprite)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_lastIndexOf : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_lastIndexOf() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_lastIndexOf";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.Sprite arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.Sprite)_temp;
					}

					int _result_ = (int)(_this.LastIndexOf((UnityEngine.Sprite)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("LastIndexOf",new Type[] {typeof(UnityEngine.Sprite)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_lastIndexOf_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_lastIndexOf_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_lastIndexOf_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.Sprite arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.Sprite)_temp;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					int _result_ = (int)(_this.LastIndexOf((UnityEngine.Sprite)arg0,(System.Int32)arg1)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("LastIndexOf",new Type[] {typeof(UnityEngine.Sprite),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_lastIndexOf__ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_lastIndexOf__() : base(3)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_lastIndexOf__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.Sprite arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.Sprite)_temp;
					}
					int arg1 = TypeConverter.ConvertToInt(argements[1]);
					int arg2 = TypeConverter.ConvertToInt(argements[2]);

					int _result_ = (int)(_this.LastIndexOf((UnityEngine.Sprite)arg0,(System.Int32)arg1,(System.Int32)arg2)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("LastIndexOf",new Type[] {typeof(UnityEngine.Sprite),typeof(System.Int32),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_remove : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_remove() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_remove";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.Sprite arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.Sprite)_temp;
					}

					bool _result_ = _this.Remove((UnityEngine.Sprite)arg0)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("Remove",new Type[] {typeof(UnityEngine.Sprite)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_removeAll : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_removeAll() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_removeAll";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Predicate<UnityEngine.Sprite> arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Predicate<UnityEngine.Sprite>)_temp;
					}

					int _result_ = (int)(_this.RemoveAll((System.Predicate<UnityEngine.Sprite>)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("RemoveAll",new Type[] {typeof(System.Predicate<UnityEngine.Sprite>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_removeRange : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_removeRange() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_removeRange";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					_this.RemoveRange((System.Int32)arg0,(System.Int32)arg1)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("RemoveRange",new Type[] {typeof(System.Int32),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_reverse : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_reverse() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_reverse";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					_this.Reverse()
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("Reverse",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_reverse_ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_reverse_() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_reverse_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					int arg1 = TypeConverter.ConvertToInt(argements[1]);

					_this.Reverse((System.Int32)arg0,(System.Int32)arg1)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("Reverse",new Type[] {typeof(System.Int32),typeof(System.Int32)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_sort : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_sort() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_sort";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					_this.Sort()
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("Sort",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_sort___ : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_sort___() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_sort___";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Comparison<UnityEngine.Sprite> arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Comparison<UnityEngine.Sprite>)_temp;
					}

					_this.Sort((System.Comparison<UnityEngine.Sprite>)arg0)
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("Sort",new Type[] {typeof(System.Comparison<UnityEngine.Sprite>)});;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_toArray : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_toArray() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_toArray";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.ToArray()
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("ToArray",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_trimExcess : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_trimExcess() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_trimExcess";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.fun_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					_this.TrimExcess()
					;
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("TrimExcess",Type.EmptyTypes);;
				}
				return method;
			}

		}

		public class system_collections_generic_List_Of_Sprite_trueForAll : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_generic_List_Of_Sprite_trueForAll() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_generic_List_Of_Sprite_trueForAll";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_boolean;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Generic.List<UnityEngine.Sprite> _this =
					(System.Collections.Generic.List<UnityEngine.Sprite>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.Predicate<UnityEngine.Sprite> arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Predicate<UnityEngine.Sprite>)_temp;
					}

					bool _result_ = _this.TrueForAll((System.Predicate<UnityEngine.Sprite>)arg0)
					;
					if(_result_)
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.True);
					}
					else
					{
						returnSlot.setValue(ASBinCode.rtData.rtBoolean.False);
					}

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Generic.List<UnityEngine.Sprite>).GetMethod("TrueForAll",new Type[] {typeof(System.Predicate<UnityEngine.Sprite>)});;
				}
				return method;
			}

		}

	}
}
