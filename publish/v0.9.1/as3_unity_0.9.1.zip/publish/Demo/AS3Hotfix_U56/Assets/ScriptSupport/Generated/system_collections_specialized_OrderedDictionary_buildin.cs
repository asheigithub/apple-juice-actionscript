using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_collections_specialized_OrderedDictionary_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_collections_specialized_OrderedDictionary_creator", default(System.Collections.Specialized.OrderedDictionary)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_OrderedDictionary_buildin.system_collections_specialized_OrderedDictionary_constructor_","system_collections_specialized_OrderedDictionary_constructor_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_OrderedDictionary_buildin.system_collections_specialized_OrderedDictionary_constructor__","system_collections_specialized_OrderedDictionary_constructor__");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_OrderedDictionary_buildin.system_collections_specialized_OrderedDictionary_constructor___","system_collections_specialized_OrderedDictionary_constructor___");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_OrderedDictionary_buildin.system_collections_specialized_OrderedDictionary_ctor","system_collections_specialized_OrderedDictionary_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_OrderedDictionary_buildin._system_collections_specialized_OrderedDictionaryAdapter_ctor","_system_collections_specialized_OrderedDictionaryAdapter_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_collections_specialized_OrderedDictionary_buildin.system_collections_specialized_OrderedDictionary_asReadOnly","system_collections_specialized_OrderedDictionary_asReadOnly");
		}

		public class system_collections_specialized_OrderedDictionaryAdapter :System.Collections.Specialized.OrderedDictionary ,ASRuntime.ICrossExtendAdapter
		{

			public ASBinCode.rtti.Class AS3Class { get { return typeclass; } }

			public ASBinCode.rtData.rtObjectBase AS3Object { get { return bindAS3Object; } }

			protected Player player;
			private Class typeclass;
			private ASBinCode.rtData.rtObjectBase bindAS3Object;

			public void SetAS3RuntimeEnvironment(Player player, Class typeclass, ASBinCode.rtData.rtObjectBase bindAS3Object)
			{
				this.player = player;
				this.typeclass = typeclass;
				this.bindAS3Object = bindAS3Object;
			}

			public system_collections_specialized_OrderedDictionaryAdapter():base(){}
			private ASBinCode.rtData.rtFunction _as3function_0;
			private int _as3functionId_0 =-1;
			public override System.Collections.IDictionaryEnumerator GetEnumerator()
			{

				if (_as3function_0 == null)
					_as3function_0 = (ASBinCode.rtData.rtFunction)player.getMethod(bindAS3Object, "getEnumerator");
				if (_as3functionId_0 == -1)
				{
					_as3functionId_0 = ((ClassMethodGetter)typeclass.getBaseLinkSystemClass().classMembers.FindByName("getEnumerator").bindField).functionId;
				}

				if (_as3function_0 != null &&
				(player == null || (player != null && NativeConstParameterFunction.checkToken(
				new NativeConstParameterFunction.ExecuteToken(
				player.ExecuteToken.tokenid, _as3functionId_0
				)
				))
				)
				)
				{
					return base.GetEnumerator();
				}
				else
				{
					return (System.Collections.IDictionaryEnumerator)player.InvokeFunction(_as3function_0,0,null,null,null,null,null,null);
				}
			}


		}
		public class system_collections_specialized_OrderedDictionary_constructor_ : NativeConstParameterFunction
		{
			public system_collections_specialized_OrderedDictionary_constructor_() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_OrderedDictionary_constructor_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Collections.Specialized.OrderedDictionary((System.Int32)arg0));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_specialized_OrderedDictionary_constructor__ : NativeConstParameterFunction
		{
			public system_collections_specialized_OrderedDictionary_constructor__() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_OrderedDictionary_constructor__";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					System.Collections.IEqualityComparer arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.Collections.IEqualityComparer)_temp;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Collections.Specialized.OrderedDictionary((System.Collections.IEqualityComparer)arg0));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_specialized_OrderedDictionary_constructor___ : NativeConstParameterFunction
		{
			public system_collections_specialized_OrderedDictionary_constructor___() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_int);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_OrderedDictionary_constructor___";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					int arg0 = TypeConverter.ConvertToInt(argements[0]);
					System.Collections.IEqualityComparer arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (System.Collections.IEqualityComparer)_temp;
					}

					var cls = bin.getClassByRunTimeDataType(functionDefine.signature.returnType);
					((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, new System.Collections.Specialized.OrderedDictionary((System.Int32)arg0,(System.Collections.IEqualityComparer)arg1));
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_specialized_OrderedDictionary_ctor : NativeConstParameterFunction
		{
			public system_collections_specialized_OrderedDictionary_ctor() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_OrderedDictionary_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{

					((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new System.Collections.Specialized.OrderedDictionary();
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class _system_collections_specialized_OrderedDictionaryAdapter_ctor : NativeConstParameterFunction,ICrossExtendAdapterCreator
		{
			public _system_collections_specialized_OrderedDictionaryAdapter_ctor() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public Type GetAdapterType()
			{
				return typeof(system_collections_specialized_OrderedDictionaryAdapter);
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "_system_collections_specialized_OrderedDictionaryAdapter_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{

					((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = new system_collections_specialized_OrderedDictionaryAdapter();

					((ICrossExtendAdapter)((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value)
						.SetAS3RuntimeEnvironment(stackframe.player, ((ASBinCode.rtData.rtObjectBase)thisObj).value._class, (ASBinCode.rtData.rtObjectBase)thisObj);


					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
					success = true;
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_collections_specialized_OrderedDictionary_asReadOnly : NativeConstParameterFunction,IMethodGetter
		{
			public system_collections_specialized_OrderedDictionary_asReadOnly() : base(0)
			{
				para = new List<RunTimeDataType>();

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_collections_specialized_OrderedDictionary_asReadOnly";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Collections.Specialized.OrderedDictionary _this =
					(System.Collections.Specialized.OrderedDictionary)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{

					object _result_ = _this.AsReadOnly()
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			private System.Reflection.MethodInfo method;
			public System.Reflection.MethodInfo GetMethodInfo()
			{
				if (method == null)
				{
					method=typeof(System.Collections.Specialized.OrderedDictionary).GetMethod("AsReadOnly",Type.EmptyTypes);;
				}
				return method;
			}

		}

	}
}
