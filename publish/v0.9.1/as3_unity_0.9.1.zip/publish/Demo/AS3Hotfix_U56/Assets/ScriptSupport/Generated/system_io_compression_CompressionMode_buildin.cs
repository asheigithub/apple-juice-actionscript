using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_io_compression_CompressionMode_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_io_compression_CompressionMode_creator", default(System.IO.Compression.CompressionMode)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_io_compression_CompressionMode_buildin.system_io_compression_CompressionMode_ctor","system_io_compression_CompressionMode_ctor");
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_io_compression_CompressionMode_Decompress_getter",()=>{ return System.IO.Compression.CompressionMode.Decompress;}));
			bin.regNativeFunction(LinkSystem_Buildin.getStruct_static_field_getter("system_io_compression_CompressionMode_Compress_getter",()=>{ return System.IO.Compression.CompressionMode.Compress;}));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_io_compression_CompressionMode_buildin.system_io_compression_CompressionMode_operator_bitOr","system_io_compression_CompressionMode_operator_bitOr");
		}

		public class system_io_compression_CompressionMode_ctor : NativeFunctionBase
		{
			public system_io_compression_CompressionMode_ctor()
			{
				para = new List<RunTimeDataType>();
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_io_compression_CompressionMode_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override RunTimeValueBase execute(RunTimeValueBase thisObj, SLOT[] argements, object stackframe, out string errormessage, out int errorno)
			{
				errormessage = null; errorno = 0;
				return ASBinCode.rtData.rtUndefined.undefined;

			}
		}

		public class system_io_compression_CompressionMode_operator_bitOr : ASRuntime.nativefuncs.NativeConstParameterFunction
		{
			public system_io_compression_CompressionMode_operator_bitOr() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_io_compression_CompressionMode_operator_bitOr";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{
				System.IO.Compression.CompressionMode ts1;

				if (argements[0].rtType == RunTimeDataType.rt_null)
				{
					ts1 = default(System.IO.Compression.CompressionMode);
				}
				else
				{
					LinkObj<object> argObj = (LinkObj<object>)((ASBinCode.rtData.rtObjectBase)argements[0]).value;
					ts1 = (System.IO.Compression.CompressionMode)argObj.value;
				}

				System.IO.Compression.CompressionMode ts2;

				if (argements[1].rtType == RunTimeDataType.rt_null)
				{
					ts2 = default(System.IO.Compression.CompressionMode);
				}
				else
				{
					LinkObj<object> argObj = (LinkObj<object>)((ASBinCode.rtData.rtObjectBase)argements[1]).value;
					ts2 = (System.IO.Compression.CompressionMode)argObj.value;
				}

				((StackSlot)returnSlot).setLinkObjectValue(
					bin.getClassByRunTimeDataType(functionDefine.signature.returnType), stackframe.player, ts1 | ts2);

				success = true;
			}
		}

	}
}
