using ASBinCode;
using ASBinCode.rtti;
using ASRuntime;
using ASRuntime.nativefuncs;
using System;
using System.Collections;
using System.Collections.Generic;
namespace ASCAutoGen.regNativeFunctions
{
	class system_Comparison_Of_Selectable_buildin
	{
		public static void regNativeFunctions(CSWC bin)
		{
			bin.regNativeFunction(LinkSystem_Buildin.getCreator("system_Comparison_Of_Selectable_creator", default(System.Comparison<UnityEngine.UI.Selectable>)));
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Comparison_Of_Selectable_buildin.system_Comparison_Of_Selectable_ctor","system_Comparison_Of_Selectable_ctor");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Comparison_Of_Selectable_buildin.system_Comparison_Of_Selectable_implicit_from_","system_Comparison_Of_Selectable_implicit_from_");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Comparison_Of_Selectable_buildin.system_Comparison_Of_Selectable_invoke","system_Comparison_Of_Selectable_invoke");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Comparison_Of_Selectable_buildin.system_Comparison_Of_Selectable_beginInvoke","system_Comparison_Of_Selectable_beginInvoke");
			bin.regNativeFunction("ASCAutoGen.regNativeFunctions.system_Comparison_Of_Selectable_buildin.system_Comparison_Of_Selectable_endInvoke","system_Comparison_Of_Selectable_endInvoke");
		}


		public class system_Comparison_Of_Selectable_ctor : NativeConstParameterFunction
		{
			public system_Comparison_Of_Selectable_ctor() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_function);
				
			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Comparison_Of_Selectable_ctor";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					var cls = bin.getClassByRunTimeDataType(thisObj.rtType);

					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						stackframe.throwArgementException(token, "参数" + functionDefine.signature.parameters[0].name + "不能为null" );
						success = false;
					}
					else
					{
						var action = stackframe.player.WapperFunctionDelegate(argements[0], cls, typeof(System.Comparison<UnityEngine.UI.Selectable>) ,

							(wapper) => {
								

								System.Comparison<UnityEngine.UI.Selectable> actionwapper = (__wapperargs__0,__wapperargs__1) =>
								{
									return (System.Int32)wapper.Invoke(__wapperargs__0,__wapperargs__1);
								};

								wapper.action = actionwapper;								

							}
							
							);

						


						((LinkObj<object>)((ASBinCode.rtData.rtObjectBase)thisObj).value).value = action;
						success = true;
					}
					returnSlot.directSet(ASBinCode.rtData.rtUndefined.undefined);
					
				}
				catch (ASRunTimeException ex)
				{
					success = false;
					stackframe.throwError(token, 9998, ex.ToString());					
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}


		public class system_Comparison_Of_Selectable_implicit_from_ : NativeConstParameterFunction,IWapperDelegateMaker
		{
			public system_Comparison_Of_Selectable_implicit_from_() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_function);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Comparison_Of_Selectable_implicit_from_";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				try
				{
					var cls = ((ASBinCode.rtData.rtObjectBase)thisObj).value._class.instanceClass;
					if (argements[0].rtType == RunTimeDataType.rt_null)
					{
						stackframe.throwArgementException(token, "参数" + functionDefine.signature.parameters[0].name + "不能为null");
						success = false;
					}
					else
					{
						var action = MakeWapper(argements[0], stackframe.player, cls);

						((StackSlot)returnSlot).setLinkObjectValue(cls, stackframe.player, (System.Comparison<UnityEngine.UI.Selectable>)action);

						success = true;
					}

				}
				catch (ASRunTimeException ex)
				{
					success = false;
					stackframe.throwError(token, 9998, ex.ToString());
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}

			public Delegate MakeWapper(ASBinCode.RunTimeValueBase function, Player player, ASBinCode.rtti.Class cls)
			{
				var action = player.WapperFunctionDelegate(function, cls, typeof(System.Comparison<UnityEngine.UI.Selectable>),
					(wapper)=> {
						

						System.Comparison<UnityEngine.UI.Selectable> actionwapper = (__wapperargs__0,__wapperargs__1) =>
						{
							return (System.Int32)wapper.Invoke(__wapperargs__0,__wapperargs__1);
						};

						wapper.action = actionwapper;
						
					});

				

				return action;

			}
		}

		public class system_Comparison_Of_Selectable_invoke : NativeConstParameterFunction
		{
			public system_Comparison_Of_Selectable_invoke() : base(2)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Comparison_Of_Selectable_invoke";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Comparison<UnityEngine.UI.Selectable> _this =
					(System.Comparison<UnityEngine.UI.Selectable>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.UI.Selectable arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.UI.Selectable)_temp;
					}
					UnityEngine.UI.Selectable arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (UnityEngine.UI.Selectable)_temp;
					}

					int _result_ = (int)(_this.Invoke((UnityEngine.UI.Selectable)arg0,(UnityEngine.UI.Selectable)arg1)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_Comparison_Of_Selectable_beginInvoke : NativeConstParameterFunction
		{
			public system_Comparison_Of_Selectable_beginInvoke() : base(4)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Comparison_Of_Selectable_beginInvoke";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_void;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Comparison<UnityEngine.UI.Selectable> _this =
					(System.Comparison<UnityEngine.UI.Selectable>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					UnityEngine.UI.Selectable arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (UnityEngine.UI.Selectable)_temp;
					}
					UnityEngine.UI.Selectable arg1;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[1],

							stackframe.player.linktypemapper.getLinkType(argements[1].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[1].rtType,

								functionDefine.signature.parameters[1].type
								);
							success = false;
							return;
						}
						arg1 = (UnityEngine.UI.Selectable)_temp;
					}
					System.AsyncCallback arg2;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[2],

							stackframe.player.linktypemapper.getLinkType(argements[2].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[2].rtType,

								functionDefine.signature.parameters[2].type
								);
							success = false;
							return;
						}
						arg2 = (System.AsyncCallback)_temp;
					}
					System.Object arg3;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[3],

							stackframe.player.linktypemapper.getLinkType(argements[3].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[3].rtType,

								functionDefine.signature.parameters[3].type
								);
							success = false;
							return;
						}
						arg3 = (System.Object)_temp;
					}

					object _result_ = _this.BeginInvoke((UnityEngine.UI.Selectable)arg0,(UnityEngine.UI.Selectable)arg1,(System.AsyncCallback)arg2,(System.Object)arg3)
					;
					stackframe.player.linktypemapper.storeLinkObject_ToSlot(_result_, functionDefine.signature.returnType, returnSlot, bin, stackframe.player);
					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

		public class system_Comparison_Of_Selectable_endInvoke : NativeConstParameterFunction
		{
			public system_Comparison_Of_Selectable_endInvoke() : base(1)
			{
				para = new List<RunTimeDataType>();
				para.Add(RunTimeDataType.rt_void);

			}

			public override bool isMethod
			{
				get
				{
					return true;
				}
			}

			public override string name
			{
				get
				{
					return "system_Comparison_Of_Selectable_endInvoke";
				}
			}

			List<RunTimeDataType> para;
			public override List<RunTimeDataType> parameters
			{
				get
				{
					return para;
				}
			}

			public override RunTimeDataType returnType
			{
				get
				{
					return RunTimeDataType.rt_int;
				}
			}

			public override void execute3(RunTimeValueBase thisObj, FunctionDefine functionDefine, SLOT returnSlot, SourceToken token, StackFrame stackframe, out bool success)
			{

				System.Comparison<UnityEngine.UI.Selectable> _this =
					(System.Comparison<UnityEngine.UI.Selectable>)((LinkSystemObject)((ASBinCode.rtData.rtObjectBase)thisObj).value).GetLinkData();

				try
				{
					System.IAsyncResult arg0;
					{
						object _temp;
						if (!stackframe.player.linktypemapper.rtValueToLinkObject(
							argements[0],

							stackframe.player.linktypemapper.getLinkType(argements[0].rtType)
							,
							bin, true, out _temp
							))
						{
							stackframe.throwCastException(token, argements[0].rtType,

								functionDefine.signature.parameters[0].type
								);
							success = false;
							return;
						}
						arg0 = (System.IAsyncResult)_temp;
					}

					int _result_ = (int)(_this.EndInvoke((System.IAsyncResult)arg0)
					)
					;
					returnSlot.setValue(_result_);

					
					
					success = true;
				}
				catch (ASRunTimeException tlc)
				{
					success = false;
					stackframe.throwAneException(token, tlc.Message);
				}
				catch (InvalidCastException ic)
				{
					success = false;
					stackframe.throwAneException(token, ic.Message);
				}
				catch (ArgumentException a)
				{
					success = false;
					stackframe.throwAneException(token, a.Message);
				}
				catch (IndexOutOfRangeException i)
				{
					success = false;
					stackframe.throwAneException(token, i.Message);
				}
				catch (NotSupportedException n)
				{
					success = false;
					stackframe.throwAneException(token, n.Message);
				}

			}
		}

	}
}
