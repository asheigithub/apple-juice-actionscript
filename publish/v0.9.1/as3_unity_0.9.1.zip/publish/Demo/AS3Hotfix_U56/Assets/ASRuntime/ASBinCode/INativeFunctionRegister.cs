﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASBinCode
{
    public interface INativeFunctionRegister
    {
        void registrationFunction(CSWC bin);
        
    }
}
