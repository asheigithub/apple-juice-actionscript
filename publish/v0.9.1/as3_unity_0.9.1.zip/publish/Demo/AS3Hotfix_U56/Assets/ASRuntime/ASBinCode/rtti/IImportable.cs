﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASBinCode.rtti
{
    /// <summary>
    /// 可导入的
    /// </summary>
    public interface IImportable
    {
        CSWC assembly { get;}
    }
}
