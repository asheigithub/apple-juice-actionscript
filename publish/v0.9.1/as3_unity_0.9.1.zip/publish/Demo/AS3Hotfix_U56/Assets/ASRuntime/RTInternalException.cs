﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASRuntime
{
    ///// <summary>
    ///// 运行时内部异常
    ///// </summary>
    //class RTInternalException :Exception
    //{
    //    public error.InternalError err;
    //    public RTInternalException(error.InternalError err)
    //    {
    //        this.err = err;
    //    }
    //    public RTInternalException(ASBinCode.SourceToken token,string message)
    //    {
    //        this.err = new error.InternalError(token, message);
    //    }
    //}
}
