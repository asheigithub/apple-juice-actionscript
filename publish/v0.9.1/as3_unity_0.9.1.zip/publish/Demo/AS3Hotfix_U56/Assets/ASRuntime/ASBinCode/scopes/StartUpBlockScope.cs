﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASBinCode.scopes
{
	public class StartUpBlockScope : ScopeBase
    {
    }
}
