﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASBinCode.rtti
{
    public interface IHostedObject
    {
        object hostedObject { get; set; }
    }
}
