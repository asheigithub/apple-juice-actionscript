﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASRuntime.flash.utils
{
	public interface IDataOutput
	{
	}
}
