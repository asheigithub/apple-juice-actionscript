用FlashDevelop打开项目，
点击编译，即可将热更字节码生成到Unity项目。

项目演示为将热更字节码复制到Unity的StreamingAssets中，真实项目需要从网络下载更新这个文件。

运行 bat\CreateUnityAPI.bat 可自动导出Unity API.
genapi.config.xml 中定义要到出API的dll.