用FlashDevelop打开项目，
点击编译，即可将热更字节码生成到Unity项目。

项目演示为将热更字节码复制到Unity的StreamingAssets中，真实项目需要从网络下载更新这个文件。

运行 bat\CreateUnityAPI.bat 可自动导出Unity API.
genapi.config.xml 中定义要到出API的dll.


The following text is translated by Bing Translator
----------------------------------------------------------
Open the project with FlashDevelop,

Click "Compile" to generate the hot fix bytecode file to the Unity project.

Project demo to copy the hot fix bytecode file to Unity's StreamingAssets directory, the real project can be modified to update the file from the network.

Run Bat/createunityapi.bat can automatically export the Unity API. These APIs can be defined in the configuration file ' Genapi.config.xml '.